package ru.example.jobs.placeholder;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.job.JobType;
import ru.example.jobs.manager.PlayerProfile;

public final class JobsExpansion extends PlaceholderExpansion {

    private final JobsPlugin plugin;

    public JobsExpansion(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return "job";
    }

    @Override
    public String getAuthor() {
        return "Redstone Agents";
    }

    @Override
    public String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (player == null) {
            return "";
        }
        try {
            PlayerProfile data = plugin.playerDataManager().getOrLoad(player.getUniqueId());
            String key = params.toLowerCase();
            return switch (key) {
                case "education" -> education(player);
                case "active" -> data.activeJob() == null
                        ? "none"
                        : data.activeJob().id();
                case "progress" -> progress(player, data);
                case "loader_delivered" -> String.valueOf(data.stats(JobType.LOADER).delivered());
                case "farmer_collected" -> String.valueOf(data.stats(JobType.FARMER).delivered());
                default -> "";
            };
        } catch (RuntimeException exception) {
            plugin.getLogger().warning("Ошибка PlaceholderAPI job_" + params + ": " + exception.getMessage());
            return "";
        }
    }

    private String education(OfflinePlayer player) {
        if (player.isOnline() && player.getPlayer() != null) {
            String value = player.getPlayer().getPersistentDataContainer()
                    .get(plugin.keys().education(), PersistentDataType.STRING);
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return plugin.config().educationDefault();
    }

    private String progress(OfflinePlayer player, PlayerProfile data) {
        JobType active = data.activeJob();
        if (active == null || !player.isOnline() || player.getPlayer() == null) {
            return "0";
        }
        return String.valueOf(plugin.jobManager().progress(player.getPlayer(), active));
    }
}
