package ru.example.jobs.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.config.GuiButton;
import ru.example.jobs.job.Job;
import ru.example.jobs.job.JobStopReason;
import ru.example.jobs.job.JobType;
import ru.example.jobs.manager.JobStats;
import ru.example.jobs.util.ItemUtil;
import ru.example.jobs.util.Text;
import ru.example.jobs.util.TimeFormat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public final class GuiManager {

    private static final int OPEN_ATTEMPTS = 3;

    private final JobsPlugin plugin;

    public GuiManager(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, JobType type) {
        if (player == null || !player.isOnline()) {
            return;
        }
        Inventory inventory = create(player, type);
        if (inventory == null) {
            plugin.getLogger().warning("GUI: не удалось построить меню " + type.id()
                    + " для " + player.getName());
            sendChatMenu(player, type);
            return;
        }

        plugin.getServer().getScheduler().runTask(plugin,
                () -> attemptOpen(player, type, inventory, 1));
    }

    private void attemptOpen(Player player, JobType type, Inventory inventory, int attempt) {
        if (!player.isOnline()) {
            return;
        }
        if (openNow(player, inventory)) {
            player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 0.8F, 1.0F);
            return;
        }
        if (attempt >= OPEN_ATTEMPTS) {
            sendChatMenu(player, type);
            return;
        }

        if (player.getOpenInventory().getTopInventory() != inventory) {
            player.closeInventory();
        }
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> attemptOpen(player, type, inventory, attempt + 1), 2L);
    }

    public void sendChatMenu(Player player, JobType type) {
        Job job = plugin.jobManager().job(type);
        String jobName = job == null ? type.id() : job.plainDisplayName();
        JobType active = plugin.jobManager().activeJob(player);

        player.sendMessage(Text.mm("<red>Меню работы открыть не удалось: инвентари блокирует другой плагин.</red>"));
        if (active == null) {
            player.sendMessage(Text.mm("<yellow>Начать работу: <click:run_command:'/jobs start "
                    + type.id() + "'><gold>[Начать " + Text.escape(jobName) + "]</gold></click></yellow>"));
        } else if (active == type) {
            player.sendMessage(Text.mm("<yellow>Закончить работу: "
                    + "<click:run_command:'/jobs stop'><gold>[Закончить " + Text.escape(jobName)
                    + "]</gold></click></yellow>"));
        } else {
            player.sendMessage(Text.mm("<yellow>Сейчас активна другая работа. Закончить её: "
                    + "<click:run_command:'/jobs stop'><gold>[Закончить]</gold></click></yellow>"));
        }
    }

    public Inventory create(Player player, JobType type) {
        Job job = plugin.jobManager().job(type);
        String jobName = job == null ? type.id() : job.plainDisplayName();
        Map<String, String> base = Map.of("%job%", Text.escape(jobName));

        JobsGuiHolder holder = new JobsGuiHolder(type);
        Inventory inventory;
        try {
            inventory = Bukkit.createInventory(holder, 27,
                    Text.mm(plugin.config().guiTitle(), base));
            holder.inventory(inventory);
            fillFrame(inventory);

            JobType active = plugin.jobManager().activeJob(player);
            if (active == null) {
                inventory.setItem(plugin.config().startButton().slot(),
                        actionItem(plugin.config().startButton(), "start", base));
            } else if (active == type) {
                inventory.setItem(plugin.config().stopButton().slot(),
                        actionItem(plugin.config().stopButton(), "stop", base));
            } else {
                Job activeJob = plugin.jobManager().job(active);
                String activeName = activeJob == null ? active.id() : activeJob.plainDisplayName();
                Map<String, String> placeholders = Map.of(
                        "%job%", Text.escape(jobName),
                        "%active%", Text.escape(activeName),
                        "%active_job%", Text.escape(activeName));
                inventory.setItem(plugin.config().stopOtherButton().slot(),
                        actionItem(plugin.config().stopOtherButton(), "stop", placeholders));
            }

            inventory.setItem(plugin.config().infoButton().slot(), infoItem(player, type, base));
            GuiButton decoration = plugin.config().decorativeItem(type);
            if (decoration != null) {
                inventory.setItem(decoration.slot(), actionItem(decoration, null, base));
            }
        } catch (Throwable throwable) {
            plugin.getLogger().log(Level.WARNING, "GUI: ошибка построения меню " + type.id(), throwable);
            return null;
        }
        return inventory;
    }

    private boolean openNow(Player player, Inventory inventory) {
        if (!player.isOnline()) {
            return false;
        }
        try {
            player.openInventory(inventory);
        } catch (Throwable throwable) {
            plugin.getLogger().log(Level.WARNING,
                    "GUI: openInventory упал для " + player.getName(), throwable);
            return false;
        }

        return isOpen(player);
    }

    private boolean isOpen(Player player) {
        return player.getOpenInventory().getTopInventory().getHolder() instanceof JobsGuiHolder;
    }

    public void handleClick(Player player, JobsGuiHolder holder, InventoryClickEvent event) {
        event.setCancelled(true);
        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof JobsGuiHolder)) {
            return;
        }
        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return;
        }
        String action = item.getItemMeta().getPersistentDataContainer()
                .get(plugin.keys().action(), PersistentDataType.STRING);
        if (action == null) {
            return;
        }
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8F, 1.2F);

        switch (action) {
            case "start" -> {
                plugin.jobManager().startJob(player, holder.jobType());
                refreshNextTick(player, holder.jobType());
            }
            case "stop" -> {
                plugin.jobManager().stopJob(player, JobStopReason.GUI);
                player.closeInventory();
            }
            case "info" -> {
                
            }
            default -> {
            }
        }
    }

    private void refreshNextTick(Player player, JobType type) {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                open(player, type);
            }
        });
    }

    private ItemStack actionItem(GuiButton button, String action,
                                 Map<String, String> placeholders) {
        return ItemUtil.item(button.material(),
                Text.mm(button.name(), placeholders),
                renderLore(button.lore(), placeholders),
                action == null ? null : plugin.keys().action(),
                action);
    }

    private ItemStack infoItem(Player player, JobType type, Map<String, String> base) {
        JobStats stats = plugin.playerDataManager().getOrLoad(player).stats(type);
        GuiButton button = plugin.config().infoButton();
        Map<String, String> placeholders = Map.of(
                "%job%", base.get("%job%"),
                "%label%", Text.escape(plugin.config().statLabel(type)),
                "%delivered%", String.valueOf(stats.delivered()),
                "%count%", String.valueOf(stats.delivered()),
                "%earned%", Text.escape(plugin.economyService().format(stats.earned())),
                "%currency%", Text.escape(plugin.economyService().currencyName()),
                "%time%", TimeFormat.format(stats.timeSeconds()));
        return ItemUtil.item(button.material(),
                Text.mm(button.name(), placeholders),
                renderLore(button.lore(), placeholders));
    }

    private List<Component> renderLore(List<String> lines, Map<String, String> placeholders) {
        List<Component> lore = new ArrayList<>(lines.size());
        for (String line : lines) {
            lore.add(Text.mm(line, placeholders));
        }
        return lore;
    }

    private void fillFrame(Inventory inventory) {
        List<Material> fillers = plugin.config().guiFillerMaterials();
        if (fillers.isEmpty()) {
            fillers = List.of(Material.BLACK_STAINED_GLASS_PANE);
        }
        
        Material border = fillers.get(0);
        Material background = fillers.size() > 1 ? fillers.get(1) : border;
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, ItemUtil.filler(isBorder(slot) ? border : background));
        }
    }

    private boolean isBorder(int slot) {
        int row = slot / 9;
        int column = slot % 9;
        return row == 0 || row == 2 || column == 0 || column == 8;
    }
}
