package ru.example.jobs.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import ru.example.jobs.job.JobType;

public final class JobsGuiHolder implements InventoryHolder {

    private final JobType jobType;
    private Inventory inventory;

    public JobsGuiHolder(JobType jobType) {
        this.jobType = jobType;
    }

    public JobType jobType() {
        return jobType;
    }

    public void inventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
