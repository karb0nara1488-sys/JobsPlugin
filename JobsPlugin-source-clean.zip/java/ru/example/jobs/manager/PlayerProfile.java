package ru.example.jobs.manager;

import ru.example.jobs.job.JobType;

import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;

public final class PlayerProfile {

    private final UUID uuid;
    private String name;
    private String education;
    private JobType activeJob;
    private final Map<JobType, JobStats> stats = new EnumMap<>(JobType.class);
    private CarryState carry;
    private long sessionStartMillis;
    private boolean dirty;

    public PlayerProfile(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
        this.education = null;
        for (JobType type : JobType.values()) {
            stats.put(type, new JobStats());
        }
    }

    public UUID uuid() {
        return uuid;
    }

    public String name() {
        return name;
    }

    public void name(String name) {
        this.name = name;
    }

    public String education() {
        return education;
    }

    public void education(String education) {
        this.education = education;
    }

    public JobType activeJob() {
        return activeJob;
    }

    public void activeJob(JobType activeJob) {
        this.activeJob = activeJob;
    }

    public void setActiveJob(JobType activeJob) {
        this.activeJob = activeJob;
    }

    public boolean isActive(JobType type) {
        return activeJob == type;
    }

    public JobStats stats(JobType type) {
        return stats.computeIfAbsent(type, ignored -> new JobStats());
    }

    public Map<JobType, JobStats> allStats() {
        return stats;
    }

    public CarryState carry() {
        return carry;
    }

    public void carry(CarryState carry) {
        this.carry = carry;
    }

    public boolean isCarrying() {
        return carry != null;
    }

    public long sessionStartMillis() {
        return sessionStartMillis;
    }

    public void sessionStartMillis(long value) {
        this.sessionStartMillis = Math.max(0L, value);
    }

    public boolean dirty() {
        return dirty;
    }

    public void dirty(boolean dirty) {
        this.dirty = dirty;
    }

    public void markDirty() {
        this.dirty = true;
    }
}
