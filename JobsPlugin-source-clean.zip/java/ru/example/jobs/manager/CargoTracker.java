package ru.example.jobs.manager;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import ru.example.jobs.JobsPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public final class CargoTracker {

    private final JobsPlugin plugin;
    private final File file;
    private final Map<BlockKey, String> tracked = new HashMap<>();
    private boolean dirty;
    private int secondsSinceSave;

    public CargoTracker(JobsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "cargo.yml");
    }

    public void load() {
        tracked.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        for (Map<?, ?> entry : yaml.getMapList("blocks")) {
            String world = stringValue(entry.get("world"));
            String id = stringValue(entry.get("id"));
            if (world == null || id == null) {
                continue;
            }
            tracked.put(new BlockKey(world, intValue(entry.get("x")), intValue(entry.get("y")),
                    intValue(entry.get("z"))), id);
        }
        dirty = false;
        plugin.getLogger().info("Загружено блоков-груза: " + tracked.size() + ".");
    }

    public void save() {
        if (!dirty) {
            return;
        }
        YamlConfiguration yaml = new YamlConfiguration();
        List<Map<String, Object>> serialized = new ArrayList<>(tracked.size());
        for (Map.Entry<BlockKey, String> entry : tracked.entrySet()) {
            BlockKey key = entry.getKey();
            Map<String, Object> map = new HashMap<>();
            map.put("world", key.world());
            map.put("x", key.x());
            map.put("y", key.y());
            map.put("z", key.z());
            map.put("id", entry.getValue());
            serialized.add(map);
        }
        yaml.set("blocks", serialized);
        try {
            yaml.save(file);
            dirty = false;
        } catch (IOException exception) {
            plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить cargo.yml", exception);
        }
    }

    public void tickAutosave() {
        secondsSinceSave++;
        if (secondsSinceSave >= plugin.config().saveIntervalSeconds()) {
            secondsSinceSave = 0;
            save();
        }
    }

    public void track(Location location, String cargoId) {
        if (location == null || location.getWorld() == null || cargoId == null) {
            return;
        }
        tracked.put(BlockKey.of(location), cargoId);
        dirty = true;
    }

    public void untrack(Block block) {
        if (block == null || block.getWorld() == null) {
            return;
        }
        if (tracked.remove(BlockKey.of(block.getLocation())) != null) {
            dirty = true;
        }
    }

    public boolean isTracked(Block block) {
        return block != null && block.getWorld() != null
                && tracked.containsKey(BlockKey.of(block.getLocation()));
    }

    public String cargoIdAt(Block block) {
        return block == null || block.getWorld() == null
                ? null : tracked.get(BlockKey.of(block.getLocation()));
    }

    public int size() {
        return tracked.size();
    }

    private static String stringValue(Object value) {
        if (value == null) {
            return null;
        }
        String text = String.valueOf(value).trim();
        return text.isEmpty() ? null : text;
    }

    private static int intValue(Object value) {
        if (value instanceof Number number) {
            return number.intValue();
        }
        try {
            return value == null ? 0 : Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private record BlockKey(String world, int x, int y, int z) {

        static BlockKey of(Location location) {
            return new BlockKey(location.getWorld().getName(),
                    location.getBlockX(), location.getBlockY(), location.getBlockZ());
        }
    }
}
