package ru.example.jobs.manager;

import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.job.Job;
import ru.example.jobs.job.JobStopReason;
import ru.example.jobs.job.JobType;
import ru.example.jobs.util.Text;
import ru.example.jobs.util.TimeFormat;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class JobManager {

    private final JobsPlugin plugin;
    private final Map<JobType, Job> jobs = new EnumMap<>(JobType.class);
    private final Map<UUID, SessionState> sessions = new HashMap<>();

    public JobManager(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    public void register(Job job) {
        jobs.put(job.type(), job);
    }

    public Job job(JobType type) {
        return jobs.get(type);
    }

    public SessionState session(Player player) {
        return sessions.computeIfAbsent(player.getUniqueId(), ignored -> new SessionState());
    }

    public SessionState sessionIfPresent(Player player) {
        return sessions.get(player.getUniqueId());
    }

    public boolean isActive(Player player, JobType type) {
        return plugin.playerDataManager().getOrLoad(player).activeJob() == type;
    }

    public JobType activeJob(Player player) {
        return plugin.playerDataManager().getOrLoad(player).activeJob();
    }

    public void startJob(Player player, JobType type) {
        Job job = jobs.get(type);
        if (job == null) {
            return;
        }
        PlayerProfile data = plugin.playerDataManager().getOrLoad(player);
        JobType current = data.activeJob();
        if (current == type) {
            plugin.messages().send(player, "job-already-active");
            return;
        }
        if (current != null) {
            Job active = jobs.get(current);
            String name = active == null ? current.id() : active.plainDisplayName();
            plugin.messages().send(player, "already-working",
                    Map.of("%job%", Text.escape(name)));
            return;
        }

        data.setActiveJob(type);
        data.carry(null);
        plugin.playerDataManager().markDirty(player.getUniqueId());

        SessionState session = session(player);
        session.clearCarried();
        session.clearBag();
        job.onStart(player, session);

        plugin.messages().send(player, "job-started",
                Map.of("%job%", Text.escape(job.plainDisplayName())));
    }

    public void stopJob(Player player, JobStopReason reason) {
        PlayerProfile data = plugin.playerDataManager().getOrLoad(player);
        JobType type = data.activeJob();
        if (type == null) {
            plugin.messages().send(player, "no-active-job");
            return;
        }
        Job job = jobs.get(type);
        SessionState session = session(player);
        if (job != null) {
            job.onStop(player, session, reason);
        }

        data.setActiveJob(null);
        data.carry(null);
        plugin.playerDataManager().markDirty(player.getUniqueId());
        sessions.remove(player.getUniqueId());

        if (job != null) {
            sendReport(player, job, data.stats(type));
        }
    }

    public void handleJoin(Player player) {
        PlayerProfile data = plugin.playerDataManager().getOrLoad(player);
        JobType type = data.activeJob();
        if (type == null) {
            return;
        }
        Job job = jobs.get(type);
        if (job == null) {
            data.setActiveJob(null);
            plugin.playerDataManager().markDirty(player.getUniqueId());
            return;
        }
        job.onJoin(player, session(player));
    }

    public void handleQuit(Player player) {
        PlayerProfile data = plugin.playerDataManager().getOrLoad(player);
        JobType type = data.activeJob();
        if (type != null) {
            Job job = jobs.get(type);
            SessionState session = sessionIfPresent(player);
            if (job != null && session != null) {
                job.onQuit(player, session);
            }
        }
        sessions.remove(player.getUniqueId());
        plugin.playerDataManager().unload(player.getUniqueId());
    }

    public void handleDisable() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerProfile data = plugin.playerDataManager().getOrLoad(player);
            JobType type = data.activeJob();
            if (type == null) {
                continue;
            }
            Job job = jobs.get(type);
            SessionState session = sessionIfPresent(player);
            if (job != null && session != null) {
                job.onQuit(player, session);
            }
        }
        sessions.clear();
    }

    public void tickSecond() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerProfile data = plugin.playerDataManager().getOrLoad(player);
            JobType type = data.activeJob();
            if (type == null) {
                continue;
            }
            data.stats(type).addTimeSeconds(1L);
            plugin.playerDataManager().markDirty(player.getUniqueId());
        }
    }

    public void tickBossBars() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            SessionState session = sessions.get(player.getUniqueId());
            if (session == null) {
                continue;
            }
            PlayerProfile data = plugin.playerDataManager().getIfLoaded(player.getUniqueId());
            if (data == null || data.activeJob() == null) {
                continue;
            }
            Job job = jobs.get(data.activeJob());
            if (job != null) {
                job.tickBossBar(player, session);
            }
        }
    }

    public int progress(Player player, JobType type) {
        if (!isActive(player, type)) {
            return 0;
        }
        SessionState session = sessionIfPresent(player);
        Job job = jobs.get(type);
        if (session == null || job == null) {
            return 0;
        }
        return Math.max(0, Math.min(100, job.progress(player, session)));
    }

    public void clearSession(UUID uuid) {
        sessions.remove(uuid);
    }

    private void sendReport(Player player, Job job, JobStats stats) {
        Map<String, String> placeholders = Map.of(
                "%job%", Text.escape(job.plainDisplayName()),
                "%label%", Text.escape(plugin.config().statLabel(job.type())),
                "%delivered%", String.valueOf(stats.delivered()),
                "%earned%", Text.escape(plugin.economyService().format(stats.earned())),
                "%currency%", Text.escape(plugin.economyService().currencyName()),
                "%time%", TimeFormat.format(stats.timeSeconds()));
        plugin.messages().sendRaw(player, "job-stopped", placeholders);
        plugin.messages().sendRaw(player, "report-delivered", placeholders);
        plugin.messages().sendRaw(player, "report-earned", placeholders);
        plugin.messages().sendRaw(player, "report-time", placeholders);
    }
}
