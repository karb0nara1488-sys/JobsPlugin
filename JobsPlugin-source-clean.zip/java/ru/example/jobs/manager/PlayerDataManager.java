package ru.example.jobs.manager;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.config.PluginConfig;
import ru.example.jobs.job.JobType;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public final class PlayerDataManager {

    private final JobsPlugin plugin;
    private final PluginConfig config;
    private final File playersDirectory;
    private final Map<UUID, PlayerProfile> cache = new HashMap<>();
    private int autosaveSeconds;

    public PlayerDataManager(JobsPlugin plugin, PluginConfig config) {
        this.plugin = plugin;
        this.config = config;
        this.playersDirectory = new File(plugin.getDataFolder(), "players");
        if (!playersDirectory.exists() && !playersDirectory.mkdirs()) {
            plugin.getLogger().warning("Не удалось создать папку " + playersDirectory.getAbsolutePath());
        }
    }

    public PlayerProfile get(Player player) {
        PlayerProfile profile = cache.get(player.getUniqueId());
        if (profile == null) {
            profile = load(player.getUniqueId(), player.getName());
        } else if (player.getName() != null && !player.getName().equals(profile.name())) {
            profile.name(player.getName());
            profile.markDirty();
        }
        return profile;
    }

    public PlayerProfile getIfLoaded(UUID uuid) {
        return cache.get(uuid);
    }

    public PlayerProfile getOrLoad(UUID uuid, String name) {
        PlayerProfile cached = cache.get(uuid);
        if (cached != null) {
            return cached;
        }
        return load(uuid, name == null ? uuid.toString() : name);
    }

    public PlayerProfile getOrLoad(Player player) {
        return get(player);
    }

    public PlayerProfile getOrLoad(UUID uuid) {
        return getOrLoad(uuid, uuid.toString());
    }

    public void markDirty(UUID uuid) {
        PlayerProfile profile = cache.get(uuid);
        if (profile != null) {
            profile.markDirty();
        }
    }

    public void unload(UUID uuid) {
        PlayerProfile profile = cache.remove(uuid);
        if (profile != null) {
            save(profile);
        }
    }

    public void tickAutosave() {
        autosaveSeconds++;
        if (autosaveSeconds >= config.saveIntervalSeconds()) {
            autosaveSeconds = 0;
            saveAll();
        }
    }

    private PlayerProfile load(UUID uuid, String name) {
        PlayerProfile profile = new PlayerProfile(uuid, name);
        File file = playerFile(uuid);
        if (!file.exists()) {
            cache.put(uuid, profile);
            return profile;
        }

        YamlConfiguration yaml = readFile(file);
        if (yaml == null) {
            File backup = new File(playersDirectory, uuid + ".yml.bak");
            if (backup.exists()) {
                yaml = readFile(backup);
                if (yaml != null) {
                    plugin.getLogger().warning("Основной файл игрока " + uuid + " повреждён, загружен .bak");
                }
            }
        }
        if (yaml == null) {
            plugin.getLogger().severe("Не удалось прочитать данные игрока " + uuid + ". Создан пустой профиль.");
            cache.put(uuid, profile);
            return profile;
        }

        profile.name(yaml.getString("name", name));
        profile.education(yaml.getString("education"));
        profile.activeJob(JobType.fromId(yaml.getString("active_job")));

        for (JobType type : JobType.values()) {
            ConfigurationSection section = yaml.getConfigurationSection("jobs." + type.id());
            if (section == null) {
                continue;
            }
            JobStats stats = profile.stats(type);
            long counter;
            if (type == JobType.FARMER && section.contains("collected")) {
                counter = section.getLong("collected");
            } else {
                counter = section.getLong("delivered");
            }
            stats.counter(counter);
            stats.earned(section.getDouble("earned"));
            stats.timeSeconds(section.getLong("time_seconds"));
        }

        ConfigurationSection carrySection = yaml.getConfigurationSection("carry");
        if (carrySection != null) {
            JobType carryJob = JobType.fromId(carrySection.getString("job"));
            String cargoId = carrySection.getString("cargo-id");
            if (carryJob != null && cargoId != null) {
                Location origin = null;
                ConfigurationSection originSection = carrySection.getConfigurationSection("origin");
                if (originSection != null) {
                    String worldName = originSection.getString("world");
                    World world = worldName == null ? null : Bukkit.getWorld(worldName);
                    if (world != null) {
                        origin = new Location(world,
                                originSection.getDouble("x"),
                                originSection.getDouble("y"),
                                originSection.getDouble("z"));
                    } else {
                        plugin.getLogger().warning("Мир груза игрока " + uuid + " не загружен: " + worldName);
                    }
                }
                CarryState carry = new CarryState(carryJob, cargoId,
                        carrySection.getString("display-name", cargoId), origin);
                carry.inventorySnapshotBase64(carrySection.getString("inventory-snapshot"));
                profile.carry(carry);
            }
        }

        cache.put(uuid, profile);
        return profile;
    }

    private YamlConfiguration readFile(File file) {
        try {
            return YamlConfiguration.loadConfiguration(file);
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.WARNING, "Ошибка чтения " + file.getName(), ex);
            return null;
        }
    }

    public void save(PlayerProfile profile) {
        File file = playerFile(profile.uuid());
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("version", 1);
        yaml.set("name", profile.name());
        yaml.set("education", profile.education());
        yaml.set("active_job", profile.activeJob() == null ? null : profile.activeJob().id());

        for (JobType type : JobType.values()) {
            JobStats stats = profile.stats(type);
            String base = "jobs." + type.id();
            yaml.set(base + "." + type.counterKey(), stats.counter());
            if (type == JobType.FARMER) {
                
                yaml.set(base + ".delivered", stats.counter());
            }
            yaml.set(base + ".earned", stats.earned());
            yaml.set(base + ".time_seconds", stats.timeSeconds());
        }

        CarryState carry = profile.carry();
        if (carry != null) {
            yaml.set("carry.job", carry.job().id());
            yaml.set("carry.cargo-id", carry.cargoId());
            yaml.set("carry.display-name", carry.displayName());
            Location origin = carry.origin();
            if (origin != null) {
                yaml.set("carry.origin.world", origin.getWorld().getName());
                yaml.set("carry.origin.x", origin.getX());
                yaml.set("carry.origin.y", origin.getY());
                yaml.set("carry.origin.z", origin.getZ());
            }
            yaml.set("carry.snapshot-version", 1);
            yaml.set("carry.inventory-snapshot", carry.inventorySnapshotBase64());
        }

        try {
            if (config.backupBeforeSave() && file.exists()) {
                File backup = new File(playersDirectory, profile.uuid() + ".yml.bak");
                Files.copy(file.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
            yaml.save(file);
            profile.dirty(false);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить данные игрока " + profile.uuid(), ex);
        }
    }

    public void saveIfDirty(PlayerProfile profile) {
        if (profile.dirty()) {
            save(profile);
        }
    }

    public void saveAll() {
        for (PlayerProfile profile : cache.values()) {
            save(profile);
        }
    }

    public void saveAll(boolean ignored) {
        saveAll();
    }

    public Map<UUID, PlayerProfile> cache() {
        return cache;
    }

    private File playerFile(UUID uuid) {
        return new File(playersDirectory, uuid + ".yml");
    }
}
