package ru.example.jobs.manager;

public final class JobStats {

    private long counter;
    private double earned;
    private long timeSeconds;

    public long counter() {
        return counter;
    }

    public void counter(long value) {
        this.counter = Math.max(0L, value);
    }

    public long delivered() {
        return counter;
    }

    public long collected() {
        return counter;
    }

    public void addDelivered(long amount) {
        addCounter(amount);
    }

    public void addCollected(long amount) {
        addCounter(amount);
    }

    public void incrementCounter() {
        this.counter++;
    }

    public void addCounter(long amount) {
        this.counter += Math.max(0L, amount);
    }

    public double earned() {
        return earned;
    }

    public void earned(double value) {
        this.earned = Math.max(0.0, value);
    }

    public void addEarned(double amount) {
        this.earned = Math.max(0.0, this.earned + amount);
    }

    public long timeSeconds() {
        return timeSeconds;
    }

    public void timeSeconds(long value) {
        this.timeSeconds = Math.max(0L, value);
    }

    public void addTime(long seconds) {
        this.timeSeconds += Math.max(0L, seconds);
    }

    public void addTimeSeconds(long seconds) {
        addTime(seconds);
    }
}
