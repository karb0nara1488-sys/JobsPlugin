package ru.example.jobs.manager;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.LinkedHashMap;
import java.util.Map;

public final class SessionState {

    private boolean carrying;
    private String carriedBlockId;
    private Location carriedOrigin;

    private boolean lifting;
    private BukkitTask liftTask;
    private long liftStartMillis;
    private long liftDurationMillis;
    private String liftBlockId;
    private Location liftTarget;
    
    private Location liftOrigin;

    private BossBar bossBar;

    private ItemStack[] inventorySnapshot;

    private final Map<String, Integer> harvestBag = new LinkedHashMap<>();

    private double harvestValue;

    public boolean carrying() {
        return carrying;
    }

    public void setCarrying(boolean carrying) {
        this.carrying = carrying;
    }

    public String carriedBlockId() {
        return carriedBlockId;
    }

    public void setCarriedBlockId(String carriedBlockId) {
        this.carriedBlockId = carriedBlockId;
    }

    public Location carriedOrigin() {
        return carriedOrigin;
    }

    public void setCarriedOrigin(Location carriedOrigin) {
        this.carriedOrigin = carriedOrigin;
    }

    public void clearCarried() {
        this.carrying = false;
        this.carriedBlockId = null;
        this.carriedOrigin = null;
    }

    public boolean lifting() {
        return lifting;
    }

    public void setLifting(boolean lifting) {
        this.lifting = lifting;
    }

    public BukkitTask liftTask() {
        return liftTask;
    }

    public void setLiftTask(BukkitTask liftTask) {
        this.liftTask = liftTask;
    }

    public long liftStartMillis() {
        return liftStartMillis;
    }

    public void setLiftStartMillis(long liftStartMillis) {
        this.liftStartMillis = liftStartMillis;
    }

    public long liftDurationMillis() {
        return liftDurationMillis;
    }

    public void setLiftDurationMillis(long liftDurationMillis) {
        this.liftDurationMillis = liftDurationMillis;
    }

    public String liftBlockId() {
        return liftBlockId;
    }

    public void setLiftBlockId(String liftBlockId) {
        this.liftBlockId = liftBlockId;
    }

    public Location liftTarget() {
        return liftTarget;
    }

    public void setLiftTarget(Location liftTarget) {
        this.liftTarget = liftTarget;
    }

    public Location liftOrigin() {
        return liftOrigin;
    }

    public void setLiftOrigin(Location liftOrigin) {
        this.liftOrigin = liftOrigin;
    }

    public BossBar bossBar() {
        return bossBar;
    }

    public void setBossBar(BossBar bossBar) {
        this.bossBar = bossBar;
    }

    public boolean inventoryReplaced() {
        return inventorySnapshot != null;
    }

    public ItemStack[] inventorySnapshot() {
        return inventorySnapshot;
    }

    public void setInventorySnapshot(ItemStack[] snapshot) {
        this.inventorySnapshot = snapshot == null ? null : snapshot.clone();
    }

    public void clearInventorySnapshot() {
        this.inventorySnapshot = null;
    }

    public Map<String, Integer> harvestBag() {
        return harvestBag;
    }

    public int bagCount() {
        int total = 0;
        for (Integer value : harvestBag.values()) {
            total += value == null ? 0 : value;
        }
        return total;
    }

    public double harvestValue() {
        return harvestValue;
    }

    public void addHarvest(String cropId, double value) {
        harvestBag.merge(cropId, 1, Integer::sum);
        harvestValue += Math.max(0.0D, value);
    }

    public void clearBag() {
        harvestBag.clear();
        harvestValue = 0.0D;
    }

    public boolean hasBlock() {
        return carrying || !harvestBag.isEmpty();
    }
}
