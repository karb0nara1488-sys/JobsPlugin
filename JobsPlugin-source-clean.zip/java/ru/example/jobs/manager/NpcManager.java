package ru.example.jobs.manager;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.config.NpcLocation;
import ru.example.jobs.npc.NpcType;
import ru.example.jobs.util.Text;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class NpcManager {

    private static final double REMOVE_RADIUS = 12.0D;

    private final JobsPlugin plugin;
    private final Map<NpcType, List<NpcLocation>> locations = new EnumMap<>(NpcType.class);
    private final Map<NpcType, List<UUID>> spawned = new EnumMap<>(NpcType.class);

    public NpcManager(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        despawnAll();
        removeTaggedNpcs();
        loadLocations();
        spawnAll();
    }

    public void ensureSpawned() {
        for (NpcType type : NpcType.values()) {
            List<NpcLocation> points = locations.getOrDefault(type, List.of());
            if (points.isEmpty()) {
                continue;
            }
            if (!allChunksLoaded(points)) {
                continue;
            }
            int alive = 0;
            for (UUID uuid : spawned.getOrDefault(type, List.of())) {
                Entity entity = Bukkit.getEntity(uuid);
                if (entity != null && entity.isValid()) {
                    alive++;
                }
            }
            if (alive == points.size()) {
                continue;
            }
            plugin.getLogger().info("NPC " + type.id() + ": восстановлено " + points.size() + " шт.");
            despawn(type);
            for (NpcLocation point : points) {
                spawn(type, point);
            }
        }
    }

    private boolean allChunksLoaded(List<NpcLocation> points) {
        for (NpcLocation point : points) {
            Location location = point.resolve();
            if (location == null || location.getWorld() == null) {
                return false;
            }
            if (!location.getWorld()
                    .isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4)) {
                return false;
            }
        }
        return true;
    }

    private void loadLocations() {
        locations.clear();
        for (NpcType type : NpcType.values()) {
            locations.put(type, new ArrayList<>(plugin.config().npcLocations(type.id())));
        }
    }

    public void spawnAll() {
        int total = 0;
        for (NpcType type : NpcType.values()) {
            for (NpcLocation location : locations.getOrDefault(type, List.of())) {
                if (spawn(type, location)) {
                    total++;
                }
            }
        }
        if (total > 0) {
            plugin.getLogger().info("NPC размещено: " + total + ".");
        }
    }

    public void spawnAt(Player player, NpcType type) {
        Location location = player.getLocation().clone();
        plugin.config().addNpcLocation(type.id(), location);
        List<NpcLocation> points = locations.computeIfAbsent(type, ignored -> new ArrayList<>());
        points.add(NpcLocation.of(location));
        spawn(type, NpcLocation.of(location));
        plugin.messages().send(player, "npc-spawned", Map.of(
                "%id%", type.id(),
                "%count%", String.valueOf(points.size())));
    }

    public NpcType removeNearest(Player player) {
        Location origin = player.getLocation();
        NpcType bestType = null;
        double bestDistance = REMOVE_RADIUS * REMOVE_RADIUS;
        for (NpcType type : NpcType.values()) {
            for (NpcLocation location : locations.getOrDefault(type, List.of())) {
                double distance = location.distanceSquared(origin);
                if (distance >= 0.0D && distance <= bestDistance) {
                    bestDistance = distance;
                    bestType = type;
                }
            }
        }
        if (bestType == null) {
            return null;
        }
        plugin.config().removeNpcLocation(bestType.id(), origin, REMOVE_RADIUS);
        reload();
        return bestType;
    }

    public int clear(NpcType type) {
        int count = locations.getOrDefault(type, List.of()).size();
        if (count == 0) {
            return 0;
        }
        plugin.config().clearNpcLocations(type.id());
        reload();
        return count;
    }

    public int count(NpcType type) {
        return locations.getOrDefault(type, List.of()).size();
    }

    public int totalCount() {
        int total = 0;
        for (NpcType type : NpcType.values()) {
            total += count(type);
        }
        return total;
    }

    private boolean spawn(NpcType type, NpcLocation requested) {
        Location location = requested.resolve();
        if (location == null || location.getWorld() == null) {
            plugin.getLogger().warning("NPC " + type.id() + " не создан: мир '" + requested.world()
                    + "' ещё не загружен.");
            return false;
        }
        World world = location.getWorld();
        int chunkX = location.getBlockX() >> 4;
        int chunkZ = location.getBlockZ() >> 4;
        if (!world.isChunkLoaded(chunkX, chunkZ)) {
            Chunk chunk = world.getChunkAt(chunkX, chunkZ);
            if (!chunk.isLoaded()) {
                chunk.load();
            }
        }
        Villager villager = world.spawn(location, Villager.class, entity -> {
            entity.setAI(false);
            entity.setSilent(true);
            entity.setInvulnerable(true);
            entity.setPersistent(true);
            entity.setRemoveWhenFarAway(false);
            entity.setCanPickupItems(false);
            entity.setCollidable(false);
            entity.setProfession(Villager.Profession.NONE);
            entity.setVillagerType(Villager.Type.PLAINS);
            entity.customName(Text.mm(plugin.config().npcName(type)));
            entity.setCustomNameVisible(true);
            entity.setRotation(location.getYaw(), location.getPitch());
            entity.getPersistentDataContainer().set(plugin.keys().npc(),
                    PersistentDataType.STRING, type.id());
        });
        spawned.computeIfAbsent(type, ignored -> new ArrayList<>()).add(villager.getUniqueId());
        return true;
    }

    public void despawn(NpcType type) {
        List<UUID> uuids = spawned.remove(type);
        if (uuids == null) {
            return;
        }
        for (UUID uuid : uuids) {
            Entity entity = Bukkit.getEntity(uuid);
            if (entity != null) {
                entity.remove();
            }
        }
    }

    public void despawnAll() {
        for (NpcType type : NpcType.values()) {
            despawn(type);
        }
    }

    public void removeTaggedNpcs() {
        for (World world : Bukkit.getWorlds()) {
            for (Villager villager : world.getEntitiesByClass(Villager.class)) {
                if (villager.getPersistentDataContainer()
                        .has(plugin.keys().npc(), PersistentDataType.STRING)) {
                    villager.remove();
                }
            }
        }
    }

    public Optional<NpcType> npcType(Entity entity) {
        if (entity == null) {
            return Optional.empty();
        }
        String id = entity.getPersistentDataContainer()
                .get(plugin.keys().npc(), PersistentDataType.STRING);
        return NpcType.byId(id);
    }

    public Location location(NpcType type) {
        List<NpcLocation> points = locations.get(type);
        return points == null || points.isEmpty() ? null : points.get(0).resolve();
    }

    public List<NpcLocation> locations(NpcType type) {
        return List.copyOf(locations.getOrDefault(type, List.of()));
    }

    public double removeRadius() {
        return REMOVE_RADIUS;
    }
}
