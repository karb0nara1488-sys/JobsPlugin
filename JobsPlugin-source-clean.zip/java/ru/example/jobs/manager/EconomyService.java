package ru.example.jobs.manager;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import ru.example.jobs.config.PluginConfig;
import ru.example.jobs.economy.EconomyProvider;
import ru.example.jobs.economy.NoEconomyProvider;
import ru.example.jobs.economy.VaultEconomyResolver;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class EconomyService {

    private final PluginConfig config;
    private volatile EconomyProvider provider = NoEconomyProvider.INSTANCE;

    public EconomyService(PluginConfig config) {
        this.config = config;
    }

    public boolean reconfigure() {
        provider = NoEconomyProvider.INSTANCE;
        return tryHook();
    }

    public boolean tryHook() {
        if (!config.economyEnabled()) {
            provider = NoEconomyProvider.INSTANCE;
            return false;
        }
        if (provider.available()) {
            return true;
        }
        EconomyProvider resolved;
        try {
            resolved = VaultEconomyResolver.resolve();
        } catch (Throwable ignored) {
            resolved = null;
        }
        if (resolved == null) {
            return false;
        }
        provider = resolved;
        return true;
    }

    public boolean available() {
        return provider.available();
    }

    public String backendName() {
        return provider.backendName();
    }

    public boolean deposit(OfflinePlayer player, double amount) {
        if (!available() && !tryHook()) {
            return false;
        }
        if (amount <= 0.0D) {
            return true;
        }
        return provider.deposit(player, amount);
    }

    public String currencyName() {
        String name = provider.currencyName();
        return name == null || name.isBlank() ? config.currencyFallback() : name;
    }

    public String formatAmount(double amount) {
        return String.format(Locale.ROOT, "%.2f", amount);
    }

    public String format(double amount) {
        return formatAmount(amount);
    }

    public List<String> diagnostics() {
        List<String> lines = new ArrayList<>();
        lines.add("economy.provider=" + config.economyProviderMode()
                + ", enabled=" + config.economyEnabled()
                + ", available=" + available()
                + ", backend=" + provider.backendName());
        boolean vaultBridge = false;
        boolean vaultEconomyPlugin = false;
        for (Plugin plugin : Bukkit.getPluginManager().getPlugins()) {
            String name = plugin.getName();
            String lower = name.toLowerCase(Locale.ROOT);
            if (lower.equals("vault") || lower.equals("vaultunlocked")) {
                vaultBridge = true;
            }
            if (lower.contains("vaulteconomy")) {
                vaultEconomyPlugin = true;
            }
            if (!lower.contains("vault") && !lower.contains("essent")) {
                continue;
            }
            lines.add("плагин " + name + ": " + (plugin.isEnabled() ? "включён" : "выключен")
                    + ", версия " + plugin.getDescription().getVersion());
        }
        lines.addAll(VaultEconomyResolver.describeServices());
        if (!provider.available() && !vaultBridge) {
            if (vaultEconomyPlugin) {
                lines.add("Подсказка: VaultEconomy — это экономический плагин, а не Vault API. "
                        + "Установите Vault (MilkBowl) или VaultUnlocked.");
            } else {
                lines.add("Подсказка: установите Vault (MilkBowl) или VaultUnlocked, "
                        + "чтобы экономика стала доступна другим плагинам.");
            }
        }
        return lines;
    }
}
