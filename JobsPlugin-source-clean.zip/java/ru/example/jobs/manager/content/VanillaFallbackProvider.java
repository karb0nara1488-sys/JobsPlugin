package ru.example.jobs.manager.content;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

public final class VanillaFallbackProvider implements CustomContentProvider {

    private final Map<String, Material> materials;
    private final Map<Material, String> reverse;
    private final Logger logger;

    public VanillaFallbackProvider(Map<String, Material> materials, Logger logger) {
        this.materials = Collections.unmodifiableMap(new LinkedHashMap<>(materials));
        this.reverse = new LinkedHashMap<>();
        for (Map.Entry<String, Material> entry : this.materials.entrySet()) {
            this.reverse.putIfAbsent(entry.getValue(), entry.getKey());
        }
        this.logger = logger;
    }

    @Override
    public String name() {
        return "Vanilla";
    }

    @Override
    public boolean available() {
        return true;
    }

    @Override
    public String blockId(Block block) {
        return reverse.get(block.getType());
    }

    @Override
    public boolean removeBlock(Block block) {
        block.setType(Material.AIR, false);
        return true;
    }

    @Override
    public boolean placeBlock(String id, Location location) {
        Material material = materials.get(id);
        if (material == null) {
            logger.warning("Vanilla fallback: неизвестный id '" + id + "'");
            return false;
        }
        Block block = location.getBlock();
        block.setType(material, false);
        BlockData data = block.getBlockData();
        if (data instanceof Ageable ageable) {
            ageable.setAge(0);
            block.setBlockData(ageable, false);
        }
        return true;
    }

    @Override
    public ItemStack item(String id) {
        Material material = materials.get(id);
        return material == null ? null : new ItemStack(material);
    }
}
