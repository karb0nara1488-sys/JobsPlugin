package ru.example.jobs.manager.content;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

public final class NexoContentProvider implements CustomContentProvider {

    private static final String NEXO_BLOCKS_CLASS = "com.nexomc.nexo.api.NexoBlocks";
    private static final String NEXO_ITEMS_CLASS = "com.nexomc.nexo.api.NexoItems";
    private static final String ITEM_BUILDER_CLASS = "com.nexomc.nexo.items.ItemBuilder";
    private static final String MECHANIC_CLASS = "com.nexomc.nexo.mechanics.Mechanic";

    private final Logger logger;
    private final Map<String, Boolean> itemCache = new ConcurrentHashMap<>();

    private boolean available;
    private boolean failureLogged;

    private Method isCustomBlock;
    private Method customBlockMechanic;
    private Method mechanicGetItemId;
    private Method itemFromId;
    private Method itemBuilderBuild;
    private Method placeBlock;
    private Method removeBlock;

    public NexoContentProvider(Logger logger) {
        this.logger = logger;
        try {
            init();
            this.available = true;
            logger.info("Nexo API подключён (reflection). Кастомный контент активен.");
        } catch (Throwable throwable) {
            this.available = false;
            logger.info("Nexo API недоступен, используется vanilla fallback: " + throwable.getClass().getSimpleName());
        }
    }

    private void init() throws ReflectiveOperationException {
        Class<?> nexoBlocks = Class.forName(NEXO_BLOCKS_CLASS);
        this.isCustomBlock = nexoBlocks.getMethod("isCustomBlock", Block.class);
        this.customBlockMechanic = nexoBlocks.getMethod("customBlockMechanic", Block.class);
        this.placeBlock = nexoBlocks.getMethod("place", String.class, Location.class);
        this.removeBlock = nexoBlocks.getMethod("remove", Location.class, Player.class, boolean.class);

        Class<?> mechanic = Class.forName(MECHANIC_CLASS);
        this.mechanicGetItemId = mechanic.getMethod("getItemID");

        Class<?> nexoItems = Class.forName(NEXO_ITEMS_CLASS);
        this.itemFromId = nexoItems.getMethod("itemFromId", String.class);

        Class<?> itemBuilder = Class.forName(ITEM_BUILDER_CLASS);
        this.itemBuilderBuild = itemBuilder.getMethod("build");
    }

    @Override
    public String name() {
        return "Nexo";
    }

    @Override
    public boolean available() {
        return available;
    }

    public boolean hasItem(String id) {
        if (!available || id == null) {
            return false;
        }
        return itemCache.computeIfAbsent(id, key -> {
            try {
                return itemFromId.invoke(null, key) != null;
            } catch (ReflectiveOperationException exception) {
                logFailure("NexoItems.itemFromId", exception);
                return false;
            }
        });
    }

    @Override
    public String blockId(Block block) {
        if (!available) {
            return null;
        }
        try {
            Object custom = isCustomBlock.invoke(null, block);
            if (!(custom instanceof Boolean) || !((Boolean) custom)) {
                return null;
            }
            Object mechanic = customBlockMechanic.invoke(null, block);
            if (mechanic == null) {
                return null;
            }
            Object id = mechanicGetItemId.invoke(mechanic);
            return id instanceof String ? (String) id : null;
        } catch (ReflectiveOperationException exception) {
            logFailure("NexoBlocks.customBlockMechanic", exception);
            return null;
        }
    }

    @Override
    public boolean removeBlock(Block block) {
        if (!available) {
            return false;
        }
        try {
            Object result = removeBlock.invoke(null, block.getLocation(), null, false);
            return result instanceof Boolean && (Boolean) result;
        } catch (ReflectiveOperationException exception) {
            logFailure("NexoBlocks.remove", exception);
            return false;
        }
    }

    @Override
    public boolean placeBlock(String id, Location location) {
        if (!available || id == null) {
            return false;
        }
        try {
            placeBlock.invoke(null, id, location);
            return true;
        } catch (ReflectiveOperationException exception) {
            logFailure("NexoBlocks.place", exception);
            return false;
        }
    }

    @Override
    public ItemStack item(String id) {
        if (!available || id == null) {
            return null;
        }
        try {
            Object builder = itemFromId.invoke(null, id);
            if (builder == null) {
                return null;
            }
            Object result = itemBuilderBuild.invoke(builder);
            return result instanceof ItemStack ? (ItemStack) result : null;
        } catch (ReflectiveOperationException exception) {
            logFailure("NexoItems.itemFromId", exception);
            return null;
        }
    }

    private void logFailure(String method, ReflectiveOperationException exception) {
        if (!failureLogged) {
            failureLogged = true;
            logger.warning("Ошибка вызова Nexo API " + method + ": " + exception);
        }
    }
}
