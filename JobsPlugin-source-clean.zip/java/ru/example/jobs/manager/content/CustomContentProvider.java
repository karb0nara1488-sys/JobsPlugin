package ru.example.jobs.manager.content;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

public interface CustomContentProvider {

    String name();

    boolean available();

    String blockId(Block block);

    boolean removeBlock(Block block);

    boolean placeBlock(String id, Location location);

    ItemStack item(String id);
}
