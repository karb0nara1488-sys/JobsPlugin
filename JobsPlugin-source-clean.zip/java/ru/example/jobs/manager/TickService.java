package ru.example.jobs.manager;

import org.bukkit.scheduler.BukkitTask;
import ru.example.jobs.JobsPlugin;

import java.util.logging.Level;

public final class TickService {

    private final JobsPlugin plugin;
    private BukkitTask secondTask;
    private BukkitTask bossBarTask;
    private BukkitTask displayTask;
    private int npcSeconds;

    public TickService(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        stop();
        secondTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            try {
                plugin.jobManager().tickSecond();
                plugin.playerDataManager().tickAutosave();
                plugin.fieldManager().tickAutosave();
                plugin.cargoTracker().tickAutosave();
                npcSeconds++;
                if (npcSeconds >= 5) {
                    npcSeconds = 0;
                    plugin.npcManager().ensureSpawned();
                }
            } catch (Throwable throwable) {
                plugin.getLogger().log(Level.SEVERE, "Ошибка в секундной задаче JobsPlugin", throwable);
            }
        }, 20L, 20L);

        bossBarTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            try {
                plugin.jobManager().tickBossBars();
            } catch (Throwable throwable) {
                plugin.getLogger().log(Level.SEVERE, "Ошибка обновления BossBar", throwable);
            }
        }, 2L, 2L);

        int displayTicks = plugin.config().displayUpdateTicks();
        displayTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            try {
                plugin.fieldManager().tickDisplays();
            } catch (Throwable throwable) {
                plugin.getLogger().log(Level.SEVERE, "Ошибка обновления TextDisplay", throwable);
            }
        }, displayTicks, displayTicks);
    }

    public void stop() {
        if (secondTask != null) {
            secondTask.cancel();
            secondTask = null;
        }
        if (bossBarTask != null) {
            bossBarTask.cancel();
            bossBarTask = null;
        }
        if (displayTask != null) {
            displayTask.cancel();
            displayTask = null;
        }
    }

    public void restart() {
        stop();
        start();
    }
}
