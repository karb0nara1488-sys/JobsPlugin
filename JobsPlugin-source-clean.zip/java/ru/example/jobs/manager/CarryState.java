package ru.example.jobs.manager;

import org.bukkit.Location;
import ru.example.jobs.job.JobType;

public final class CarryState {

    private final JobType job;
    private final String cargoId;
    private final String displayName;
    private final Location origin;
    
    private String inventorySnapshotBase64;

    public CarryState(JobType job, String cargoId, String displayName, Location origin) {
        this.job = job;
        this.cargoId = cargoId;
        this.displayName = displayName;
        this.origin = origin == null ? null : origin.clone();
    }

    public JobType job() {
        return job;
    }

    public String cargoId() {
        return cargoId;
    }

    public String displayName() {
        return displayName;
    }

    public Location origin() {
        return origin == null ? null : origin.clone();
    }

    public String inventorySnapshotBase64() {
        return inventorySnapshotBase64;
    }

    public void inventorySnapshotBase64(String value) {
        this.inventorySnapshotBase64 = value;
    }
}
