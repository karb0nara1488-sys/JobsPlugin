package ru.example.jobs.manager;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import ru.example.jobs.config.PluginConfig;
import ru.example.jobs.field.CropType;
import ru.example.jobs.job.LoaderBlockType;
import ru.example.jobs.manager.content.CustomContentProvider;
import ru.example.jobs.manager.content.NexoContentProvider;
import ru.example.jobs.manager.content.VanillaFallbackProvider;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ContentManager {

    private final JavaPlugin plugin;
    private final PluginConfig config;
    private final NexoContentProvider nexo;
    private final Map<String, Material> fallbackMaterials = new LinkedHashMap<>();

    private VanillaFallbackProvider vanilla;

    public ContentManager(JavaPlugin plugin, PluginConfig config) {
        this.plugin = plugin;
        this.config = config;
        rebuildFallback();
        if (Bukkit.getPluginManager().getPlugin("Nexo") != null) {
            this.nexo = new NexoContentProvider(plugin.getLogger());
            if (!nexo.available()) {
                plugin.getLogger().info("Nexo установлен, но API недоступен — используется vanilla fallback.");
            }
        } else {
            this.nexo = null;
            plugin.getLogger().info("Nexo не установлен — используется vanilla fallback.");
        }
    }

    private void rebuildFallback() {
        fallbackMaterials.clear();
        for (LoaderBlockType block : config.loaderBlocks().values()) {
            fallbackMaterials.put(block.id(), block.fallbackMaterial());
        }
        for (CropType crop : config.crops().values()) {
            fallbackMaterials.put(crop.id(), crop.fallbackMaterial());
        }
        this.vanilla = new VanillaFallbackProvider(fallbackMaterials, plugin.getLogger());
    }

    public void reload() {
        rebuildFallback();
    }

    private boolean nexoActive() {
        return nexo != null && nexo.available();
    }

    public String blockId(Block block) {
        if (nexoActive()) {
            String id = nexo.blockId(block);
            if (id != null) {
                return id;
            }
        }
        return vanilla.blockId(block);
    }

    public boolean removeBlock(Block block) {
        if (nexoActive() && nexo.blockId(block) != null) {
            return nexo.removeBlock(block);
        }
        return vanilla.removeBlock(block);
    }

    public boolean placeBlock(String id, Location location) {
        if (nexoActive() && nexo.hasItem(id)) {
            return nexo.placeBlock(id, location);
        }
        return vanilla.placeBlock(id, location);
    }

    public boolean placeCrop(CropType crop, Location location) {
        if (nexoActive() && crop.nexoId() != null && nexo.hasItem(crop.nexoId())) {
            return nexo.placeBlock(crop.nexoId(), location);
        }
        return vanilla.placeBlock(crop.id(), location);
    }

    public ItemStack item(String id) {
        if (nexoActive() && nexo.hasItem(id)) {
            ItemStack item = nexo.item(id);
            if (item != null) {
                return item;
            }
        }
        return vanilla.item(id);
    }

    public LoaderBlockType loaderBlock(String id) {
        return id == null ? null : config.loaderBlocks().get(id);
    }

    public boolean isNexoAvailable() {
        return nexoActive();
    }

    public String providerName() {
        return nexoActive() ? "Nexo" : "Vanilla";
    }

    public Map<String, Material> fallbackMaterials() {
        return Map.copyOf(fallbackMaterials);
    }
}
