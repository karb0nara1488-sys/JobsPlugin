package ru.example.jobs.manager;

import ru.example.jobs.job.JobType;

import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;

public final class PlayerData {

    private final UUID uuid;
    private final Map<JobType, JobStats> stats = new EnumMap<>(JobType.class);
    private JobType activeJob;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        for (JobType type : JobType.values()) {
            stats.put(type, new JobStats());
        }
    }

    public UUID uuid() {
        return uuid;
    }

    public JobStats stats(JobType type) {
        return stats.computeIfAbsent(type, ignored -> new JobStats());
    }

    public JobType activeJob() {
        return activeJob;
    }

    public void setActiveJob(JobType activeJob) {
        this.activeJob = activeJob;
    }

    public boolean isActive(JobType type) {
        return activeJob == type;
    }
}
