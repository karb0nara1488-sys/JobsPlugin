package ru.example.jobs.job;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.manager.SessionState;
import ru.example.jobs.util.Text;

public abstract class Job {

    protected final JobsPlugin plugin;
    private final JobType type;

    protected Job(JobsPlugin plugin, JobType type) {
        this.plugin = plugin;
        this.type = type;
    }

    public JobType type() {
        return type;
    }

    public Component displayName() {
        return Text.mm(plugin.config().jobDisplayName(type));
    }

    public String plainDisplayName() {
        return Text.plain(displayName());
    }

    public abstract void onStart(Player player, SessionState session);

    public abstract void onStop(Player player, SessionState session, JobStopReason reason);

    public abstract void onQuit(Player player, SessionState session);

    public abstract void onJoin(Player player, SessionState session);

    public abstract int progress(Player player, SessionState session);

    public void tickBossBar(Player player, SessionState session) {
    }
}
