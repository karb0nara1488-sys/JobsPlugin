package ru.example.jobs.job;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.manager.CarryState;
import ru.example.jobs.manager.PlayerProfile;
import ru.example.jobs.manager.SessionState;
import ru.example.jobs.util.ItemStackSerializer;
import ru.example.jobs.util.Text;

import java.util.Arrays;
import java.util.Map;
import java.util.UUID;

public final class LoaderJob extends Job {

    public LoaderJob(JobsPlugin plugin) {
        super(plugin, JobType.LOADER);
    }

    @Override
    public void onStart(Player player, SessionState session) {
        clearStoredCarry(player);
        
        showBossBar(player, session);
        updateBossBar(player, session);
    }

    @Override
    public void onStop(Player player, SessionState session, JobStopReason reason) {
        cancelLift(session);
        returnCarriedBlock(player, session);
        clearStoredCarry(player);
        removeSlowness(player);
        hideBossBar(player, session);
    }

    @Override
    public void onJoin(Player player, SessionState session) {
        
        cancelLift(session);
        PlayerProfile profile = plugin.playerDataManager().getOrLoad(player);
        CarryState carry = profile.carry();
        if (carry != null && carry.job() == JobType.LOADER) {
            session.setCarrying(true);
            session.setCarriedBlockId(carry.cargoId());
            session.setCarriedOrigin(carry.origin());

            ItemStack[] saved = ItemStackSerializer.decode(carry.inventorySnapshotBase64());
            if (saved != null) {
                player.getInventory().setContents(saved);
            }
        }
        
        if (session.carrying()) {
            applyCarryInventory(player, session, session.carriedBlockId());
            if (carry != null) {
                carry.inventorySnapshotBase64(ItemStackSerializer.encode(session.inventorySnapshot()));
                profile.markDirty();
                plugin.playerDataManager().saveIfDirty(profile);
            }
            applySlowness(player);
        } else {
            restoreCarryInventory(player, session);
            removeSlowness(player);
        }
        showBossBar(player, session);
        updateBossBar(player, session);
    }

    @Override
    public void onQuit(Player player, SessionState session) {
        cancelLift(session);

        restoreCarryInventory(player, session);
        removeSlowness(player);
        hideBossBar(player, session);
    }

    @Override
    public int progress(Player player, SessionState session) {
        if (session.lifting()) {
            long elapsed = System.currentTimeMillis() - session.liftStartMillis();
            long duration = Math.max(1L, session.liftDurationMillis());
            return (int) Math.min(100L, Math.max(0L, elapsed * 100L / duration));
        }
        return session.carrying() ? 100 : 0;
    }

    @Override
    public void tickBossBar(Player player, SessionState session) {
        updateBossBar(player, session);
    }

    private String resolveCargoId(Block block) {
        String tracked = plugin.cargoTracker().cargoIdAt(block);
        if (tracked != null) {
            return tracked;
        }
        if (!plugin.config().loaderRequirePlacedCargo() || plugin.contentManager().isNexoAvailable()) {
            return plugin.contentManager().blockId(block);
        }
        return null;
    }

    public boolean startPickup(Player player, Block block) {
        SessionState session = plugin.jobManager().session(player);
        if (session.lifting()) {
            plugin.messages().send(player, "lifting");
            return true;
        }
        if (session.carrying()) {
            plugin.messages().send(player, "already-carrying");
            return true;
        }
        String blockId = resolveCargoId(block);
        LoaderBlockType type = plugin.contentManager().loaderBlock(blockId);
        if (type == null) {
            return false;
        }

        long durationMillis = (long) (plugin.config().loaderPickupSeconds() * 1000L);
        session.setLifting(true);
        session.setLiftStartMillis(System.currentTimeMillis());
        session.setLiftDurationMillis(Math.max(1L, durationMillis));
        session.setLiftBlockId(blockId);
        session.setLiftTarget(block.getLocation().clone());
        session.setLiftOrigin(player.getLocation().clone());

        player.sendActionBar(plugin.messages().component("lifting", Map.of(), false));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.6F, 1.2F);

        long ticks = Math.max(1L, Math.round(plugin.config().loaderPickupSeconds() * 20.0D));
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> completePickup(player, session), ticks);
        session.setLiftTask(task);
        return true;
    }

    private void completePickup(Player player, SessionState session) {
        if (!player.isOnline() || !session.lifting()) {
            return;
        }
        Location targetLocation = session.liftTarget();
        String expectedId = session.liftBlockId();
        session.setLiftTask(null);

        if (targetLocation == null || targetLocation.getWorld() == null) {
            clearLift(session);
            return;
        }
        Block target = targetLocation.getBlock();
        String actualId = plugin.cargoTracker().cargoIdAt(target);
        if (actualId == null) {
            actualId = plugin.contentManager().blockId(target);
        }
        if (actualId == null || !expectedId.equals(actualId)) {
            clearLift(session);
            plugin.messages().send(player, "block-missing");
            return;
        }
        if (!plugin.contentManager().removeBlock(target)) {
            clearLift(session);
            plugin.messages().send(player, "block-missing");
            return;
        }

        session.setLifting(false);
        session.setCarrying(true);
        session.setCarriedBlockId(expectedId);
        session.setCarriedOrigin(targetLocation.clone());
        session.setLiftBlockId(null);
        session.setLiftTarget(null);
        session.setLiftOrigin(null);
        applySlowness(player);
        
        applyCarryInventory(player, session, expectedId);

        LoaderBlockType type = plugin.contentManager().loaderBlock(expectedId);
        String blockName = type == null ? expectedId : type.plainName();
        PlayerProfile profile = plugin.playerDataManager().getOrLoad(player);
        CarryState carry = new CarryState(JobType.LOADER, expectedId, blockName,
                session.carriedOrigin());
        
        carry.inventorySnapshotBase64(ItemStackSerializer.encode(session.inventorySnapshot()));
        profile.carry(carry);
        profile.markDirty();
        plugin.playerDataManager().saveIfDirty(profile);
        plugin.messages().send(player, "block-picked", Map.of("%block%", Text.escape(blockName)));
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0F, 1.2F);
    }

    public boolean deliver(Player player) {
        SessionState session = plugin.jobManager().session(player);
        if (!session.carrying()) {
            plugin.messages().send(player, "nothing-to-deliver");
            return false;
        }
        LoaderBlockType type = plugin.contentManager().loaderBlock(session.carriedBlockId());
        if (type == null) {
            session.clearCarried();
            plugin.messages().send(player, "nothing-to-deliver");
            return false;
        }
        double reward = type.price() * plugin.config().rewardMultiplier();
        if (!plugin.economyService().available()) {
            plugin.economyService().tryHook();
        }
        if (!plugin.economyService().available()) {
            plugin.messages().send(player, "no-economy");
            return false;
        }
        if (!plugin.economyService().deposit(player, reward)) {
            plugin.messages().send(player, "economy-deposit-failed");
            return false;
        }

        UUID uuid = player.getUniqueId();
        PlayerProfile profile = plugin.playerDataManager().getOrLoad(uuid);
        profile.stats(JobType.LOADER).addDelivered(1);
        profile.stats(JobType.LOADER).addEarned(reward);
        profile.carry(null);
        plugin.playerDataManager().markDirty(uuid);
        plugin.playerDataManager().saveIfDirty(profile);

        session.clearCarried();
        removeSlowness(player);
        restoreCarryInventory(player, session);
        plugin.messages().send(player, "block-delivered",
                Map.of("%amount%", Text.escape(plugin.economyService().format(reward)),
                        "%currency%", Text.escape(plugin.economyService().currencyName())));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.9F, 1.3F);
        return true;
    }

    public void cancelJob(Player player) {
        plugin.jobManager().stopJob(player, JobStopReason.CANCELLED);
    }

    public boolean isCarrying(Player player) {
        SessionState session = plugin.jobManager().sessionIfPresent(player);
        return session != null && session.carrying();
    }

    public boolean returnBlock(Player player) {
        SessionState session = plugin.jobManager().sessionIfPresent(player);
        return session != null && returnCarriedBlock(player, session);
    }

    private boolean returnCarriedBlock(Player player, SessionState session) {
        if (!session.carrying()) {
            return true;
        }
        String id = session.carriedBlockId();
        Location origin = session.carriedOrigin();
        if (origin == null || origin.getWorld() == null) {
            session.clearCarried();
            return true;
        }

        Location destination = findFreeSpot(origin);
        if (destination != null && plugin.contentManager().placeBlock(id, destination)) {
            session.clearCarried();
            clearStoredCarry(player);
            restoreCarryInventory(player, session);
            removeSlowness(player);
            plugin.messages().send(player, "block-returned");
            player.playSound(player.getLocation(), Sound.BLOCK_WOOD_PLACE, 0.8F, 1.0F);
            return true;
        }
        plugin.getLogger().warning("Не удалось вернуть блок " + id + " для игрока " + player.getName());
        session.clearCarried();
        clearStoredCarry(player);
        restoreCarryInventory(player, session);
        LoaderBlockType type = plugin.contentManager().loaderBlock(id);
        if (type != null && type.fallbackMaterial() != null && type.fallbackMaterial().isItem()) {
            ItemStack item = new ItemStack(type.fallbackMaterial());
            for (ItemStack overflow : player.getInventory().addItem(item).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), overflow);
            }
        }
        removeSlowness(player);
        plugin.messages().send(player, "cargo-return-failed");
        return true;
    }

    private void clearStoredCarry(Player player) {
        PlayerProfile profile = plugin.playerDataManager().getOrLoad(player);
        if (profile.carry() != null) {
            profile.carry(null);
            profile.markDirty();
            plugin.playerDataManager().saveIfDirty(profile);
        }
    }

    private Location findFreeSpot(Location origin) {        if (origin.getBlock().getType().isAir()) {
            return origin;
        }
        for (int radius = 1; radius <= 3; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    Location candidate = origin.clone().add(dx, 0, dz);
                    if (candidate.getBlock().getType().isAir()) {
                        return candidate;
                    }
                }
            }
        }
        for (int dy = 1; dy <= 2; dy++) {
            Location candidate = origin.clone().add(0, dy, 0);
            if (candidate.getBlock().getType().isAir()) {
                return candidate;
            }
        }
        return null;
    }

    private void applyCarryInventory(Player player, SessionState session, String cargoId) {
        if (session.inventoryReplaced()) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        ItemStack[] contents = inventory.getContents();
        session.setInventorySnapshot(contents);
        ItemStack filler = cargoItem(cargoId);
        ItemStack[] filled = new ItemStack[contents.length];
        Arrays.fill(filled, filler);
        inventory.setContents(filled);
    }

    private void restoreCarryInventory(Player player, SessionState session) {
        if (!session.inventoryReplaced()) {
            return;
        }
        player.getInventory().setContents(session.inventorySnapshot());
        session.clearInventorySnapshot();
    }

    private ItemStack cargoItem(String cargoId) {
        LoaderBlockType type = plugin.contentManager().loaderBlock(cargoId);
        Material material = type == null ? Material.BARREL : type.fallbackMaterial();
        if (material == null || material.isAir() || !material.isItem()) {
            material = Material.BARREL;
        }
        return new ItemStack(material, Math.max(1, material.getMaxStackSize()));
    }

    public void cancelCarryOnDeath(Player player, SessionState session) {
        cancelLift(session);
        if (session.carrying()) {
            String id = session.carriedBlockId();
            Location origin = session.carriedOrigin();
            Location destination = origin == null ? null : findFreeSpot(origin);
            if (destination == null) {
                destination = findFreeSpot(player.getLocation());
            }
            if (id != null && destination != null) {
                plugin.contentManager().placeBlock(id, destination);
            }
        }
        session.clearCarried();
        session.clearInventorySnapshot();
        clearStoredCarry(player);
        removeSlowness(player);
        hideBossBar(player, session);
    }

    private void applySlowness(Player player) {
        if (!plugin.config().slownessEnabled()) {
            return;
        }
        int amplifier = plugin.config().loaderSlownessAmplifier();
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                PotionEffect.INFINITE_DURATION, amplifier, false, false, false));
    }

    private void removeSlowness(Player player) {
        player.removePotionEffect(PotionEffectType.SLOWNESS);
    }

    private void showBossBar(Player player, SessionState session) {
        if (session.bossBar() != null) {
            return;
        }
        BossBar bar = BossBar.bossBar(Text.mm(""), 1.0F,
                plugin.config().loaderBossBarColor(), plugin.config().loaderBossBarOverlay());
        player.showBossBar(bar);
        session.setBossBar(bar);
    }

    private void updateBossBar(Player player, SessionState session) {
        showBossBar(player, session);
        BossBar bar = session.bossBar();
        if (bar == null) {
            return;
        }

        float barProgress;
        String template;
        String blockId;
        if (session.lifting()) {
            template = plugin.config().loaderBossBar("lifting");
            long elapsed = System.currentTimeMillis() - session.liftStartMillis();
            long duration = Math.max(1L, session.liftDurationMillis());
            barProgress = (float) Math.min(1.0D, Math.max(0.0D, elapsed / (double) duration));
            blockId = session.liftBlockId();
        } else if (session.carrying()) {
            template = plugin.config().loaderBossBar("carrying");
            barProgress = 1.0F;
            blockId = session.carriedBlockId();
        } else {
            template = plugin.config().loaderBossBar("idle");
            barProgress = 1.0F;
            blockId = null;
        }

        LoaderBlockType type = plugin.contentManager().loaderBlock(blockId);
        String blockName = type == null ? "?" : type.plainName();
        String hint = plugin.config().loaderBossBar("hint");
        int percent = Math.round(Math.max(0.0F, Math.min(1.0F, barProgress)) * 100.0F);
        Component name = Text.mm(template + " " + hint,
                Map.of("%name%", Text.escape(blockName),
                        "%block%", Text.escape(blockName),
                        "%progress%", String.valueOf(percent)));
        bar.name(name);
        bar.progress(barProgress);
        bar.color(plugin.config().loaderBossBarColor());
    }

    private void hideBossBar(Player player, SessionState session) {
        BossBar bar = session.bossBar();
        if (bar != null) {
            player.hideBossBar(bar);
            session.setBossBar(null);
        }
    }

    private void cancelLift(SessionState session) {
        BukkitTask task = session.liftTask();
        if (task != null) {
            task.cancel();
        }
        clearLift(session);
    }

    private void clearLift(SessionState session) {
        session.setLifting(false);
        session.setLiftTask(null);
        session.setLiftBlockId(null);
        session.setLiftTarget(null);
        session.setLiftOrigin(null);
    }
}
