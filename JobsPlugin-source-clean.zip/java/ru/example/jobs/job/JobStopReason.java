package ru.example.jobs.job;

public enum JobStopReason {
    GUI,
    CANCELLED
}
