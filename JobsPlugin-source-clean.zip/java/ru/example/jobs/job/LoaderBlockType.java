package ru.example.jobs.job;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import ru.example.jobs.config.CargoDefinition;
import ru.example.jobs.util.Text;

public final class LoaderBlockType {

    private final String id;
    private final String displayName;
    private final double price;
    private final Material fallbackMaterial;
    private final String nexoId;

    public LoaderBlockType(String id, String displayName, double price, Material fallbackMaterial) {
        this(id, displayName, price, fallbackMaterial, id);
    }

    public LoaderBlockType(String id, String displayName, double price, Material fallbackMaterial, String nexoId) {
        this.id = id;
        this.displayName = displayName;
        this.price = price;
        this.fallbackMaterial = fallbackMaterial;
        this.nexoId = nexoId;
    }

    public static LoaderBlockType from(CargoDefinition cargo) {
        return new LoaderBlockType(cargo.id(), cargo.displayName(), cargo.price(),
                cargo.fallbackMaterial(), cargo.nexoId());
    }

    public String id() {
        return id;
    }

    public String displayName() {
        return displayName;
    }

    public Component nameComponent() {
        return Text.mm(displayName);
    }

    public String plainName() {
        return Text.plain(nameComponent());
    }

    public double price() {
        return price;
    }

    public Material fallbackMaterial() {
        return fallbackMaterial;
    }

    public String nexoId() {
        return nexoId;
    }
}
