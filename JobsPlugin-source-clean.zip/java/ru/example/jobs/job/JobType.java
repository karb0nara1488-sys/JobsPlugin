package ru.example.jobs.job;

import java.util.Locale;

public enum JobType {
    LOADER("loader", "delivered"),
    FARMER("farmer", "collected");

    private final String id;
    private final String counterKey;

    JobType(String id, String counterKey) {
        this.id = id;
        this.counterKey = counterKey;
    }

    public String id() {
        return id;
    }

    public String counterKey() {
        return counterKey;
    }

    public static JobType fromId(String id) {
        if (id == null) {
            return null;
        }
        String normalized = id.toLowerCase(Locale.ROOT);
        for (JobType type : values()) {
            if (type.id.equals(normalized)) {
                return type;
            }
        }
        return null;
    }

    public static JobType fromNpcId(String npcId) {
        if (npcId == null) {
            return null;
        }
        if (npcId.startsWith("gruzchik")) {
            return LOADER;
        }
        if (npcId.startsWith("fermer")) {
            return FARMER;
        }
        return null;
    }
}
