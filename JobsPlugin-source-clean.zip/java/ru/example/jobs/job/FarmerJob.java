package ru.example.jobs.job;

import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.field.CropType;
import ru.example.jobs.field.FieldCrop;
import ru.example.jobs.manager.SessionState;
import ru.example.jobs.util.Text;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class FarmerJob extends Job {

    public FarmerJob(JobsPlugin plugin) {
        super(plugin, JobType.FARMER);
    }

    @Override
    public void onStart(Player player, SessionState session) {
        
        session.clearBag();
    }

    @Override
    public void onStop(Player player, SessionState session, JobStopReason reason) {
        
        session.clearBag();
    }

    @Override
    public void onQuit(Player player, SessionState session) {
        session.clearBag();
    }

    @Override
    public void onJoin(Player player, SessionState session) {
        
        session.clearBag();
    }

    @Override
    public int progress(Player player, SessionState session) {
        Block target = player.getTargetBlockExact(8);
        if (target == null) {
            return 0;
        }
        FieldCrop crop = plugin.fieldManager().cropAt(target.getLocation());
        if (crop == null) {
            return 0;
        }
        return (int) Math.round(plugin.fieldManager().percent(crop));
    }

    public boolean harvest(Player player, Block block) {
        FieldCrop crop = plugin.fieldManager().cropAt(block.getLocation());
        if (crop == null) {
            return false;
        }
        CropType type = plugin.config().crops().get(crop.cropId());
        if (type == null) {
            return false;
        }
        if (!plugin.jobManager().isActive(player, JobType.FARMER)) {
            plugin.messages().send(player, "must-start-job");
            return true;
        }

        int percent = (int) Math.round(plugin.fieldManager().percent(crop));
        int minPercent = plugin.config().farmerMinGrowthPercent();
        if (percent < minPercent) {
            plugin.messages().actionBar(player, "crop-too-young", Map.of(
                    "%percent%", String.valueOf(percent),
                    "%min%", String.valueOf(minPercent)));
            return true;
        }
        if (plugin.config().farmerRequireGrown() && percent < 100) {
            plugin.messages().actionBar(player, "crop-not-grown",
                    Map.of("%percent%", String.valueOf(percent)));
            return true;
        }

        SessionState session = plugin.jobManager().session(player);
        if (session.bagCount() >= plugin.config().farmerBagCapacity()) {
            plugin.messages().send(player, "bag-full");
            return true;
        }

        double unitValue = type.price() * percent / 100.0D;
        if (ThreadLocalRandom.current().nextDouble() < type.bonusChance()) {
            unitValue += type.bonusPrice() * percent / 100.0D;
        }
        session.addHarvest(crop.cropId(), unitValue);
        plugin.fieldManager().resetCrop(crop);

        plugin.messages().send(player, "harvest-added", Map.of(
                "%crop%", Text.escape(type.plainName()),
                "%count%", String.valueOf(session.bagCount())));
        player.playSound(player.getLocation(), Sound.BLOCK_CROP_BREAK, 0.8F, 1.1F);
        return true;
    }

    public boolean deliver(Player player) {
        SessionState session = plugin.jobManager().session(player);
        if (session.harvestBag().isEmpty()) {
            plugin.messages().send(player, "nothing-to-deliver");
            return false;
        }

        int count = session.bagCount();
        double total = session.harvestValue();

        if (count == 0) {
            session.clearBag();
            plugin.messages().send(player, "nothing-to-deliver");
            return false;
        }
        double reward = total * plugin.config().rewardMultiplier();
        if (!plugin.economyService().available()) {
            plugin.economyService().tryHook();
        }
        if (!plugin.economyService().available()) {
            plugin.messages().send(player, "no-economy");
            return false;
        }
        if (!plugin.economyService().deposit(player, reward)) {
            plugin.messages().send(player, "economy-deposit-failed");
            return false;
        }

        UUID uuid = player.getUniqueId();
        plugin.playerDataManager().getOrLoad(uuid).stats(JobType.FARMER).addDelivered(count);
        plugin.playerDataManager().getOrLoad(uuid).stats(JobType.FARMER).addEarned(reward);
        plugin.playerDataManager().markDirty(uuid);

        session.clearBag();
        plugin.messages().send(player, "harvest-delivered", Map.of(
                "%amount%", Text.escape(plugin.economyService().format(reward)),
                "%currency%", Text.escape(plugin.economyService().currencyName()),
                "%count%", String.valueOf(count)));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.9F, 1.3F);
        return true;
    }
}
