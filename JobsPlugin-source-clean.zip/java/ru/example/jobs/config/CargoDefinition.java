package ru.example.jobs.config;

import org.bukkit.Material;

public record CargoDefinition(
        String id,
        String nexoId,
        Material fallbackMaterial,
        Material fallbackIcon,
        String displayName,
        double price
) {
}
