package ru.example.jobs.config;

public record NpcDefinition(String id, String displayName) {
}
