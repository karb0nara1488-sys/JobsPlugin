package ru.example.jobs.config;

import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import ru.example.jobs.util.Text;

import java.util.Collections;
import java.util.Map;

public final class Messages {

    private final JavaPlugin plugin;
    private String prefix = "";

    public Messages(JavaPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        prefix = plugin.getConfig().getString("messages.prefix", "");
    }

    public String raw(String key) {
        return plugin.getConfig().getString("messages." + key,
                "<red>Сообщение не найдено: " + key + "</red>");
    }

    public String prefix() {
        return prefix;
    }

    public Component component(String key, Map<String, String> placeholders, boolean withPrefix) {
        String value = (withPrefix ? prefix : "") + raw(key);
        return Text.mm(value, placeholders);
    }

    public void send(CommandSender sender, String key) {
        send(sender, key, Collections.emptyMap());
    }

    public void send(CommandSender sender, String key, Map<String, String> placeholders) {
        sender.sendMessage(component(key, placeholders, true));
    }

    public void sendRaw(CommandSender sender, String key, Map<String, String> placeholders) {
        sender.sendMessage(component(key, placeholders, false));
    }

    public void actionBar(Player player, String key, Map<String, String> placeholders) {
        player.sendActionBar(component(key, placeholders, false));
    }
}
