package ru.example.jobs.config;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.LinkedHashMap;
import java.util.Map;

public record NpcLocation(String world, double x, double y, double z, float yaw, float pitch) {

    public static NpcLocation of(Location location) {
        return new NpcLocation(location.getWorld().getName(), location.getX(), location.getY(),
                location.getZ(), location.getYaw(), location.getPitch());
    }

    public static NpcLocation fromSection(ConfigurationSection section) {
        if (section == null) {
            return null;
        }
        String world = section.getString("world");
        if (world == null || world.isBlank()) {
            return null;
        }
        return new NpcLocation(world, section.getDouble("x"), section.getDouble("y"),
                section.getDouble("z"), (float) section.getDouble("yaw"),
                (float) section.getDouble("pitch"));
    }

    public static NpcLocation fromMap(Map<?, ?> map) {
        if (map == null) {
            return null;
        }
        Object world = map.get("world");
        if (!(world instanceof String name) || name.isBlank()) {
            return null;
        }
        return new NpcLocation(name, number(map.get("x")), number(map.get("y")), number(map.get("z")),
                (float) number(map.get("yaw")), (float) number(map.get("pitch")));
    }

    private static double number(Object value) {
        return value instanceof Number number ? number.doubleValue() : 0.0D;
    }

    public Map<String, Object> serialize() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("world", world);
        map.put("x", x);
        map.put("y", y);
        map.put("z", z);
        map.put("yaw", yaw);
        map.put("pitch", pitch);
        return map;
    }

    public Location resolve() {
        World bukkitWorld = Bukkit.getWorld(world);
        return bukkitWorld == null ? null : new Location(bukkitWorld, x, y, z, yaw, pitch);
    }

    public double distanceSquared(Location other) {
        Location resolved = resolve();
        if (resolved == null || other == null || other.getWorld() == null
                || !resolved.getWorld().equals(other.getWorld())) {
            return -1.0D;
        }
        return resolved.distanceSquared(other);
    }
}
