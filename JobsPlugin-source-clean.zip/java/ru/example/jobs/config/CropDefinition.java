package ru.example.jobs.config;

import org.bukkit.Material;

import java.util.List;

public record CropDefinition(
        String id,
        String displayName,
        long growthSeconds,
        int weight,
        double price,
        double bonusChance,
        double bonusPrice,
        List<String> nexoStages,
        List<CropStage> fallbackStages,
        Material fallbackIcon
) {

    public int stageCount() {
        return Math.max(1, Math.max(nexoStages.size(), fallbackStages.size()));
    }

    public int stageIndex(int percent) {
        int count = stageCount();
        int clamped = Math.max(0, Math.min(100, percent));
        if (clamped >= 100) {
            return count - 1;
        }
        return Math.min(count - 1, clamped * count / 100);
    }

    public String nexoStage(int index) {
        if (nexoStages.isEmpty()) {
            return id;
        }
        return nexoStages.get(Math.max(0, Math.min(nexoStages.size() - 1, index)));
    }

    public CropStage fallbackStage(int index) {
        if (fallbackStages.isEmpty()) {
            return new CropStage(Material.WHEAT, 0);
        }
        return fallbackStages.get(Math.max(0, Math.min(fallbackStages.size() - 1, index)));
    }
}
