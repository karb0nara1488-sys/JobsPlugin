package ru.example.jobs.config;

import org.bukkit.Material;

import java.util.List;

public record GuiButton(int slot, Material material, String name, List<String> lore, String job) {

    public GuiButton(int slot, Material material, String name, List<String> lore) {
        this(slot, material, name, lore, null);
    }
}
