package ru.example.jobs.config;

import org.bukkit.Material;

public record CropStage(Material material, int age) {
}
