package ru.example.jobs.config;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.field.CropType;
import ru.example.jobs.job.JobType;
import ru.example.jobs.job.LoaderBlockType;
import ru.example.jobs.npc.NpcType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class PluginConfig {

    private final JobsPlugin plugin;
    private FileConfiguration raw;

    private int saveIntervalSeconds;
    private int timeFlushSeconds;
    private boolean backupBeforeSave;

    private String currencyFallback;
    private double rewardMultiplier;
    private boolean economyEnabled;
    private String economyProviderMode;
    private int economyRetryTicks;
    private int economyRetryAttempts;
    private String timeFormat;

    private int bossBarUpdateTicks;
    private BossBar.Color loaderBossBarColor;
    private BossBar.Overlay loaderBossBarOverlay;
    private BossBar.Color farmerBossBarColor;
    private BossBar.Overlay farmerBossBarOverlay;
    private String loaderBossBarIdle;
    private String loaderBossBarPickup;
    private String loaderBossBarCarrying;
    private String farmerBossBarCarrying;

    private String loaderDisplayName;
    private double loaderPickupSeconds;
    private boolean loaderCancelOnSneak;
    private double loaderCancelDistance;
    private boolean slownessEnabled;
    private int slownessAmplifier;
    private boolean loaderFreezeOnPickup;
    private boolean loaderProtectBlocks;
    private boolean loaderRequirePlacedCargo;
    private String loaderProtectBypassPermission;
    private Material loaderMarkerMaterial;
    private String loaderMarkerName;
    private List<String> loaderMarkerLore;
    private int barrelsDefaultCount;
    private int barrelsMaxCount;
    private int barrelsDistance;
    private int barrelsLayers;
    private String barrelsBlockId;

    private String farmerDisplayName;
    private boolean farmerRequireFullGrowth;
    private int farmerMinGrowthPercent;
    private int farmerBagCapacity;
    private Material farmerMarkerMaterial;
    private String farmerMarkerName;
    private List<String> farmerMarkerLore;

    private int fieldMaxSize;
    private int plantStep;
    private int displayMax;
    private int displayUpdateTicks;
    private double displayYOffset;
    private double displayViewRange;
    private boolean updateBlockStages;
    private String fieldDisplayFormat;
    private List<Material> groundMaterials;

    private String contentProviderMode;

    private String guiTitle;
    private List<Material> guiFillerMaterials;
    private GuiButton startButton;
    private GuiButton stopButton;
    private GuiButton stopOtherButton;
    private GuiButton infoButton;
    private List<GuiButton> decorativeItems;
    private Map<String, Material> jobIcons;

    private String educationDefault;
    private String prefix;
    private final Map<String, String> messages = new LinkedHashMap<>();

    private final Map<String, CargoDefinition> cargoMap = new LinkedHashMap<>();
    private final Map<String, CropDefinition> cropMap = new LinkedHashMap<>();
    private final Map<String, NpcDefinition> npcMap = new LinkedHashMap<>();

    private Map<String, LoaderBlockType> loaderBlockView;
    private Map<String, CropType> cropView;

    public PluginConfig(JobsPlugin plugin) {
        this.plugin = plugin;
        this.raw = plugin.getConfig();
        parse();
    }

    public void reload() {
        plugin.reloadConfig();
        this.raw = plugin.getConfig();
        parse();
    }

    private void parse() {
        saveIntervalSeconds = intValue("storage.save-interval-seconds", 300);
        timeFlushSeconds = intValue("storage.time-flush-seconds", 60);
        backupBeforeSave = boolValue("storage.backup-before-save", true);

        currencyFallback = stringValue("economy.currency-fallback", "монет");
        rewardMultiplier = doubleValue("economy.reward-multiplier", 1.0);
        economyProviderMode = parseEconomyMode(stringValue("economy.provider", "auto"));
        economyEnabled = !"none".equals(economyProviderMode);
        economyRetryTicks = Math.max(1, intValue("economy.retry-ticks", 40));
        economyRetryAttempts = Math.max(0, intValue("economy.retry-attempts", 30));
        timeFormat = stringValue("time.format", "auto");

        bossBarUpdateTicks = Math.max(1, intValue("bossbar.update-ticks", 2));
        loaderBossBarColor = bossBarColor("bossbar.loader.color", BossBar.Color.YELLOW);
        loaderBossBarOverlay = bossBarOverlay("bossbar.loader.overlay", BossBar.Overlay.PROGRESS);
        farmerBossBarColor = bossBarColor("bossbar.farmer.color", BossBar.Color.GREEN);
        farmerBossBarOverlay = bossBarOverlay("bossbar.farmer.overlay", BossBar.Overlay.PROGRESS);
        loaderBossBarPickup = stringValue("bossbar.loader.pickup", "<gold>Перетаскиваю блок... <progress>%");
        loaderBossBarIdle = stringValue("bossbar.loader.idle", "<gold>Грузчик: возьмите блок</gold>");
        loaderBossBarCarrying = stringValue("bossbar.loader.carrying", "<gold>Несу блок: <name>");
        farmerBossBarCarrying = stringValue("bossbar.farmer.carrying", "<green>Несу урожай: <name>");

        loaderDisplayName = stringValue("jobs.loader.display-name", "Грузчик");
        loaderPickupSeconds = Math.max(0.1, doubleValue("jobs.loader.pickup-seconds", 3.0));
        loaderCancelOnSneak = boolValue("jobs.loader.cancel-pickup-on-sneak", true);
        loaderCancelDistance = Math.max(1.0, doubleValue("jobs.loader.pickup-cancel-distance", 8.0));
        slownessEnabled = boolValue("jobs.loader.slowness.enabled", true);
        slownessAmplifier = Math.max(0, intValue("jobs.loader.slowness.amplifier", 3));
        loaderFreezeOnPickup = boolValue("jobs.loader.freeze-on-pickup", true);
        loaderProtectBlocks = boolValue("jobs.loader.protect-blocks", true);
        loaderRequirePlacedCargo = boolValue("jobs.loader.require-placed-cargo", true);
        loaderProtectBypassPermission = stringValue("jobs.loader.protect-bypass-permission", "jobs.admin");
        loaderMarkerMaterial = material("jobs.loader.marker.material", Material.PAPER);
        loaderMarkerName = stringValue("jobs.loader.marker.name", "<gold>Груз: <name>");
        loaderMarkerLore = stringList("jobs.loader.marker.lore", List.of("<gray>Сдайте груз NPC.</gray>"));
        barrelsMaxCount = Math.max(1, intValue("jobs.loader.barrels.max-count", 1000));
        barrelsDefaultCount = Math.min(barrelsMaxCount,
                Math.max(1, intValue("jobs.loader.barrels.default-count", 50)));
        barrelsDistance = Math.max(1, intValue("jobs.loader.barrels.distance", 5));
        barrelsLayers = Math.max(1, intValue("jobs.loader.barrels.layers", 3));
        barrelsBlockId = stringValue("jobs.loader.barrels.block.id",
                stringValue("jobs.loader.barrels.cargo-id", "jobs_barrel"));

        farmerDisplayName = stringValue("jobs.farmer.display-name", "Фермер");
        farmerRequireFullGrowth = boolValue("jobs.farmer.require-full-growth", false);
        farmerMinGrowthPercent = Math.max(0, Math.min(100,
                intValue("jobs.farmer.min-growth-percent", 25)));
        farmerBagCapacity = Math.max(1, intValue("jobs.farmer.bag-capacity", 64));
        farmerMarkerMaterial = material("jobs.farmer.marker.material", Material.PAPER);
        farmerMarkerName = stringValue("jobs.farmer.marker.name", "<green>Урожай: <name>");
        farmerMarkerLore = stringList("jobs.farmer.marker.lore", List.of("<gray>Сдайте урожай NPC.</gray>"));

        fieldMaxSize = Math.max(1, intValue("jobs.farmer.field.max-size", 150));
        plantStep = Math.max(1, intValue("jobs.farmer.field.plant-step", 1));
        displayMax = Math.max(0, intValue("jobs.farmer.field.display.max", 4000));
        displayUpdateTicks = Math.max(1, intValue("jobs.farmer.field.display.update-ticks", 20));
        displayYOffset = Math.max(0.0, doubleValue("jobs.farmer.field.display.y-offset", 1.2));
        displayViewRange = (float) Math.max(1.0, doubleValue("jobs.farmer.field.display.view-range", 48.0));
        updateBlockStages = boolValue("jobs.farmer.field.display.update-block-stages", true);
        fieldDisplayFormat = stringValue("jobs.farmer.field.display.format", "<name> <gray>(<percent>%)</gray>");
        groundMaterials = materials("jobs.farmer.field.ground-materials",
                List.of(Material.DIRT, Material.GRASS_BLOCK, Material.PODZOL,
                        Material.COARSE_DIRT, Material.ROOTED_DIRT));

        contentProviderMode = stringValue("content.provider", "auto").toLowerCase(Locale.ROOT);

        guiTitle = stringValue("gui.title", "<gold>Работа: <job>");
        guiFillerMaterials = materials("gui.filler-materials",
                List.of(Material.GRAY_STAINED_GLASS_PANE, Material.BLACK_STAINED_GLASS_PANE));
        startButton = guiButton("gui.start", 13, Material.LIME_DYE, "<green>Начать работу</green>",
                List.of("<gray>Нажмите, чтобы начать</gray>"));
        stopButton = guiButton("gui.stop", 13, Material.RED_DYE, "<red>Закончить работу</red>",
                List.of("<gray>Нажмите, чтобы закончить</gray>"));
        stopOtherButton = guiButton("gui.stop-other", 13, Material.GRAY_DYE, "<gray>Закончить работу</gray>",
                List.of("<red>Вы уже работаете: <active_job></red>"));
        infoButton = guiButton("gui.info", 15, Material.BOOK, "<gold>Инфо</gold>",
                List.of("<gray>Перенесено/собрано: <count></gray>"));
        decorativeItems = parseDecorative();
        jobIcons = parseJobIcons();

        educationDefault = stringValue("placeholders.education-default", "none");

        parseMessages();
        parseCargos();
        parseCrops();
        parseNpcs();
        loaderBlockView = null;
        cropView = null;

        if (cropMap.isEmpty()) {
            plugin.getLogger().warning("В config.yml не найдено ни одной культуры (jobs.farmer.crops). Фермер не сможет создавать поля.");
        }
    }

    private void parseCargos() {
        cargoMap.clear();
        ConfigurationSection section = raw.getConfigurationSection("jobs.loader.cargo");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                String base = "jobs.loader.cargo." + id;
                String displayName = raw.getString(base + ".display-name", id);
                double price = Math.max(0.0, raw.getDouble(base + ".price", 0.0));
                String contentBase = "content.cargo." + id;
                String nexoId = raw.getString(contentBase + ".nexo-id", id);
                Material fallback = material(contentBase + ".fallback-material", Material.PAPER);
                Material icon = material(contentBase + ".fallback-icon", fallback);
                cargoMap.put(id, new CargoDefinition(id, nexoId, fallback, icon, displayName, price));
            }
        }
        registerBarrelsBlock();
    }

    private void registerBarrelsBlock() {
        ConfigurationSection block = raw.getConfigurationSection("jobs.loader.barrels.block");
        if (block == null) {
            return;
        }
        String id = block.getString("id", barrelsBlockId == null ? "jobs_barrel" : barrelsBlockId);
        if (id == null || id.isBlank()) {
            return;
        }
        String displayName = block.getString("display-name", id);
        double price = Math.max(0.0, block.getDouble("price", 0.0));
        String nexoId = block.getString("nexo-id", id);
        Material fallback = material("jobs.loader.barrels.block.fallback-material", Material.BARREL);
        Material icon = material("jobs.loader.barrels.block.fallback-icon", fallback);
        cargoMap.put(id, new CargoDefinition(id, nexoId, fallback, icon, displayName, price));
        barrelsBlockId = id;
    }

    private void parseCrops() {
        cropMap.clear();
        ConfigurationSection section = raw.getConfigurationSection("jobs.farmer.crops");
        if (section == null) {
            return;
        }
        for (String id : section.getKeys(false)) {
            String base = "jobs.farmer.crops." + id;
            String displayName = raw.getString(base + ".display-name", id);
            long growthSeconds = Math.max(1L, raw.getLong(base + ".growth-seconds", 180L));
            int weight = Math.max(1, raw.getInt(base + ".weight", 10));
            double price = Math.max(0.0, raw.getDouble(base + ".price", 0.0));
            double bonusChance = clamp(raw.getDouble(base + ".bonus-chance", 0.0), 0.0, 1.0);
            double bonusPrice = Math.max(0.0, raw.getDouble(base + ".bonus-price", 0.0));

            String contentBase = "content.crops." + id;
            List<String> nexoStages = new ArrayList<>(raw.getStringList(contentBase + ".nexo-stages"));
            if (nexoStages.isEmpty()) {
                nexoStages.add(id);
            }
            List<CropStage> fallbackStages = new ArrayList<>();
            for (Map<?, ?> map : raw.getMapList(contentBase + ".fallback-stages")) {
                String materialName = String.valueOf(map.get("material"));
                Material material = Material.matchMaterial(materialName);
                if (material == null) {
                    plugin.getLogger().warning("Неизвестный fallback-материал культуры " + id + ": " + materialName);
                    continue;
                }
                int age = asInt(map.get("age"), 0);
                fallbackStages.add(new CropStage(material, Math.max(0, age)));
            }
            if (fallbackStages.isEmpty()) {
                fallbackStages.add(new CropStage(Material.WHEAT, 0));
            }
            Material icon = material(contentBase + ".fallback-icon", fallbackStages.get(0).material());
            cropMap.put(id, new CropDefinition(id, displayName, growthSeconds, weight, price, bonusChance,
                    bonusPrice, List.copyOf(nexoStages), List.copyOf(fallbackStages), icon));
        }
    }

    private void parseNpcs() {
        npcMap.clear();
        ConfigurationSection section = raw.getConfigurationSection("npcs");
        if (section == null) {
            return;
        }
        for (String id : section.getKeys(false)) {
            String displayName = raw.getString("npcs." + id + ".display-name", id);
            npcMap.put(id, new NpcDefinition(id, displayName));
        }
    }

    private void parseMessages() {
        messages.clear();
        ConfigurationSection section = raw.getConfigurationSection("messages");
        if (section != null) {
            flattenMessages("", section);
        }
        prefix = messages.getOrDefault("prefix", "");
    }

    private void flattenMessages(String parent, ConfigurationSection section) {
        for (String key : section.getKeys(false)) {
            String path = parent.isEmpty() ? key : parent + "." + key;
            Object value = section.get(key);
            if (value instanceof ConfigurationSection child) {
                flattenMessages(path, child);
            } else if (value != null) {
                messages.put(path, String.valueOf(value));
            }
        }
    }

    private List<GuiButton> parseDecorative() {
        List<GuiButton> result = new ArrayList<>();
        for (Map<?, ?> map : raw.getMapList("gui.decorative")) {
            int slot = asInt(map.get("slot"), 0);
            if (slot < 0 || slot > 26) {
                continue;
            }
            Material material = Material.matchMaterial(String.valueOf(map.get("material")));
            if (material == null) {
                continue;
            }
            String name = String.valueOf(map.get("name"));
            List<String> lore = new ArrayList<>();
            Object loreObject = map.get("lore");
            if (loreObject instanceof List<?> list) {
                for (Object line : list) {
                    lore.add(String.valueOf(line));
                }
            }
            result.add(new GuiButton(slot, material, name, List.copyOf(lore), decorativeJob(map)));
        }
        return result;
    }

    private String decorativeJob(Map<?, ?> map) {
        Object job = map.get("job");
        if (job == null) {
            return null;
        }
        String value = String.valueOf(job).trim();
        return value.isEmpty() ? null : value.toLowerCase(Locale.ROOT);
    }

    private Map<String, Material> parseJobIcons() {
        Map<String, Material> icons = new LinkedHashMap<>();
        icons.put("loader", material("gui.job-icons.loader", Material.CHEST));
        icons.put("farmer", material("gui.job-icons.farmer", Material.HAY_BLOCK));
        return icons;
    }

    private GuiButton guiButton(String path, int defaultSlot, Material defaultMaterial, String defaultName, List<String> defaultLore) {
        int slot = intValue(path + ".slot", defaultSlot);
        slot = Math.max(0, Math.min(26, slot));
        Material material = material(path + ".material", defaultMaterial);
        String name = stringValue(path + ".name", defaultName);
        List<String> lore = raw.getStringList(path + ".lore");
        if (lore.isEmpty() && !raw.contains(path + ".lore")) {
            lore = defaultLore;
        }
        return new GuiButton(slot, material, name, List.copyOf(lore));
    }

    public void addNpcLocation(String id, Location location) {
        List<NpcLocation> locations = new ArrayList<>(npcLocations(id));
        locations.add(NpcLocation.of(location));
        writeNpcLocations(id, locations);
    }

    public boolean removeNpcLocation(String id, Location near, double maxDistance) {
        List<NpcLocation> locations = new ArrayList<>(npcLocations(id));
        int bestIndex = -1;
        double bestDistance = maxDistance * maxDistance;
        for (int i = 0; i < locations.size(); i++) {
            double distance = locations.get(i).distanceSquared(near);
            if (distance >= 0.0D && distance <= bestDistance) {
                bestDistance = distance;
                bestIndex = i;
            }
        }
        if (bestIndex < 0) {
            return false;
        }
        locations.remove(bestIndex);
        writeNpcLocations(id, locations);
        return true;
    }

    public void clearNpcLocations(String id) {
        raw.set("npcs." + id + ".location", null);
        raw.set("npcs." + id + ".locations", new ArrayList<>());
        plugin.saveConfig();
    }

    public List<NpcLocation> npcLocations(String id) {
        List<NpcLocation> result = new ArrayList<>();
        for (Map<?, ?> entry : raw.getMapList("npcs." + id + ".locations")) {
            NpcLocation location = NpcLocation.fromMap(entry);
            if (location != null) {
                result.add(location);
            }
        }
        if (result.isEmpty()) {
            NpcLocation legacy = NpcLocation.fromSection(
                    raw.getConfigurationSection("npcs." + id + ".location"));
            if (legacy != null) {
                result.add(legacy);
            }
        }
        return result;
    }

    private void writeNpcLocations(String id, List<NpcLocation> locations) {
        List<Map<String, Object>> serialized = new ArrayList<>(locations.size());
        for (NpcLocation location : locations) {
            serialized.add(location.serialize());
        }
        raw.set("npcs." + id + ".location", null);
        raw.set("npcs." + id + ".locations", serialized);
        plugin.saveConfig();
    }

    private String stringValue(String path, String fallback) {
        String value = raw.getString(path);
        return value == null ? fallback : value;
    }

    private int intValue(String path, int fallback) {
        return raw.getInt(path, fallback);
    }

    private double doubleValue(String path, double fallback) {
        return raw.getDouble(path, fallback);
    }

    private boolean boolValue(String path, boolean fallback) {
        return raw.getBoolean(path, fallback);
    }

    private List<String> stringList(String path, List<String> fallback) {
        if (!raw.contains(path)) {
            return List.copyOf(fallback);
        }
        return List.copyOf(raw.getStringList(path));
    }

    private Material material(String path, Material fallback) {
        String value = raw.getString(path);
        if (value == null || value.isBlank()) {
            return fallback;
        }
        Material material = Material.matchMaterial(value.trim());
        if (material == null) {
            plugin.getLogger().warning("Неизвестный материал в " + path + ": " + value + " (использую " + fallback + ")");
            return fallback;
        }
        return material;
    }

    private List<Material> materials(String path, List<Material> fallback) {
        List<String> names = raw.getStringList(path);
        if (names.isEmpty()) {
            return List.copyOf(fallback);
        }
        List<Material> result = new ArrayList<>();
        for (String name : names) {
            Material material = Material.matchMaterial(name);
            if (material != null) {
                result.add(material);
            }
        }
        return result.isEmpty() ? List.copyOf(fallback) : List.copyOf(result);
    }

    private BossBar.Color bossBarColor(String path, BossBar.Color fallback) {
        String value = raw.getString(path);
        if (value == null) {
            return fallback;
        }
        try {
            return BossBar.Color.valueOf(value.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }

    private BossBar.Overlay bossBarOverlay(String path, BossBar.Overlay fallback) {
        String value = raw.getString(path);
        if (value == null) {
            return fallback;
        }
        try {
            return BossBar.Overlay.valueOf(value.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }

    private static int asInt(Object value, int fallback) {
        if (value instanceof Number number) {
            return number.intValue();
        }
        if (value != null) {
            try {
                return Integer.parseInt(String.valueOf(value));
            } catch (NumberFormatException ignored) {
                return fallback;
            }
        }
        return fallback;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private String parseEconomyMode(String value) {
        String mode = value == null ? "auto" : value.trim().toLowerCase(Locale.ROOT);
        if (mode.equals("auto") || mode.equals("vault") || mode.equals("none")) {
            return mode;
        }
        plugin.getLogger().warning("Неизвестный economy.provider: " + value
                + " (ожидается auto|vault|none). Использую auto.");
        return "auto";
    }

    public FileConfiguration raw() {
        return raw;
    }

    public int saveIntervalSeconds() {
        return saveIntervalSeconds;
    }

    public int timeFlushSeconds() {
        return timeFlushSeconds;
    }

    public boolean backupBeforeSave() {
        return backupBeforeSave;
    }

    public String currencyFallback() {
        return currencyFallback;
    }

    public double rewardMultiplier() {
        return rewardMultiplier;
    }

    public boolean economyEnabled() {
        return economyEnabled;
    }

    public String economyProviderMode() {
        return economyProviderMode;
    }

    public int economyRetryTicks() {
        return economyRetryTicks;
    }

    public int economyRetryAttempts() {
        return economyRetryAttempts;
    }

    public String timeFormat() {
        return timeFormat;
    }

    public int bossBarUpdateTicks() {
        return bossBarUpdateTicks;
    }

    public BossBar.Color loaderBossBarColor() {
        return loaderBossBarColor;
    }

    public BossBar.Overlay loaderBossBarOverlay() {
        return loaderBossBarOverlay;
    }

    public BossBar.Color farmerBossBarColor() {
        return farmerBossBarColor;
    }

    public BossBar.Overlay farmerBossBarOverlay() {
        return farmerBossBarOverlay;
    }

    public String loaderBossBarPickup() {
        return loaderBossBarPickup;
    }

    public String loaderBossBarIdle() {
        return loaderBossBarIdle;
    }

    public String loaderBossBarCarrying() {
        return loaderBossBarCarrying;
    }

    public String farmerBossBarCarrying() {
        return farmerBossBarCarrying;
    }

    public String loaderDisplayName() {
        return loaderDisplayName;
    }

    public double loaderPickupSeconds() {
        return loaderPickupSeconds;
    }

    public boolean loaderCancelOnSneak() {
        return loaderCancelOnSneak;
    }

    public double loaderCancelDistance() {
        return loaderCancelDistance;
    }

    public boolean slownessEnabled() {
        return slownessEnabled;
    }

    public int slownessAmplifier() {
        return slownessAmplifier;
    }

    public boolean loaderFreezeOnPickup() {
        return loaderFreezeOnPickup;
    }

    public boolean loaderProtectBlocks() {
        return loaderProtectBlocks;
    }

    public boolean loaderRequirePlacedCargo() {
        return loaderRequirePlacedCargo;
    }

    public String loaderProtectBypassPermission() {
        return loaderProtectBypassPermission;
    }

    public Material loaderMarkerMaterial() {
        return loaderMarkerMaterial;
    }

    public String loaderMarkerName() {
        return loaderMarkerName;
    }

    public List<String> loaderMarkerLore() {
        return loaderMarkerLore;
    }

    public int barrelsDefaultCount() {
        return barrelsDefaultCount;
    }

    public int barrelsMaxCount() {
        return barrelsMaxCount;
    }

    public int barrelsDistance() {
        return barrelsDistance;
    }

    public int barrelsLayers() {
        return barrelsLayers;
    }

    public String barrelsBlockId() {
        return barrelsBlockId;
    }

    public String farmerDisplayName() {
        return farmerDisplayName;
    }

    public boolean farmerRequireFullGrowth() {
        return farmerRequireFullGrowth;
    }

    public Material farmerMarkerMaterial() {
        return farmerMarkerMaterial;
    }

    public String farmerMarkerName() {
        return farmerMarkerName;
    }

    public List<String> farmerMarkerLore() {
        return farmerMarkerLore;
    }

    public int fieldMaxSize() {
        return fieldMaxSize;
    }

    public int plantStep() {
        return plantStep;
    }

    public int displayMax() {
        return displayMax;
    }

    public int displayUpdateTicks() {
        return displayUpdateTicks;
    }

    public double displayYOffset() {
        return displayYOffset;
    }

    public float displayViewRange() {
        return (float) displayViewRange;
    }

    public boolean updateBlockStages() {
        return updateBlockStages;
    }

    public String contentProviderMode() {
        return contentProviderMode;
    }

    public String guiTitle() {
        return guiTitle;
    }

    public List<Material> guiFillerMaterials() {
        return guiFillerMaterials;
    }

    public GuiButton startButton() {
        return startButton;
    }

    public GuiButton stopButton() {
        return stopButton;
    }

    public GuiButton stopOtherButton() {
        return stopOtherButton;
    }

    public GuiButton infoButton() {
        return infoButton;
    }

    public List<GuiButton> decorativeItems() {
        return decorativeItems;
    }

    public GuiButton decorativeItem(JobType type) {
        return decorationFor(type);
    }

    public Material jobIcon(String jobId) {
        return jobIcons.getOrDefault(jobId, Material.CHEST);
    }

    public String educationDefault() {
        return educationDefault;
    }

    public String prefix() {
        return prefix;
    }

    public String message(String key) {
        return messages.getOrDefault(key, "<red>[Jobs] Нет сообщения: " + key + "</red>");
    }

    public Map<String, CargoDefinition> cargoMap() {
        return Map.copyOf(cargoMap);
    }

    public CargoDefinition cargo(String id) {
        return cargoMap.get(id);
    }

    public Map<String, CropDefinition> cropMap() {
        return Map.copyOf(cropMap);
    }

    public CropDefinition crop(String id) {
        return cropMap.get(id);
    }

    public Map<String, NpcDefinition> npcMap() {
        return Map.copyOf(npcMap);
    }

    public NpcDefinition npc(String id) {
        return npcMap.get(id);
    }

    public Map<String, LoaderBlockType> loaderBlocks() {
        if (loaderBlockView == null) {
            Map<String, LoaderBlockType> view = new LinkedHashMap<>();
            for (CargoDefinition cargo : cargoMap.values()) {
                view.put(cargo.id(), LoaderBlockType.from(cargo));
            }
            loaderBlockView = Map.copyOf(view);
        }
        return loaderBlockView;
    }

    public Map<String, CropType> crops() {
        if (cropView == null) {
            Map<String, CropType> view = new LinkedHashMap<>();
            for (CropDefinition crop : cropMap.values()) {
                view.put(crop.id(), CropType.from(crop));
            }
            cropView = Map.copyOf(view);
        }
        return cropView;
    }

    public int loaderSlownessAmplifier() {
        return slownessAmplifier;
    }

    public String loaderBossBar(String kind) {
        if (kind == null) {
            return "";
        }
        return switch (kind.toLowerCase(Locale.ROOT)) {
            case "lifting", "pickup" -> loaderBossBarPickup;
            case "carrying" -> loaderBossBarCarrying;
            case "idle" -> loaderBossBarIdle;
            default -> "";
        };
    }

    public String jobDisplayName(JobType type) {
        return type == JobType.FARMER ? farmerDisplayName : loaderDisplayName;
    }

    public String statLabel(JobType type) {
        return type == JobType.FARMER ? "Собрано" : "Перенесено";
    }

    public int farmerBagCapacity() {
        return farmerBagCapacity;
    }

    public boolean farmerRequireGrown() {
        return farmerRequireFullGrowth;
    }

    public int farmerMinGrowthPercent() {
        return farmerMinGrowthPercent;
    }

    public int fieldMaxDisplays() {
        return displayMax;
    }

    public double fieldDisplayHeight() {
        return displayYOffset;
    }

    public String fieldDisplayFormat() {
        return fieldDisplayFormat;
    }

    public List<Material> groundMaterials() {
        return groundMaterials;
    }

    public String guiStartName() {
        return startButton.name();
    }

    public List<String> guiStartLore() {
        return startButton.lore();
    }

    public String guiStopName() {
        return stopButton.name();
    }

    public List<String> guiStopLore() {
        return stopButton.lore();
    }

    public String guiStopDisabledName() {
        return stopOtherButton.name();
    }

    public List<String> guiStopDisabledLore() {
        return stopOtherButton.lore();
    }

    public String guiInfoName() {
        return infoButton.name();
    }

    public List<String> guiInfoLore() {
        return infoButton.lore();
    }

    public String guiDecorationName(JobType type) {
        GuiButton button = decorationFor(type);
        return button == null ? (type == JobType.FARMER ? "Поле" : "Грузовой склад") : button.name();
    }

    public List<String> guiDecorationLore(JobType type) {
        GuiButton button = decorationFor(type);
        return button == null ? List.of() : button.lore();
    }

    private GuiButton decorationFor(JobType type) {
        if (decorativeItems.isEmpty()) {
            return null;
        }
        String wantedJob = type.id();
        for (GuiButton button : decorativeItems) {
            if (wantedJob.equals(button.job())) {
                return button;
            }
        }
        
        int legacySlot = type == JobType.FARMER ? 16 : 10;
        for (GuiButton button : decorativeItems) {
            if (button.job() == null && button.slot() == legacySlot) {
                return button;
            }
        }
        return decorativeItems.get(type == JobType.FARMER ? decorativeItems.size() - 1 : 0);
    }

    public String npcName(NpcType type) {
        NpcDefinition definition = npc(type.id());
        return definition == null ? type.defaultName() : definition.displayName();
    }

}
