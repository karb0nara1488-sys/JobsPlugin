package ru.example.jobs.command;

import org.bukkit.Location;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.config.CargoDefinition;
import ru.example.jobs.job.JobStopReason;
import ru.example.jobs.job.JobType;
import ru.example.jobs.util.Text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public final class JobsCommand implements CommandExecutor, TabCompleter {

    private static final int TEST_FARMER_RADIUS = 3;

    private final JobsPlugin plugin;

    public JobsCommand(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("jobs.admin")) {
            plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            plugin.messages().send(sender, "usage-jobs");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadPlugin();
                plugin.messages().send(sender, "reloaded");
            }
            case "menu" -> handleMenu(sender, args);
            case "start" -> handleStart(sender, args);
            case "stop" -> handleStop(sender);
            case "test" -> handleTest(sender, args);
            case "economy" -> reportEconomy(sender);
            default -> plugin.messages().send(sender, "usage-jobs");
        }
        return true;
    }

    private void handleMenu(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return;
        }
        JobType type = args.length < 2 ? null : JobType.fromId(args[1]);
        if (type == null) {
            plugin.messages().send(player, "usage-jobs");
            return;
        }
        plugin.guiManager().open(player, type);
    }

    private void handleStart(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return;
        }
        JobType type = args.length < 2 ? null : JobType.fromId(args[1]);
        if (type == null) {
            plugin.messages().send(player, "usage-jobs");
            return;
        }
        plugin.jobManager().startJob(player, type);
    }

    private void handleStop(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return;
        }
        plugin.jobManager().stopJob(player, JobStopReason.CANCELLED);
    }

    private void reportEconomy(CommandSender sender) {
        if (plugin.economyService().available()) {
            plugin.messages().send(sender, "economy-status", Map.of(
                    "%provider%", plugin.economyService().backendName(),
                    "%currency%", plugin.economyService().currencyName()));
            return;
        }
        plugin.messages().send(sender, "economy-status-off", Map.of(
                "%mode%", plugin.config().economyProviderMode(),
                "%vault%", vaultState()));
        for (String line : plugin.economyService().diagnostics()) {
            plugin.messages().sendRaw(sender, "economy-diagnostic-line",
                    Map.of("%line%", Text.escape(line)));
        }
    }

    private String vaultState() {
        Plugin vault = plugin.getServer().getPluginManager().getPlugin("Vault");
        if (vault == null) {
            return "не установлен";
        }
        return (vault.isEnabled() ? "включён" : "выключен")
                + " " + vault.getDescription().getVersion();
    }

    private void handleTest(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return;
        }
        if (args.length < 2) {
            plugin.messages().send(player, "test-usage");
            return;
        }
        switch (args[1].toLowerCase()) {
            case "loader" -> testLoader(player);
            case "farmer" -> testFarmer(player);
            default -> plugin.messages().send(player, "test-usage");
        }
    }

    private void testLoader(Player player) {
        Collection<CargoDefinition> cargos = plugin.config().cargoMap().values();
        if (cargos.isEmpty()) {
            plugin.messages().send(player, "test-no-cargo");
            return;
        }
        Location base = player.getLocation().getBlock().getRelative(BlockFace.DOWN).getLocation();
        int placed = 0;
        int index = 0;
        for (CargoDefinition cargo : cargos) {
            Location target = base.clone().add(index * 2, 0, 3);
            if (plugin.contentManager().placeBlock(cargo.id(), target)) {
                placed++;
            }
            index++;
        }
        plugin.messages().send(player, "test-loader", Map.of("%count%", String.valueOf(placed)));
    }

    private void testFarmer(Player player) {
        String name = "test_" + player.getName().toLowerCase();
        int count = plugin.fieldManager().createTestField(player, name, TEST_FARMER_RADIUS);
        if (count <= 0) {
            plugin.messages().send(player, "field-no-ground");
            return;
        }
        plugin.messages().send(player, "test-farmer", Map.of(
                "%name%", name,
                "%count%", String.valueOf(count),
                "%radius%", String.valueOf(TEST_FARMER_RADIUS)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("reload", "menu", "start", "stop", "test", "economy"), args[0]);
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (sub.equals("test") || sub.equals("menu") || sub.equals("start")) {
                return filter(List.of("loader", "farmer"), args[1]);
            }
        }
        return List.of();
    }

    private List<String> filter(List<String> values, String prefix) {
        String lower = prefix == null ? "" : prefix.toLowerCase();
        List<String> result = new ArrayList<>();
        for (String value : values) {
            if (value.toLowerCase().startsWith(lower)) {
                result.add(value);
            }
        }
        return result;
    }
}
