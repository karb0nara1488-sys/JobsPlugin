package ru.example.jobs.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.field.Field;
import ru.example.jobs.util.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class FieldCommand implements CommandExecutor, TabCompleter {

    private final JobsPlugin plugin;

    public FieldCommand(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return true;
        }
        if (!player.hasPermission("jobs.admin")) {
            plugin.messages().send(player, "no-permission");
            return true;
        }
        if (args.length == 0) {
            plugin.messages().send(player, "usage-field");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "set" -> handleSet(player, args);
            case "remove" -> handleRemove(player, args);
            case "list" -> handleList(player);
            default -> plugin.messages().send(player, "usage-field");
        }
        return true;
    }

    private void handleSet(Player player, String[] args) {
        if (args.length < 2) {
            plugin.messages().send(player, "usage-field");
            return;
        }
        String name = args[1];

        if (!name.matches("[\\p{L}\\p{N}_-]{1,32}")) {
            plugin.messages().send(player, "field-name-invalid");
            return;
        }
        if (args.length == 2) {
            plugin.fieldManager().startSelection(player, name);
            return;
        }
        String action = args[2].toLowerCase();
        switch (action) {
            case "confirm" -> plugin.fieldManager().confirmSelection(player);
            case "cancel" -> plugin.fieldManager().cancelSelection(player);
            default -> plugin.messages().send(player, "usage-field");
        }
    }

    private void handleRemove(Player player, String[] args) {
        if (args.length != 2) {
            plugin.messages().send(player, "usage-field");
            return;
        }
        String name = args[1];
        if (plugin.fieldManager().removeField(name)) {
            plugin.messages().send(player, "field-removed", Map.of("%name%", Text.escape(name)));
        } else {
            plugin.messages().send(player, "field-not-found");
        }
    }

    private void handleList(Player player) {
        List<Field> fields = new ArrayList<>(plugin.fieldManager().fields());
        if (fields.isEmpty()) {
            plugin.messages().send(player, "field-list-empty");
            return;
        }
        plugin.messages().send(player, "field-list-header",
                Map.of("%count%", String.valueOf(fields.size())));
        for (Field field : fields) {
            plugin.messages().send(player, "field-list-entry", Map.of(
                    "%name%", Text.escape(field.name()),
                    "%world%", Text.escape(field.worldName())));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("set", "remove", "list"), args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            List<String> names = new ArrayList<>();
            for (Field field : plugin.fieldManager().fields()) {
                names.add(field.name());
            }
            return filter(names, args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            return List.of();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("set")) {
            return filter(List.of("confirm", "cancel"), args[2]);
        }
        return List.of();
    }

    private List<String> filter(List<String> values, String prefix) {
        String lower = prefix == null ? "" : prefix.toLowerCase();
        List<String> result = new ArrayList<>();
        for (String value : values) {
            if (value.toLowerCase().startsWith(lower)) {
                result.add(value);
            }
        }
        return result;
    }
}
