package ru.example.jobs.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;

import java.util.List;

public final class PosCommand implements CommandExecutor, TabCompleter {

    private final JobsPlugin plugin;
    private final boolean first;

    public PosCommand(JobsPlugin plugin, boolean first) {
        this.plugin = plugin;
        this.first = first;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return true;
        }
        if (!player.hasPermission("jobs.admin")) {
            plugin.messages().send(player, "no-permission");
            return true;
        }
        if (!plugin.fieldManager().isSelecting(player)) {
            plugin.messages().send(player, "field-not-selecting");
            return true;
        }
        plugin.fieldManager().setPosition(player, player.getLocation(), first);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
