package ru.example.jobs.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.npc.NpcType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class NpcCommand implements CommandExecutor, TabCompleter {

    private final JobsPlugin plugin;

    public NpcCommand(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return true;
        }
        if (!player.hasPermission("jobs.admin")) {
            plugin.messages().send(player, "no-permission");
            return true;
        }
        if (args.length == 0) {
            plugin.messages().send(player, "usage-npc");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "remove" -> handleRemove(player);
            case "clear" -> handleClear(player, args);
            case "list" -> handleList(player);
            default -> handleSpawn(player, args[0]);
        }
        return true;
    }

    private void handleSpawn(Player player, String id) {
        NpcType type = NpcType.byId(id).orElse(null);
        if (type == null) {
            plugin.messages().send(player, "npc-unknown", Map.of("%id%", id));
            return;
        }
        plugin.npcManager().spawnAt(player, type);
    }

    private void handleRemove(Player player) {
        NpcType removed = plugin.npcManager().removeNearest(player);
        if (removed == null) {
            plugin.messages().send(player, "npc-none", Map.of(
                    "%radius%", String.valueOf((int) plugin.npcManager().removeRadius())));
            return;
        }
        plugin.messages().send(player, "npc-removed", Map.of("%id%", removed.id()));
    }

    private void handleClear(Player player, String[] args) {
        if (args.length != 2) {
            plugin.messages().send(player, "usage-npc");
            return;
        }
        NpcType type = NpcType.byId(args[1]).orElse(null);
        if (type == null) {
            plugin.messages().send(player, "npc-unknown", Map.of("%id%", args[1]));
            return;
        }
        int removed = plugin.npcManager().clear(type);
        if (removed == 0) {
            plugin.messages().send(player, "npc-clear-none", Map.of("%id%", type.id()));
            return;
        }
        plugin.messages().send(player, "npc-cleared", Map.of(
                "%id%", type.id(),
                "%count%", String.valueOf(removed)));
    }

    private void handleList(Player player) {
        plugin.messages().send(player, "npc-list-header",
                Map.of("%count%", String.valueOf(plugin.npcManager().totalCount())));
        for (NpcType type : NpcType.values()) {
            plugin.messages().send(player, "npc-list-entry", Map.of(
                    "%id%", type.id(),
                    "%count%", String.valueOf(plugin.npcManager().count(type))));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("remove", "clear", "list"));
            for (NpcType type : NpcType.values()) {
                options.add(type.id());
            }
            return filter(options, args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("clear")) {
            List<String> ids = new ArrayList<>();
            for (NpcType type : NpcType.values()) {
                ids.add(type.id());
            }
            return filter(ids, args[1]);
        }
        return List.of();
    }

    private List<String> filter(List<String> values, String prefix) {
        String lower = prefix == null ? "" : prefix.toLowerCase();
        List<String> result = new ArrayList<>();
        for (String value : values) {
            if (value.toLowerCase().startsWith(lower)) {
                result.add(value);
            }
        }
        return result;
    }
}
