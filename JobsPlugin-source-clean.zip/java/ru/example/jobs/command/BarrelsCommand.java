package ru.example.jobs.command;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import ru.example.jobs.JobsPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class BarrelsCommand implements CommandExecutor, TabCompleter {

    private static final int MAX_EXTRA_LAYERS = 4;

    private final JobsPlugin plugin;

    public BarrelsCommand(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("jobs.admin")) {
            plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return true;
        }

        int max = plugin.config().barrelsMaxCount();
        String blockId = plugin.config().barrelsBlockId();
        int requested = plugin.config().barrelsDefaultCount();

        if (args.length >= 1) {
            if (isInteger(args[0])) {
                requested = Integer.parseInt(args[0]);
            } else {
                blockId = args[0];
                if (args.length >= 2) {
                    if (!isInteger(args[1])) {
                        plugin.messages().send(player, "barrels-invalid",
                                Map.of("%max%", String.valueOf(max)));
                        return true;
                    }
                    requested = Integer.parseInt(args[1]);
                }
            }
        }
        if (requested < 1 || requested > max) {
            plugin.messages().send(player, "barrels-invalid", Map.of("%max%", String.valueOf(max)));
            return true;
        }

        if (plugin.config().cargo(blockId) == null) {
            plugin.messages().send(player, "barrels-no-cargo", Map.of("%id%", blockId));
            return true;
        }

        int placed = spawnPile(player, blockId, requested);
        if (placed <= 0) {
            plugin.messages().send(player, "barrels-failed");
            return true;
        }
        plugin.messages().send(player, "barrels-spawned", Map.of(
                "%placed%", String.valueOf(placed),
                "%requested%", String.valueOf(requested)));
        return true;
    }

    private boolean isInteger(String value) {
        if (value == null || value.isEmpty()) {
            return false;
        }
        for (int i = 0; i < value.length(); i++) {
            if (!Character.isDigit(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private int spawnPile(Player player, String cargoId, int count) {
        Location center = pileCenter(player);
        World world = center.getWorld();
        if (world == null) {
            return 0;
        }

        int baseY = groundY(player, center);
        int layers = plugin.config().barrelsLayers();
        int side = baseSide(count, layers);
        int remaining = count;
        int placed = 0;

        for (int layer = 0; layer < layers + MAX_EXTRA_LAYERS && remaining > 0; layer++) {
            int layerSide = Math.max(1, side - layer);
            int start = -(layerSide / 2);
            for (int x = 0; x < layerSide && remaining > 0; x++) {
                for (int z = 0; z < layerSide && remaining > 0; z++) {
                    Location target = new Location(world,
                            center.getBlockX() + start + x,
                            baseY + layer,
                            center.getBlockZ() + start + z);
                    Block block = target.getBlock();
                    
                    if (!block.isReplaceable()
                            || !block.getRelative(BlockFace.DOWN).getType().isSolid()) {
                        continue;
                    }
                    if (plugin.contentManager().placeBlock(cargoId, target)) {
                        placed++;
                        remaining--;
                    }
                }
            }
        }
        return placed;
    }

    private Location pileCenter(Player player) {
        Location origin = player.getLocation().clone();
        Vector direction = origin.getDirection().setY(0);
        if (direction.lengthSquared() < 1.0E-4D) {
            direction = new Vector(1, 0, 0);
        }
        direction.normalize().multiply(plugin.config().barrelsDistance());
        Location center = origin.add(direction);
        center.setYaw(0.0F);
        center.setPitch(0.0F);
        return center;
    }

    private int groundY(Player player, Location center) {
        World world = center.getWorld();
        if (world == null) {
            return center.getBlockY();
        }
        int playerY = player.getLocation().getBlockY();
        for (int offset : new int[]{0, 1, -1, 2, -2}) {
            int y = playerY + offset;
            if (y <= world.getMinHeight()) {
                continue;
            }
            Block block = world.getBlockAt(center.getBlockX(), y, center.getBlockZ());
            if (block.isReplaceable() && block.getRelative(BlockFace.DOWN).getType().isSolid()) {
                return y;
            }
        }
        int ground = world.getHighestBlockYAt(center) + 1;
        int ceiling = playerY + 2;
        return Math.max(world.getMinHeight() + 1, Math.min(ground, ceiling));
    }

    private int baseSide(int count, int layers) {
        int side = 1;
        while (sumOfSquares(side, layers) < count && side < 128) {
            side++;
        }
        return side;
    }

    private int sumOfSquares(int side, int layers) {
        int sum = 0;
        for (int i = 0; i < layers; i++) {
            int layerSide = Math.max(1, side - i);
            sum += layerSide * layerSide;
        }
        return sum;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("jobs.admin")) {
            return List.of();
        }
        int max = plugin.config().barrelsMaxCount();
        List<String> counts = List.of(
                String.valueOf(plugin.config().barrelsDefaultCount()),
                String.valueOf(Math.min(10, max)),
                String.valueOf(Math.min(25, max)),
                String.valueOf(Math.min(50, max)),
                String.valueOf(Math.min(100, max)));

        if (args.length == 1) {
            String prefix = args[0] == null ? "" : args[0].toLowerCase(Locale.ROOT);
            List<String> result = new ArrayList<>();
            for (String value : counts) {
                if (value.startsWith(prefix) && !result.contains(value)) {
                    result.add(value);
                }
            }
            
            for (String id : plugin.config().cargoMap().keySet()) {
                if (id.toLowerCase(Locale.ROOT).startsWith(prefix) && !result.contains(id)) {
                    result.add(id);
                }
            }
            return result;
        }
        if (args.length == 2 && !isInteger(args[0])) {
            String prefix = args[1] == null ? "" : args[1].toLowerCase(Locale.ROOT);
            List<String> result = new ArrayList<>();
            for (String value : counts) {
                if (value.startsWith(prefix) && !result.contains(value)) {
                    result.add(value);
                }
            }
            return result;
        }
        return List.of();
    }
}
