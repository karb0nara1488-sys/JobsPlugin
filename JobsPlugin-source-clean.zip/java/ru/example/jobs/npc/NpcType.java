package ru.example.jobs.npc;

import ru.example.jobs.job.JobType;

import java.util.Optional;

public enum NpcType {

    GRUZCHIK("gruzchik", JobType.LOADER, false,
            "<gradient:#FFD700:#FF8C00>Получить работу: Грузчик</gradient>"),
    GRUZCHIK_DELIVERY("gruzchik2", JobType.LOADER, true,
            "<gradient:#00C6FF:#0072FF>Сдать блоки</gradient>"),
    FERMER("fermer", JobType.FARMER, false,
            "<gradient:#7CFC00:#228B22>Получить работу: Фермер</gradient>"),
    FERMER_DELIVERY("fermer2", JobType.FARMER, true,
            "<gradient:#FFA07A:#FF4500>Сдать растения</gradient>");

    private final String id;
    private final JobType jobType;
    private final boolean delivery;
    private final String defaultName;

    NpcType(String id, JobType jobType, boolean delivery, String defaultName) {
        this.id = id;
        this.jobType = jobType;
        this.delivery = delivery;
        this.defaultName = defaultName;
    }

    public String id() {
        return id;
    }

    public JobType jobType() {
        return jobType;
    }

    public boolean isDelivery() {
        return delivery;
    }

    public String defaultName() {
        return defaultName;
    }

    public static Optional<NpcType> byId(String id) {
        if (id == null) {
            return Optional.empty();
        }
        for (NpcType type : values()) {
            if (type.id.equalsIgnoreCase(id)) {
                return Optional.of(type);
            }
        }
        return Optional.empty();
    }
}
