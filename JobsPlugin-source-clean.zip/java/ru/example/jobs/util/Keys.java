package ru.example.jobs.util;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

public final class Keys {

    public final NamespacedKey npc;
    public final NamespacedKey action;
    public final NamespacedKey guiJob;
    public final NamespacedKey marked;
    public final NamespacedKey carryJob;
    public final NamespacedKey cargoId;
    public final NamespacedKey education;
    public final NamespacedKey display;
    public final NamespacedKey cropType;
    public final NamespacedKey loaderBlock;

    public Keys(Plugin plugin) {
        this.npc = new NamespacedKey(plugin, "npc");
        this.action = new NamespacedKey(plugin, "action");
        this.guiJob = new NamespacedKey(plugin, "gui-job");
        this.marked = new NamespacedKey(plugin, "marked");
        this.carryJob = new NamespacedKey(plugin, "carry-job");
        this.cargoId = new NamespacedKey(plugin, "cargo-id");
        this.education = new NamespacedKey(plugin, "education");
        this.display = new NamespacedKey(plugin, "display");
        this.cropType = new NamespacedKey(plugin, "crop-type");
        this.loaderBlock = new NamespacedKey(plugin, "loader-block");
    }

    public NamespacedKey npc() {
        return npc;
    }

    public NamespacedKey action() {
        return action;
    }

    public NamespacedKey education() {
        return education;
    }

    public NamespacedKey display() {
        return display;
    }

    public NamespacedKey cropType() {
        return cropType;
    }

    public NamespacedKey loaderBlock() {
        return loaderBlock;
    }
}
