package ru.example.jobs.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.example.jobs.config.PluginConfig;

import java.util.Map;

public final class Text {

    private static final MiniMessage STATIC_MINI_MESSAGE = MiniMessage.builder().strict(false).build();

    private final PluginConfig config;
    private final MiniMessage miniMessage = MiniMessage.builder().strict(false).build();

    public Text(PluginConfig config) {
        this.config = config;
    }

    public static Component mm(String template) {
        return mm(template, Map.of());
    }

    public static Component mm(String template, Map<String, String> placeholders) {
        if (template == null || template.isEmpty()) {
            return Component.empty();
        }
        String resolved = applyPlaceholders(template, placeholders);
        try {
            return STATIC_MINI_MESSAGE.deserialize(resolved);
        } catch (RuntimeException ex) {
            return Component.text(resolved.replaceAll("<[^>]+>", ""));
        }
    }

    public static String plain(Component component) {
        return component == null ? "" : PlainTextComponentSerializer.plainText().serialize(component);
    }

    public static String escape(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("<", "\\<");
    }

    public Component parse(String template) {
        return parse(template, Map.of());
    }

    public Component parse(String template, Map<String, String> placeholders) {
        if (template == null || template.isEmpty()) {
            return Component.empty();
        }
        String resolved = applyPlaceholders(template, placeholders);
        try {
            return miniMessage.deserialize(resolved);
        } catch (RuntimeException ex) {
            return Component.text(stripTags(resolved));
        }
    }

    private static String applyPlaceholders(String template, Map<String, String> placeholders) {
        String resolved = template;
        if (placeholders == null) {
            return resolved;
        }
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            String rawKey = entry.getKey();
            if (rawKey == null || rawKey.isEmpty()) {
                continue;
            }
            String key = rawKey;
            if (key.length() > 2 && key.startsWith("%") && key.endsWith("%")) {
                key = key.substring(1, key.length() - 1);
            } else if (key.length() > 2 && key.startsWith("<") && key.endsWith(">")) {
                key = key.substring(1, key.length() - 1);
            }
            String value = entry.getValue() == null ? "" : entry.getValue();
            resolved = resolved.replace("<" + key + ">", value);
            resolved = resolved.replace("%" + key + "%", value);
        }
        return resolved;
    }

    public Component message(String key, Map<String, String> placeholders) {
        return parse(config.message(key), placeholders);
    }

    public Component message(String key) {
        return message(key, Map.of());
    }

    public void send(CommandSender receiver, String template, Map<String, String> placeholders) {
        if (receiver != null) {
            receiver.sendMessage(parse(template, placeholders));
        }
    }

    public void send(CommandSender receiver, Component component) {
        if (receiver != null) {
            receiver.sendMessage(component);
        }
    }

    public void sendKey(CommandSender receiver, String key) {
        sendKey(receiver, key, Map.of());
    }

    public void sendKey(CommandSender receiver, String key, Map<String, String> placeholders) {
        if (receiver != null) {
            receiver.sendMessage(message(key, placeholders));
        }
    }

    public void sendPrefixedKey(CommandSender receiver, String key) {
        sendPrefixedKey(receiver, key, Map.of());
    }

    public void sendPrefixedKey(CommandSender receiver, String key, Map<String, String> placeholders) {
        if (receiver != null) {
            receiver.sendMessage(parse(config.prefix() + config.message(key), placeholders));
        }
    }

    public void sendPrefixed(CommandSender receiver, String template, Map<String, String> placeholders) {
        if (receiver != null) {
            receiver.sendMessage(parse(config.prefix() + template, placeholders));
        }
    }

    public void actionBar(Player player, String template, Map<String, String> placeholders) {
        if (player != null) {
            player.sendActionBar(parse(template, placeholders));
        }
    }

    public void actionBarKey(Player player, String key, Map<String, String> placeholders) {
        if (player != null) {
            player.sendActionBar(parse(config.message(key), placeholders));
        }
    }

    private static String stripTags(String value) {
        return value.replaceAll("<[^>]+>", "");
    }
}
