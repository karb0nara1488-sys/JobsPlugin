package ru.example.jobs.util;

import java.util.Locale;

public final class TimeFormat {

    private TimeFormat() {
    }

    public static String format(long totalSeconds) {
        return format(totalSeconds, "auto");
    }

    public static String format(long totalSeconds, String mode) {
        long safe = Math.max(0L, totalSeconds);
        long hours = safe / 3600L;
        long minutes = (safe % 3600L) / 60L;
        long seconds = safe % 60L;

        String normalized = mode == null ? "auto" : mode.toLowerCase(Locale.ROOT);
        if ("hh:mm:ss".equals(normalized) || ("auto".equals(normalized) && hours > 0L)) {
            return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format(Locale.ROOT, "%02d:%02d", minutes, seconds);
    }
}
