package ru.example.jobs.content;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import ru.example.jobs.config.CargoDefinition;
import ru.example.jobs.config.CropDefinition;

public interface CustomContentProvider {

    String name();

    boolean isAvailable();

    boolean matchesCargo(Block block, CargoDefinition cargo);

    void placeCargo(CargoDefinition cargo, Location location);

    void removeCargo(Block block);

    void placeCrop(CropDefinition crop, Location location, int stageIndex);

    void applyCropStage(Block block, CropDefinition crop, int stageIndex);

    Material iconForCargo(CargoDefinition cargo);

    Material iconForCrop(CropDefinition crop);
}
