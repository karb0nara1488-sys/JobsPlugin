package ru.example.jobs.content;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import ru.example.jobs.config.CargoDefinition;
import ru.example.jobs.config.CropDefinition;
import ru.example.jobs.config.CropStage;

public final class VanillaFallbackProvider implements CustomContentProvider {

    @Override
    public String name() {
        return "Vanilla";
    }

    @Override
    public boolean isAvailable() {
        return true;
    }

    @Override
    public boolean matchesCargo(Block block, CargoDefinition cargo) {
        return block.getType() == cargo.fallbackMaterial();
    }

    @Override
    public void placeCargo(CargoDefinition cargo, Location location) {
        location.getBlock().setType(cargo.fallbackMaterial(), false);
    }

    @Override
    public void removeCargo(Block block) {
        block.setType(Material.AIR, false);
    }

    @Override
    public void placeCrop(CropDefinition crop, Location location, int stageIndex) {
        applyCropStage(location.getBlock(), crop, stageIndex);
    }

    @Override
    public void applyCropStage(Block block, CropDefinition crop, int stageIndex) {
        CropStage stage = crop.fallbackStage(stageIndex);
        BlockData data = stage.material().createBlockData();
        if (data instanceof Ageable ageable) {
            ageable.setAge(Math.max(0, Math.min(ageable.getMaximumAge(), stage.age())));
        }
        block.setBlockData(data, false);
    }

    @Override
    public Material iconForCargo(CargoDefinition cargo) {
        return cargo.fallbackIcon();
    }

    @Override
    public Material iconForCrop(CropDefinition crop) {
        return crop.fallbackIcon();
    }
}
