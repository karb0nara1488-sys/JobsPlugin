package ru.example.jobs.content;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.config.CargoDefinition;
import ru.example.jobs.config.CropDefinition;
import ru.example.jobs.config.PluginConfig;
import ru.example.jobs.field.CropType;
import ru.example.jobs.job.LoaderBlockType;

import java.util.Locale;

public final class ContentManager {

    private final JobsPlugin plugin;
    private final PluginConfig config;
    private final VanillaFallbackProvider vanilla = new VanillaFallbackProvider();
    private CustomContentProvider provider = vanilla;

    public ContentManager(JobsPlugin plugin, PluginConfig config) {
        this.plugin = plugin;
        this.config = config;
    }

    public void load() {
        String mode = config.contentProviderMode();
        boolean nexoPresent = Bukkit.getPluginManager().getPlugin("Nexo") != null;

        if ("vanilla".equals(mode)) {
            provider = vanilla;
            plugin.getLogger().info("Контент: vanilla (принудительно).");
            return;
        }

        if (!nexoPresent) {
            provider = vanilla;
            if ("nexo".equals(mode)) {
                plugin.getLogger().warning("content.provider=nexo, но Nexo не найден. Использую vanilla fallback.");
            } else {
                plugin.getLogger().info("Контент: vanilla fallback (Nexo не найден).");
            }
            return;
        }

        try {
            provider = new NexoContentProvider(plugin, vanilla);
            plugin.getLogger().info("Контент: Nexo API.");
        } catch (Throwable error) {
            provider = vanilla;
            plugin.getLogger().warning("Не удалось инициализировать Nexo API (" + error.getClass().getSimpleName()
                    + "). Использую vanilla fallback.");
        }
    }

    public CustomContentProvider provider() {
        return provider;
    }

    public String providerName() {
        return provider.name();
    }

    public boolean matchesCargo(Block block, CargoDefinition cargo) {
        return provider.matchesCargo(block, cargo);
    }

    public void placeCargo(CargoDefinition cargo, Location location) {
        provider.placeCargo(cargo, location);

        plugin.cargoTracker().track(location, cargo.id());
    }

    public void removeCargo(Block block) {
        provider.removeCargo(block);
        plugin.cargoTracker().untrack(block);
    }

    public void placeCrop(CropDefinition crop, Location location, int stageIndex) {
        provider.placeCrop(crop, location, stageIndex);
    }

    public void applyCropStage(Block block, CropDefinition crop, int stageIndex) {
        provider.applyCropStage(block, crop, stageIndex);
    }

    public Material iconForCargo(CargoDefinition cargo) {
        return provider.iconForCargo(cargo);
    }

    public Material iconForCrop(CropDefinition crop) {
        return provider.iconForCrop(crop);
    }

    public String normalizedMode() {
        return config.contentProviderMode().toLowerCase(Locale.ROOT);
    }

    public void reload() {
        load();
    }

    public String blockId(Block block) {
        if (block == null) {
            return null;
        }
        for (CargoDefinition cargo : config.cargoMap().values()) {
            if (matchesCargo(block, cargo)) {
                return cargo.id();
            }
        }
        return null;
    }

    public boolean removeBlock(Block block) {
        if (block == null) {
            return false;
        }
        removeCargo(block);
        return true;
    }

    public boolean placeBlock(String id, Location location) {
        if (id == null || location == null) {
            return false;
        }
        CargoDefinition cargo = config.cargo(id);
        if (cargo == null) {
            return false;
        }
        placeCargo(cargo, location);
        return true;
    }

    public boolean placeCrop(CropType crop, Location location) {
        if (crop == null || location == null) {
            return false;
        }
        placeCrop(crop.definition(), location, 0);
        return true;
    }

    public LoaderBlockType loaderBlock(String id) {
        if (id == null) {
            return null;
        }
        CargoDefinition cargo = config.cargo(id);
        return cargo == null ? null : LoaderBlockType.from(cargo);
    }

    public boolean isNexoAvailable() {
        return provider.isAvailable() && "Nexo".equals(provider.name());
    }
}
