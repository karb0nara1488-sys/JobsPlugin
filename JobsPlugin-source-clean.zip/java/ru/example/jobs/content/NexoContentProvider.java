package ru.example.jobs.content;

import com.nexomc.nexo.api.NexoBlocks;
import com.nexomc.nexo.api.NexoItems;
import com.nexomc.nexo.items.ItemBuilder;
import com.nexomc.nexo.mechanics.custom_block.CustomBlockMechanic;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.config.CargoDefinition;
import ru.example.jobs.config.CropDefinition;

import java.util.logging.Level;

public final class NexoContentProvider implements CustomContentProvider {

    private final JobsPlugin plugin;
    private final VanillaFallbackProvider fallback;

    public NexoContentProvider(JobsPlugin plugin, VanillaFallbackProvider fallback) {
        this.plugin = plugin;
        this.fallback = fallback;
    }

    @Override
    public String name() {
        return "Nexo";
    }

    @Override
    public boolean isAvailable() {
        return true;
    }

    @Override
    public boolean matchesCargo(Block block, CargoDefinition cargo) {
        try {

            if (!NexoBlocks.isCustomBlock(block)) {
                return fallback.matchesCargo(block, cargo);
            }
            CustomBlockMechanic mechanic = NexoBlocks.customBlockMechanic(block);
            if (mechanic == null) {
                return fallback.matchesCargo(block, cargo);
            }
            return cargo.nexoId().equals(mechanic.getItemID());
        } catch (Throwable error) {
            warn("matchesCargo", error);
            return fallback.matchesCargo(block, cargo);
        }
    }

    @Override
    public void placeCargo(CargoDefinition cargo, Location location) {
        try {
            NexoBlocks.place(cargo.nexoId(), location);
        } catch (Throwable error) {
            warn("placeCargo", error);
            fallback.placeCargo(cargo, location);
        }
    }

    @Override
    public void removeCargo(Block block) {
        try {
            if (!NexoBlocks.isCustomBlock(block)) {
                fallback.removeCargo(block);
                return;
            }
            NexoBlocks.remove(block.getLocation(), null, false);
        } catch (Throwable error) {
            warn("removeCargo", error);
            fallback.removeCargo(block);
        }
    }

    @Override
    public void placeCrop(CropDefinition crop, Location location, int stageIndex) {
        try {
            NexoBlocks.place(crop.nexoStage(stageIndex), location);
        } catch (Throwable error) {
            warn("placeCrop", error);
            fallback.placeCrop(crop, location, stageIndex);
        }
    }

    @Override
    public void applyCropStage(Block block, CropDefinition crop, int stageIndex) {
        try {
            NexoBlocks.place(crop.nexoStage(stageIndex), block.getLocation());
        } catch (Throwable error) {
            warn("applyCropStage", error);
            fallback.applyCropStage(block, crop, stageIndex);
        }
    }

    @Override
    public Material iconForCargo(CargoDefinition cargo) {
        ItemStack item = buildItem(cargo.nexoId());
        return item == null ? cargo.fallbackIcon() : item.getType();
    }

    @Override
    public Material iconForCrop(CropDefinition crop) {
        ItemStack item = buildItem(crop.nexoStage(0));
        return item == null ? crop.fallbackIcon() : item.getType();
    }

    private ItemStack buildItem(String id) {
        try {
            ItemBuilder builder = NexoItems.itemFromId(id);
            return builder == null ? null : builder.build();
        } catch (Throwable error) {
            warn("itemFromId(" + id + ")", error);
            return null;
        }
    }

    private void warn(String operation, Throwable error) {
        plugin.getLogger().log(Level.WARNING, "Nexo API error in " + operation + "; using vanilla fallback", error);
    }
}
