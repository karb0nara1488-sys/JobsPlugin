package ru.example.jobs.economy;

import org.bukkit.OfflinePlayer;

public interface EconomyProvider {

    boolean available();

    String backendName();

    boolean deposit(OfflinePlayer player, double amount);

    String currencyName();
}
