package ru.example.jobs.economy;

import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class VaultEconomyResolver {

    public static final String ECONOMY_SERVICE = "net.milkbowl.vault.economy.Economy";

    private VaultEconomyResolver() {
    }

    public static EconomyProvider resolve() {
        for (Class<?> service : economyServiceClasses()) {

            RegisteredServiceProvider<?> best = bestRegistration(service);
            if (best != null && best.getProvider() != null) {
                EconomyProvider provider = VaultEconomyProvider.create(best.getProvider());
                if (provider != null) {
                    return provider;
                }
            }
            for (RegisteredServiceProvider<?> registration : registrations(service)) {
                if (registration.getProvider() == null) {
                    continue;
                }
                EconomyProvider provider = VaultEconomyProvider.create(registration.getProvider());
                if (provider != null) {
                    return provider;
                }
            }
        }
        return null;
    }

    public static List<String> describeServices() {
        List<String> lines = new ArrayList<>();
        for (Class<?> service : economyServiceClasses()) {
            Collection<RegisteredServiceProvider<?>> registrations = registrations(service);
            if (registrations.isEmpty()) {
                lines.add(service.getName() + ": сервис объявлен, но провайдеров нет");
                continue;
            }
            for (RegisteredServiceProvider<?> registration : registrations) {
                Object provider = registration.getProvider();
                String providerName = provider == null
                        ? "null"
                        : provider.getClass().getName() + providerDisplayName(provider);
                String pluginName = registration.getPlugin() == null
                        ? "?"
                        : registration.getPlugin().getName();
                lines.add(service.getName() + " <- " + providerName
                        + " [" + pluginName + ", " + registration.getPriority() + "]");
            }
        }
        if (lines.isEmpty()) {
            lines.add("Сервис " + ECONOMY_SERVICE + " не зарегистрирован");
        }
        return lines;
    }

    private static List<Class<?>> economyServiceClasses() {
        List<Class<?>> result = new ArrayList<>();
        try {
            ServicesManager services = Bukkit.getServicesManager();
            for (Class<?> service : services.getKnownServices()) {
                if (ECONOMY_SERVICE.equals(service.getName())) {
                    result.add(service);
                }
            }
        } catch (Throwable ignored) {
            
        }
        return result;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static RegisteredServiceProvider<?> bestRegistration(Class<?> service) {
        try {
            ServicesManager services = Bukkit.getServicesManager();
            return services.getRegistration((Class) service);
        } catch (Throwable ignored) {
            return null;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Collection<RegisteredServiceProvider<?>> registrations(Class<?> service) {
        try {
            ServicesManager services = Bukkit.getServicesManager();
            Collection<?> registrations = (Collection) services.getRegistrations((Class) service);
            if (registrations == null) {
                return List.of();
            }
            return (Collection) registrations;
        } catch (Throwable ignored) {
            return List.of();
        }
    }

    private static String providerDisplayName(Object provider) {
        try {
            Method getName = provider.getClass().getMethod("getName");
            Object value = getName.invoke(provider);
            return value instanceof String name && !name.isBlank() ? " (" + name + ")" : "";
        } catch (Throwable ignored) {
            return "";
        }
    }
}
