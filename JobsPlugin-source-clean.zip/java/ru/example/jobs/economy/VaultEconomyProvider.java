package ru.example.jobs.economy;

import org.bukkit.OfflinePlayer;

import java.lang.reflect.Method;

public final class VaultEconomyProvider implements EconomyProvider {

    private final Object economy;
    private final Method depositMethod;
    private final Method transactionSuccessMethod;
    private final Method nameMethod;
    private final Method currencyMethod;
    private final String backendName;

    private VaultEconomyProvider(Object economy,
                                 Method depositMethod,
                                 Method transactionSuccessMethod,
                                 Method nameMethod,
                                 Method currencyMethod) {
        this.economy = economy;
        this.depositMethod = depositMethod;
        this.transactionSuccessMethod = transactionSuccessMethod;
        this.nameMethod = nameMethod;
        this.currencyMethod = currencyMethod;
        this.backendName = readName();
    }

    public static VaultEconomyProvider create(Object economy) {
        if (economy == null) {
            return null;
        }
        try {
            Class<?> type = economy.getClass();
            Method deposit = type.getMethod("depositPlayer", OfflinePlayer.class, double.class);
            Method success = deposit.getReturnType().getMethod("transactionSuccess");
            Method name = optionalMethod(type, "getName");
            Method currency = optionalMethod(type, "currencyNamePlural");
            return new VaultEconomyProvider(economy, deposit, success, name, currency);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static Method optionalMethod(Class<?> type, String name) {
        try {
            return type.getMethod(name);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private String readName() {
        if (nameMethod == null) {
            return "Vault";
        }
        try {
            Object value = nameMethod.invoke(economy);
            if (value instanceof String name && !name.isBlank()) {
                return name;
            }
        } catch (Throwable ignored) {
            
        }
        return "Vault";
    }

    @Override
    public boolean available() {
        return true;
    }

    @Override
    public String backendName() {
        return backendName;
    }

    @Override
    public boolean deposit(OfflinePlayer player, double amount) {
        if (amount <= 0.0D) {
            return true;
        }
        if (player == null) {
            return false;
        }
        try {
            Object response = depositMethod.invoke(economy, player, amount);
            if (response == null) {
                return false;
            }
            return Boolean.TRUE.equals(transactionSuccessMethod.invoke(response));
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public String currencyName() {
        if (currencyMethod == null) {
            return null;
        }
        try {
            Object value = currencyMethod.invoke(economy);
            if (value instanceof String name && !name.isBlank()) {
                return name;
            }
        } catch (Throwable ignored) {
            
        }
        return null;
    }

    @Override
    public String toString() {
        return "VaultEconomyProvider{" + backendName + "}";
    }
}
