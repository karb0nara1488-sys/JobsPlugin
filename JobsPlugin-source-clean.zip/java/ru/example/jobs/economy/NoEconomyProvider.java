package ru.example.jobs.economy;

import org.bukkit.OfflinePlayer;

public final class NoEconomyProvider implements EconomyProvider {

    public static final NoEconomyProvider INSTANCE = new NoEconomyProvider();

    private NoEconomyProvider() {
    }

    @Override
    public boolean available() {
        return false;
    }

    @Override
    public String backendName() {
        return "none";
    }

    @Override
    public boolean deposit(OfflinePlayer player, double amount) {
        return false;
    }

    @Override
    public String currencyName() {
        return null;
    }
}
