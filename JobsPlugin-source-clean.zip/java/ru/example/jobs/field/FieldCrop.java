package ru.example.jobs.field;

import org.bukkit.Location;

public final class FieldCrop {

    private final Location location;
    private final String cropId;
    private long plantedAt;
    private int lastPercent = -1;

    public FieldCrop(Location location, String cropId, long plantedAt) {
        this.location = location;
        this.cropId = cropId;
        this.plantedAt = plantedAt;
    }

    public Location location() {
        return location;
    }

    public String cropId() {
        return cropId;
    }

    public long plantedAt() {
        return plantedAt;
    }

    public void setPlantedAt(long plantedAt) {
        this.plantedAt = plantedAt;
    }

    public int lastPercent() {
        return lastPercent;
    }

    public void setLastPercent(int lastPercent) {
        this.lastPercent = lastPercent;
    }
}
