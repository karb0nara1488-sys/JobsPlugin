package ru.example.jobs.field;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import ru.example.jobs.config.CropDefinition;
import ru.example.jobs.util.Text;

public final class CropType {

    private final CropDefinition definition;

    private CropType(CropDefinition definition) {
        this.definition = definition;
    }

    public static CropType from(CropDefinition definition) {
        return new CropType(definition);
    }

    public CropDefinition definition() {
        return definition;
    }

    public String id() {
        return definition.id();
    }

    public String displayName() {
        return definition.displayName();
    }

    public Component nameComponent() {
        return Text.mm(displayName());
    }

    public String plainName() {
        return Text.plain(nameComponent());
    }

    public String gradientFrom() {
        return "#FFFFFF";
    }

    public String gradientTo() {
        return "#B0C4DE";
    }

    public String nexoId() {
        return definition.nexoStage(0);
    }

    public Material fallbackMaterial() {
        return definition.fallbackIcon();
    }

    public long growthSeconds() {
        return definition.growthSeconds();
    }

    public double price() {
        return definition.price();
    }

    public double bonusChance() {
        return definition.bonusChance();
    }

    public double bonusPrice() {
        return definition.bonusPrice();
    }

    public double bonusMultiplier() {
        double price = definition.price();
        if (price <= 0.0D) {
            return 1.0D;
        }
        return Math.max(1.0D, 1.0D + definition.bonusPrice() / price);
    }

    public boolean requiresFarmland() {
        return true;
    }
}
