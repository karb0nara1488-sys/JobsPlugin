package ru.example.jobs.field;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.util.Text;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

public final class FieldManager {

    private static final int FILL_SCAN_MARGIN = 8;

    private final JobsPlugin plugin;
    private final FieldDisplayManager displays;
    private final File file;
    private final Map<String, Field> fields = new LinkedHashMap<>();
    private final Map<Location, FieldCrop> cropIndex = new HashMap<>();
    private final Map<UUID, FieldSelection> selections = new HashMap<>();

    private final Map<String, RawField> pendingFields = new LinkedHashMap<>();
    private boolean dirty;
    private int secondsSinceSave;

    private record RawField(UUID worldId,
                            int minX, int minY, int minZ,
                            int maxX, int maxY, int maxZ,
                            List<String> crops) {
    }

    public FieldManager(JobsPlugin plugin, FieldDisplayManager displays) {
        this.plugin = plugin;
        this.displays = displays;
        this.file = new File(plugin.getDataFolder(), "fields.yml");
    }

    public FieldDisplayManager displayManager() {
        return displays;
    }

    public void load() {
        fields.clear();
        cropIndex.clear();
        pendingFields.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("fields");
        if (root == null) {
            return;
        }
        for (String name : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(name);
            if (section == null) {
                continue;
            }
            UUID worldId = parseUuid(section.getString("world"));
            if (worldId == null) {
                plugin.getLogger().warning("Поле " + name + " пропущено: некорректный world UUID.");
                continue;
            }
            if (Bukkit.getWorld(worldId) == null) {

                pendingFields.put(name, new RawField(worldId,
                        section.getInt("min-x"), section.getInt("min-y"), section.getInt("min-z"),
                        section.getInt("max-x"), section.getInt("max-y"), section.getInt("max-z"),
                        new ArrayList<>(section.getStringList("crops"))));
                plugin.getLogger().info("Поле " + name + " отложено: мир ещё не загружен.");
                continue;
            }
            Field field = new Field(name, worldId,
                    section.getInt("min-x"), section.getInt("min-y"), section.getInt("min-z"),
                    section.getInt("max-x"), section.getInt("max-y"), section.getInt("max-z"));
            for (String raw : section.getStringList("crops")) {
                FieldCrop crop = parseCrop(raw, worldId);
                if (crop != null) {
                    field.addCrop(crop);
                    cropIndex.put(crop.location(), crop);
                }
            }
            fields.put(name, field);
        }
        dirty = false;
        plugin.getLogger().info("Загружено полей: " + fields.size()
                + ", культур: " + cropIndex.size()
                + ", отложено до загрузки мира: " + pendingFields.size());
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Field field : fields.values()) {
            String base = "fields." + field.name();
            yaml.set(base + ".world", field.worldId().toString());
            yaml.set(base + ".min-x", field.minX());
            yaml.set(base + ".min-y", field.minY());
            yaml.set(base + ".min-z", field.minZ());
            yaml.set(base + ".max-x", field.maxX());
            yaml.set(base + ".max-y", field.maxY());
            yaml.set(base + ".max-z", field.maxZ());
            List<String> crops = new ArrayList<>(field.cropCount());
            for (FieldCrop crop : field.crops()) {
                Location location = crop.location();
                crops.add(location.getBlockX() + ";" + location.getBlockY() + ";"
                        + location.getBlockZ() + ";" + crop.cropId() + ";" + crop.plantedAt());
            }
            yaml.set(base + ".crops", crops);
        }

        for (Map.Entry<String, RawField> entry : pendingFields.entrySet()) {
            if (fields.containsKey(entry.getKey())) {
                continue;
            }
            RawField raw = entry.getValue();
            String base = "fields." + entry.getKey();
            yaml.set(base + ".world", raw.worldId().toString());
            yaml.set(base + ".min-x", raw.minX());
            yaml.set(base + ".min-y", raw.minY());
            yaml.set(base + ".min-z", raw.minZ());
            yaml.set(base + ".max-x", raw.maxX());
            yaml.set(base + ".max-y", raw.maxY());
            yaml.set(base + ".max-z", raw.maxZ());
            yaml.set(base + ".crops", new ArrayList<>(raw.crops()));
        }
        try {
            yaml.save(file);
            dirty = false;
        } catch (IOException exception) {
            plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить fields.yml", exception);
        }
    }

    public void tickAutosave() {
        secondsSinceSave++;
        if (secondsSinceSave >= plugin.config().saveIntervalSeconds()) {
            secondsSinceSave = 0;
            if (dirty) {
                save();
            }
        }
    }

    public void reload() {
        displays.removeAll();
        selections.clear();
        load();
        displays.refreshAll();
    }

    public void startSelection(Player player, String name) {
        selections.put(player.getUniqueId(), new FieldSelection(name));
        plugin.messages().send(player, "field-selection-started",
                Map.of("%name%", Text.escape(name)));
    }

    public void cancelSelection(Player player) {
        if (selections.remove(player.getUniqueId()) != null) {
            plugin.messages().send(player, "field-cancelled");
        }
    }

    public void clearSelection(UUID uuid) {
        selections.remove(uuid);
    }

    public boolean isSelecting(Player player) {
        return selections.containsKey(player.getUniqueId());
    }

    public String selectionName(Player player) {
        FieldSelection selection = selections.get(player.getUniqueId());
        return selection == null ? null : selection.name();
    }

    public void setPosition(Player player, Location location, boolean first) {
        FieldSelection selection = selections.get(player.getUniqueId());
        if (selection == null) {
            plugin.messages().send(player, "field-not-selecting");
            return;
        }
        if (location == null || location.getWorld() == null) {
            return;
        }
        Location normalized = normalize(location);
        if (first) {
            selection.setPos1(normalized);
        } else {
            selection.setPos2(normalized);
        }
        plugin.messages().send(player, first ? "field-pos1" : "field-pos2", Map.of(
                "%pos%", Text.escape(describe(normalized)),
                "%size%", Text.escape(describeSize(selection))));

        if (selection.isComplete()) {
            confirmSelection(player);
        }
    }

    public void confirmSelection(Player player) {
        FieldSelection selection = selections.get(player.getUniqueId());
        if (selection == null || !selection.isComplete()) {
            plugin.messages().send(player, "field-no-selection");
            return;
        }
        Location pos1 = selection.pos1();
        Location pos2 = selection.pos2();
        if (pos1.getWorld() == null || pos2.getWorld() == null
                || !pos1.getWorld().getUID().equals(pos2.getWorld().getUID())) {
            plugin.messages().send(player, "field-different-world");
            return;
        }

        int minX = Math.min(pos1.getBlockX(), pos2.getBlockX());
        int minY = Math.min(pos1.getBlockY(), pos2.getBlockY());
        int minZ = Math.min(pos1.getBlockZ(), pos2.getBlockZ());
        int maxX = Math.max(pos1.getBlockX(), pos2.getBlockX());
        int maxY = Math.max(pos1.getBlockY(), pos2.getBlockY());
        int maxZ = Math.max(pos1.getBlockZ(), pos2.getBlockZ());
        int maxSize = plugin.config().fieldMaxSize();
        if (maxX - minX + 1 > maxSize || maxZ - minZ + 1 > maxSize) {
            plugin.messages().send(player, "field-too-large", Map.of("%max%", String.valueOf(maxSize)));
            return;
        }
        if (plugin.config().crops().isEmpty()) {
            plugin.messages().send(player, "field-no-crops-configured");
            return;
        }

        int count = fillRegion(selection.name(), pos1.getWorld(),
                minX, minY, minZ, maxX, maxY, maxZ);
        if (count <= 0) {
            plugin.messages().send(player, "field-no-ground");
            return;
        }

        selections.remove(player.getUniqueId());
        plugin.messages().send(player, "field-confirmed", Map.of(
                "%name%", Text.escape(selection.name()),
                "%count%", String.valueOf(count)));
        int limit = plugin.config().fieldMaxDisplays();
        if (count > limit) {
            plugin.messages().send(player, "field-display-warning", Map.of(
                    "%count%", String.valueOf(count),
                    "%limit%", String.valueOf(limit)));
        }
    }

    public int createTestField(Player player, String name, int radius) {
        World world = player.getWorld();
        if (world == null || plugin.config().crops().isEmpty()) {
            return 0;
        }
        int r = Math.max(1, radius);
        int cx = player.getLocation().getBlockX();
        int cy = player.getLocation().getBlockY();
        int cz = player.getLocation().getBlockZ();
        return fillRegion(name, world, cx - r, cy, cz - r, cx + r, cy, cz + r);
    }

    private int fillRegion(String name, World world,
                           int minX, int minY, int minZ,
                           int maxX, int maxY, int maxZ) {
        List<CropType> cropTypes = new ArrayList<>(plugin.config().crops().values());
        if (cropTypes.isEmpty()) {
            return 0;
        }
        Field field = new Field(name, world.getUID(), minX, minY, minZ, maxX, maxY, maxZ);
        long now = System.currentTimeMillis();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        int count = 0;
        int step = Math.max(1, plugin.config().plantStep());
        int scanFloor = Math.max(world.getMinHeight() + 1, minY - FILL_SCAN_MARGIN);

        for (int x = minX; x <= maxX; x += step) {
            for (int z = minZ; z <= maxZ; z += step) {
                int surfaceY = findSurface(world, x, z, maxY, scanFloor);
                if (surfaceY == Integer.MIN_VALUE) {
                    continue;
                }
                Block ground = world.getBlockAt(x, surfaceY, z);
                Block above = world.getBlockAt(x, surfaceY + 1, z);
                if (!above.getType().isAir() && !above.isReplaceable()) {
                    continue;
                }
                if (ground.getType() != Material.FARMLAND) {
                    ground.setType(Material.FARMLAND, false);
                }
                CropType crop = cropTypes.get(random.nextInt(cropTypes.size()));
                if (plugin.contentManager().placeCrop(crop, above.getLocation())) {
                    field.addCrop(new FieldCrop(above.getLocation(), crop.id(), now));
                    count++;
                }
            }
        }

        if (count == 0) {
            return 0;
        }
        replaceField(field);
        dirty = true;
        save();
        displays.refreshField(field);
        return count;
    }

    private int findSurface(World world, int x, int z, int fromY, int floorY) {
        int fallback = Integer.MIN_VALUE;
        List<Material> groundMaterials = plugin.config().groundMaterials();
        for (int y = fromY; y >= floorY; y--) {
            Material type = world.getBlockAt(x, y, z).getType();
            if (type.isAir() || !type.isSolid()) {
                continue;
            }
            Block above = world.getBlockAt(x, y + 1, z);
            if (!above.getType().isAir() && !above.isReplaceable()) {
                continue;
            }
            if (groundMaterials.contains(type)) {
                return y;
            }
            if (fallback == Integer.MIN_VALUE) {
                fallback = y;
            }
        }
        return fallback;
    }

    private void replaceField(Field replacement) {
        Field old = fields.get(replacement.name());
        Set<Location> newLocations = new HashSet<>();
        for (FieldCrop crop : replacement.crops()) {
            newLocations.add(crop.location());
        }
        if (old != null) {
            displays.removeField(old);
            for (FieldCrop crop : old.crops()) {
                cropIndex.remove(crop.location());
                if (!newLocations.contains(crop.location())) {
                    plugin.contentManager().removeBlock(crop.location().getBlock());
                }
            }
        }
        fields.put(replacement.name(), replacement);
        pendingFields.remove(replacement.name());
        for (FieldCrop crop : replacement.crops()) {
            cropIndex.put(crop.location(), crop);
        }
    }

    public FieldCrop cropAt(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        return cropIndex.get(normalize(location));
    }

    public int percent(FieldCrop crop) {
        CropType type = plugin.config().crops().get(crop.cropId());
        if (type == null) {
            return 0;
        }
        long elapsed = System.currentTimeMillis() - crop.plantedAt();
        long total = Math.max(1L, type.growthSeconds() * 1000L);
        long value = elapsed * 100L / total;
        return (int) Math.max(0L, Math.min(100L, value));
    }

    public void resetCrop(FieldCrop crop) {
        crop.setPlantedAt(System.currentTimeMillis());
        crop.setLastPercent(-1);
        CropType type = plugin.config().crops().get(crop.cropId());
        if (type != null) {
            plugin.contentManager().applyCropStage(crop.location().getBlock(),
                    type.definition(), 0);
        }
        displays.updateCrop(crop, 0);
        dirty = true;
    }

    public boolean removeField(String name) {
        boolean pending = pendingFields.remove(name) != null;
        Field field = fields.remove(name);
        if (field == null) {
            if (pending) {
                dirty = true;
                save();
                return true;
            }
            return false;
        }
        displays.removeField(field);
        for (FieldCrop crop : field.crops()) {
            cropIndex.remove(crop.location());
            plugin.contentManager().removeBlock(crop.location().getBlock());
        }
        dirty = true;
        save();
        return true;
    }

    public void tickDisplays() {
        displays.tick();
    }

    public Collection<Field> fields() {
        return fields.values();
    }

    public Field field(String name) {
        return fields.get(name);
    }

    public int cropCount() {
        return cropIndex.size();
    }

    public boolean isProtectedGround(Block block) {
        if (block == null || block.getWorld() == null) {
            return false;
        }
        return cropIndex.containsKey(normalize(block.getLocation().add(0.0D, 1.0D, 0.0D)));
    }

    public boolean isFieldCrop(Block block) {
        return block != null && block.getWorld() != null && cropAt(block.getLocation()) != null;
    }
    private Location normalize(Location location) {
        return new Location(location.getWorld(),
                location.getBlockX(), location.getBlockY(), location.getBlockZ());
    }

    private String describe(Location location) {
        return location.getWorld().getName() + " "
                + location.getBlockX() + " " + location.getBlockY() + " " + location.getBlockZ();
    }

    private String describeSize(FieldSelection selection) {
        Location pos1 = selection.pos1();
        Location pos2 = selection.pos2();
        if (pos1 == null || pos2 == null) {
            return "?";
        }
        int width = Math.abs(pos2.getBlockX() - pos1.getBlockX()) + 1;
        int depth = Math.abs(pos2.getBlockZ() - pos1.getBlockZ()) + 1;
        return width + "x" + depth;
    }

    private UUID parseUuid(String raw) {
        if (raw == null) {
            return null;
        }
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    private FieldCrop parseCrop(String raw, UUID worldId) {
        String[] parts = raw.split(";");
        if (parts.length != 5) {
            return null;
        }
        try {
            int x = Integer.parseInt(parts[0]);
            int y = Integer.parseInt(parts[1]);
            int z = Integer.parseInt(parts[2]);
            String cropId = parts[3];
            long plantedAt = Long.parseLong(parts[4]);
            World world = Bukkit.getWorld(worldId);
            if (world == null || cropId.isBlank()) {
                return null;
            }
            return new FieldCrop(new Location(world, x, y, z), cropId, plantedAt);
        } catch (NumberFormatException exception) {
            return null;
        }
    }
}
