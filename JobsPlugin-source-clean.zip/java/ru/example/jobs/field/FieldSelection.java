package ru.example.jobs.field;

import org.bukkit.Location;

public final class FieldSelection {

    private final String name;
    private Location pos1;
    private Location pos2;

    public FieldSelection(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

    public Location pos1() {
        return pos1;
    }

    public void setPos1(Location pos1) {
        this.pos1 = pos1;
    }

    public Location pos2() {
        return pos2;
    }

    public void setPos2(Location pos2) {
        this.pos2 = pos2;
    }

    public boolean isComplete() {
        return pos1 != null && pos2 != null;
    }
}
