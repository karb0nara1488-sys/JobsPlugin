package ru.example.jobs.field;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public final class Field {

    private final String name;
    private final UUID worldId;
    private final int minX;
    private final int minY;
    private final int minZ;
    private final int maxX;
    private final int maxY;
    private final int maxZ;
    private final Map<Location, FieldCrop> crops = new LinkedHashMap<>();

    public Field(String name,
                 UUID worldId,
                 int minX, int minY, int minZ,
                 int maxX, int maxY, int maxZ) {
        this.name = name;
        this.worldId = worldId;
        this.minX = Math.min(minX, maxX);
        this.minY = Math.min(minY, maxY);
        this.minZ = Math.min(minZ, maxZ);
        this.maxX = Math.max(minX, maxX);
        this.maxY = Math.max(minY, maxY);
        this.maxZ = Math.max(minZ, maxZ);
    }

    public String name() {
        return name;
    }

    public UUID worldId() {
        return worldId;
    }

    public World world() {
        return Bukkit.getWorld(worldId);
    }

    public String worldName() {
        World world = world();
        return world == null ? worldId.toString() : world.getName();
    }

    public int minX() {
        return minX;
    }

    public int minY() {
        return minY;
    }

    public int minZ() {
        return minZ;
    }

    public int maxX() {
        return maxX;
    }

    public int maxY() {
        return maxY;
    }

    public int maxZ() {
        return maxZ;
    }

    public int sizeX() {
        return maxX - minX + 1;
    }

    public int sizeZ() {
        return maxZ - minZ + 1;
    }

    public void addCrop(FieldCrop crop) {
        crops.put(crop.location(), crop);
    }

    public void removeCrop(FieldCrop crop) {
        crops.remove(crop.location());
    }

    public FieldCrop crop(Location location) {
        return crops.get(location);
    }

    public Collection<FieldCrop> crops() {
        return crops.values();
    }

    public int cropCount() {
        return crops.size();
    }
}
