package ru.example.jobs.field;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.TextDisplay;
import org.bukkit.entity.TextDisplay.TextAlignment;
import org.bukkit.persistence.PersistentDataType;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.util.Text;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class FieldDisplayManager {

    private final JobsPlugin plugin;
    private final Map<Location, TextDisplay> displays = new HashMap<>();

    public FieldDisplayManager(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    public void removeAll() {
        for (TextDisplay display : displays.values()) {
            display.remove();
        }
        displays.clear();
    }

    public void removeTaggedDisplays() {
        for (World world : Bukkit.getWorlds()) {
            for (TextDisplay display : world.getEntitiesByClass(TextDisplay.class)) {
                if (display.getPersistentDataContainer()
                        .has(plugin.keys().display(), PersistentDataType.STRING)) {
                    display.remove();
                }
            }
        }
    }

    public void removeField(Field field) {
        for (FieldCrop crop : field.crops()) {
            TextDisplay display = displays.remove(crop.location());
            if (display != null) {
                display.remove();
            }
        }
    }

    public void refreshAll() {
        removeAll();
        removeTaggedDisplays();
        for (Field field : plugin.fieldManager().fields()) {
            spawnForField(field);
        }
    }

    public void refreshField(Field field) {
        removeField(field);
        spawnForField(field);
    }

    private void spawnForField(Field field) {
        int limit = plugin.config().fieldMaxDisplays();
        for (FieldCrop crop : field.crops()) {
            if (displays.size() >= limit) {
                return;
            }
            CropType type = plugin.config().crops().get(crop.cropId());
            if (type == null || !isChunkLoaded(crop.location())) {
                continue;
            }
            TextDisplay display = spawn(crop, type, plugin.fieldManager().percent(crop));
            if (display != null) {
                displays.put(crop.location(), display);
            }
        }
    }

    public void tick() {
        int limit = plugin.config().fieldMaxDisplays();
        for (Field field : plugin.fieldManager().fields()) {
            for (FieldCrop crop : field.crops()) {
                CropType type = plugin.config().crops().get(crop.cropId());
                if (type == null) {
                    continue;
                }
                int percent = plugin.fieldManager().percent(crop);
                TextDisplay display = displays.get(crop.location());
                if (display != null && !display.isValid()) {
                    displays.remove(crop.location());
                    display = null;
                }
                if (display == null) {
                    if (displays.size() >= limit || !isChunkLoaded(crop.location())) {
                        continue;
                    }
                    display = spawn(crop, type, percent);
                    if (display != null) {
                        displays.put(crop.location(), display);
                        if (plugin.config().updateBlockStages()) {
                            plugin.contentManager().applyCropStage(crop.location().getBlock(),
                                    type.definition(), type.definition().stageIndex(percent));
                        }
                        crop.setLastPercent(percent);
                    }
                    continue;
                }
                if (percent != crop.lastPercent()) {
                    display.text(buildText(type, percent));
                    if (plugin.config().updateBlockStages()) {
                        plugin.contentManager().applyCropStage(crop.location().getBlock(),
                                type.definition(), type.definition().stageIndex(percent));
                    }
                    crop.setLastPercent(percent);
                }
            }
        }
        cleanupOrphans();
    }

    public void updateCrop(FieldCrop crop, int percent) {
        TextDisplay display = displays.get(crop.location());
        if (display == null || !display.isValid()) {
            return;
        }
        CropType type = plugin.config().crops().get(crop.cropId());
        if (type == null) {
            return;
        }
        display.text(buildText(type, percent));
        crop.setLastPercent(percent);
    }

    public int displayCount() {
        return displays.size();
    }

    private TextDisplay spawn(FieldCrop crop, CropType type, int percent) {
        Location location = crop.location().clone().add(0.5D,
                plugin.config().fieldDisplayHeight(), 0.5D);
        World world = location.getWorld();
        if (world == null) {
            return null;
        }
        try {
            return world.spawn(location, TextDisplay.class, entity -> {
                entity.setBillboard(Display.Billboard.CENTER);
                entity.setAlignment(TextAlignment.CENTER);
                entity.setPersistent(false);
                entity.setInvulnerable(true);
                entity.setGravity(false);
                entity.setViewRange(plugin.config().displayViewRange());
                entity.setDefaultBackground(false);
                entity.setShadowed(true);
                entity.setSeeThrough(false);
                entity.setLineWidth(200);
                entity.text(buildText(type, percent));
                entity.getPersistentDataContainer().set(plugin.keys().display(),
                        PersistentDataType.STRING, crop.cropId());
            });
        } catch (RuntimeException exception) {
            plugin.getLogger().warning("Не удалось создать TextDisplay для " + crop.cropId()
                    + ": " + exception.getMessage());
            return null;
        }
    }

    private Component buildText(CropType type, int percent) {
        try {
            return Text.mm(plugin.config().fieldDisplayFormat(), Map.of(
                    "%from%", type.gradientFrom(),
                    "%to%", type.gradientTo(),
                    "%name%", Text.escape(type.plainName()),
                    "%percent%", String.valueOf(percent)));
        } catch (RuntimeException exception) {
            return Text.mm(Text.escape(type.plainName()) + " " + percent + "%");
        }
    }

    private void cleanupOrphans() {
        Iterator<Map.Entry<Location, TextDisplay>> iterator = displays.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Location, TextDisplay> entry = iterator.next();
            if (!entry.getValue().isValid()) {
                iterator.remove();
                continue;
            }
            if (plugin.fieldManager().cropAt(entry.getKey()) == null) {
                entry.getValue().remove();
                iterator.remove();
            }
        }
    }

    private boolean isChunkLoaded(Location location) {
        World world = location.getWorld();
        return world != null && world.isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4);
    }
}
