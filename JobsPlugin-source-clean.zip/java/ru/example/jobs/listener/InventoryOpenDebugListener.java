package ru.example.jobs.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.plugin.RegisteredListener;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.gui.JobsGuiHolder;

public final class InventoryOpenDebugListener implements Listener {

    private final JobsPlugin plugin;
    private EventPriority cancelledAt;

    public InventoryOpenDebugListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onLowest(InventoryOpenEvent event) {
        cancelledAt = null;
        note(event, EventPriority.LOWEST);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onLow(InventoryOpenEvent event) {
        note(event, EventPriority.LOW);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onNormal(InventoryOpenEvent event) {
        note(event, EventPriority.NORMAL);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHigh(InventoryOpenEvent event) {
        note(event, EventPriority.HIGH);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onHighest(InventoryOpenEvent event) {
        note(event, EventPriority.HIGHEST);
    }

    private void note(InventoryOpenEvent event, EventPriority priority) {
        if (!(event.getInventory().getHolder() instanceof JobsGuiHolder)) {
            return;
        }
        if (!event.isCancelled() || cancelledAt == priority) {
            return;
        }
        cancelledAt = priority;
        StringBuilder suspects = new StringBuilder();
        for (RegisteredListener listener
                : InventoryOpenEvent.getHandlerList().getRegisteredListeners()) {
            if (listener.getPriority() != priority) {
                continue;
            }
            suspects.append(listener.getPlugin().getName()).append(' ');
        }
        plugin.getLogger().warning("Открытие меню работы отменил плагин: " + suspects
                + "(приоритет " + priority + "). Отключите или настройте его, "
                + "иначе пользуйтесь /jobs start и /jobs stop.");
    }
}
