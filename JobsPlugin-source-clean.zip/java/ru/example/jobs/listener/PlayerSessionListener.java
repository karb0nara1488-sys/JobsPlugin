package ru.example.jobs.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.job.Job;
import ru.example.jobs.job.JobType;
import ru.example.jobs.manager.SessionState;

public final class PlayerSessionListener implements Listener {

    private final JobsPlugin plugin;

    public PlayerSessionListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.jobManager().handleJoin(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.fieldManager().clearSelection(player.getUniqueId());
        plugin.jobManager().handleQuit(player);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!plugin.jobManager().isActive(player, JobType.LOADER)) {
            return;
        }
        Job job = plugin.jobManager().job(JobType.LOADER);
        SessionState session = plugin.jobManager().session(player);
        if (job != null) {
            job.onJoin(player, session);
        }
    }
}
