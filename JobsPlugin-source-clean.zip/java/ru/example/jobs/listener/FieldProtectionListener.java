package ru.example.jobs.listener;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.field.FieldCrop;

import java.util.Map;

public final class FieldProtectionListener implements Listener {

    private final JobsPlugin plugin;

    public FieldProtectionListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (plugin.fieldManager().isProtectedGround(block)) {
            event.setCancelled(true);
            plugin.messages().send(event.getPlayer(), "field-protected");
            return;
        }

        FieldCrop crop = plugin.fieldManager().cropAt(block.getLocation());
        if (crop == null) {
            return;
        }
        int percent = (int) Math.round(plugin.fieldManager().percent(crop));
        int minPercent = plugin.config().farmerMinGrowthPercent();
        if (percent < minPercent) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            plugin.messages().send(player, "crop-too-young", Map.of(
                    "%percent%", String.valueOf(percent),
                    "%min%", String.valueOf(minPercent)));
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        event.blockList().removeIf(this::protectedBlock);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(this::protectedBlock);
    }

    private boolean protectedBlock(Block block) {
        return plugin.fieldManager().isProtectedGround(block)
                || plugin.fieldManager().isFieldCrop(block);
    }
}
