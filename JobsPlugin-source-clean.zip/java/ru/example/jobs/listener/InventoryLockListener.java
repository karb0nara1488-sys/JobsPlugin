package ru.example.jobs.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.gui.JobsGuiHolder;
import ru.example.jobs.manager.SessionState;

public final class InventoryLockListener implements Listener {

    private final JobsPlugin plugin;

    public InventoryLockListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onOpen(InventoryOpenEvent event) {
        if (!event.isCancelled()) {
            return;
        }
        if (!(event.getInventory().getHolder() instanceof JobsGuiHolder)) {
            return;
        }
        plugin.getLogger().warning("Меню работы не открылось: событие InventoryOpenEvent отменил"
                + " другой плагин. Проверьте плагины, перехватывающие инвентари"
                + " (античиты, авторизация, лобби).");
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof JobsGuiHolder holder)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() == event.getView().getTopInventory()
                && event.getWhoClicked() instanceof Player player) {
            plugin.guiManager().handleClick(player, holder, event);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof JobsGuiHolder) {
            event.setCancelled(true);
            return;
        }
        if (event.getWhoClicked() instanceof Player player && carryingPhantom(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCarryClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof JobsGuiHolder) {
            return;
        }
        if (event.getWhoClicked() instanceof Player player && carryingPhantom(player)) {
            event.setCancelled(true);
        }
    }

    private boolean carryingPhantom(Player player) {
        SessionState session = plugin.jobManager().sessionIfPresent(player);
        return session != null && session.inventoryReplaced();
    }
}
