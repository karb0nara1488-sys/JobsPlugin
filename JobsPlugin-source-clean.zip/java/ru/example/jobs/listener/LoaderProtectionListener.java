package ru.example.jobs.listener;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import ru.example.jobs.JobsPlugin;

public final class LoaderProtectionListener implements Listener {

    private final JobsPlugin plugin;

    public LoaderProtectionListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!plugin.config().loaderProtectBlocks()) {
            return;
        }
        Block block = event.getBlock();
        if (!plugin.cargoTracker().isTracked(block)) {
            return;
        }
        Player player = event.getPlayer();
        if (canBreak(player)) {
            plugin.cargoTracker().untrack(block);
            return;
        }
        event.setCancelled(true);
        plugin.messages().send(player, "cargo-protected");
    }

    private boolean canBreak(Player player) {
        String permission = plugin.config().loaderProtectBypassPermission();
        if (permission == null || permission.isBlank() || permission.equalsIgnoreCase("none")) {
            return false;
        }
        return player.hasPermission(permission);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        if (!plugin.config().loaderProtectBlocks()) {
            return;
        }
        event.blockList().removeIf(block -> plugin.cargoTracker().isTracked(block));
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        if (!plugin.config().loaderProtectBlocks()) {
            return;
        }
        event.blockList().removeIf(block -> plugin.cargoTracker().isTracked(block));
    }
}
