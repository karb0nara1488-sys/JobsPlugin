package ru.example.jobs.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.job.FarmerJob;
import ru.example.jobs.job.JobType;
import ru.example.jobs.job.LoaderJob;
import ru.example.jobs.npc.NpcType;

public final class NpcListener implements Listener {

    private final JobsPlugin plugin;

    public NpcListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent event) {
        NpcType type = plugin.npcManager().npcType(event.getRightClicked()).orElse(null);
        if (type == null) {
            return;
        }

        event.setCancelled(true);
        EquipmentSlot hand = event.getHand();
        if (hand != null && hand != EquipmentSlot.HAND) {
            return;
        }
        use(event.getPlayer(), type);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        NpcType type = plugin.npcManager().npcType(event.getEntity()).orElse(null);
        if (type == null) {
            return;
        }
        event.setCancelled(true);
        if (event instanceof EntityDamageByEntityEvent byEntity
                && byEntity.getDamager() instanceof Player player) {
            use(player, type);
        }
    }

    private void use(Player player, NpcType type) {
        if (!player.hasPermission("jobs.use")) {
            plugin.messages().send(player, "no-permission");
            return;
        }
        if (type.isDelivery()) {
            deliver(player, type);
        } else {
            plugin.guiManager().open(player, type.jobType());
        }
    }

    private void deliver(Player player, NpcType type) {
        JobType jobType = type.jobType();
        JobType active = plugin.jobManager().activeJob(player);
        if (active == null) {
            plugin.messages().send(player, "must-start-job");
            return;
        }
        if (active != jobType) {
            plugin.messages().send(player, "wrong-job");
            return;
        }
        if (jobType == JobType.LOADER) {
            LoaderJob loader = (LoaderJob) plugin.jobManager().job(JobType.LOADER);
            if (loader != null) {
                loader.deliver(player);
            }
        } else if (jobType == JobType.FARMER) {
            FarmerJob farmer = (FarmerJob) plugin.jobManager().job(JobType.FARMER);
            if (farmer != null) {
                farmer.deliver(player);
            }
        }
    }
}
