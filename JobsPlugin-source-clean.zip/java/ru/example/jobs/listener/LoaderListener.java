package ru.example.jobs.listener;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.job.JobType;
import ru.example.jobs.job.LoaderJob;
import ru.example.jobs.manager.SessionState;

public final class LoaderListener implements Listener {

    private final JobsPlugin plugin;

    public LoaderListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onInteract(PlayerInteractEvent event) {
        if (event.isCancelled()) {
            return;
        }
        Player player = event.getPlayer();
        if (!plugin.jobManager().isActive(player, JobType.LOADER)) {
            return;
        }
        Block block = event.getClickedBlock();
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || block == null) {
            return;
        }
        EquipmentSlot hand = event.getHand();
        if (hand != null && hand != EquipmentSlot.HAND) {
            return;
        }
        if (!player.hasPermission("jobs.use")) {
            plugin.messages().send(player, "no-permission");
            event.setCancelled(true);
            return;
        }

        JobType active = plugin.jobManager().activeJob(player);
        if (active != JobType.LOADER) {
            return;
        }
        SessionState session = plugin.jobManager().sessionIfPresent(player);
        if (player.isSneaking()) {
            event.setCancelled(true);
            LoaderJob loader = (LoaderJob) plugin.jobManager().job(JobType.LOADER);
            if (loader != null) {
                loader.cancelJob(player);
            }
            return;
        }

        if (session != null && session.inventoryReplaced()) {
            event.setCancelled(true);
            return;
        }
        LoaderJob loader = (LoaderJob) plugin.jobManager().job(JobType.LOADER);
        if (loader != null && loader.startPickup(player, block)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!plugin.config().loaderFreezeOnPickup()) {
            return;
        }
        Player player = event.getPlayer();
        SessionState session = plugin.jobManager().sessionIfPresent(player);
        if (session == null || !session.lifting()) {
            return;
        }
        Location to = event.getTo();
        Location from = event.getFrom();
        if (to == null || (from.getX() == to.getX() && from.getY() == to.getY()
                && from.getZ() == to.getZ())) {
            return;
        }
        Location origin = session.liftOrigin();
        if (origin == null || origin.getWorld() == null || !origin.getWorld().equals(to.getWorld())) {
            return;
        }
        Location stuck = origin.clone();
        stuck.setYaw(to.getYaw());
        stuck.setPitch(to.getPitch());
        event.setTo(stuck);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (!plugin.jobManager().isActive(player, JobType.LOADER)) {
            return;
        }
        SessionState session = plugin.jobManager().sessionIfPresent(player);
        if (session == null) {
            return;
        }
        LoaderJob loader = (LoaderJob) plugin.jobManager().job(JobType.LOADER);
        if (loader == null) {
            return;
        }
        if (session.carrying()) {
            loader.returnBlock(player);
            event.setCancelled(true);
        } else if (session.lifting()) {
            
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onSwapHand(PlayerSwapHandItemsEvent event) {
        SessionState session = plugin.jobManager().sessionIfPresent(event.getPlayer());
        if (session != null && session.inventoryReplaced()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        SessionState session = plugin.jobManager().sessionIfPresent(player);
        if (session == null || !session.inventoryReplaced()) {
            return;
        }
        ItemStack[] snapshot = session.inventorySnapshot();
        if (event.getKeepInventory()) {
            player.getInventory().setContents(snapshot);
        } else {
            event.getDrops().clear();
            for (ItemStack item : snapshot) {
                if (item != null && !item.getType().isAir()) {
                    event.getDrops().add(item.clone());
                }
            }
        }
        LoaderJob loader = (LoaderJob) plugin.jobManager().job(JobType.LOADER);
        if (loader != null) {
            loader.cancelCarryOnDeath(player, session);
        }
    }
}
