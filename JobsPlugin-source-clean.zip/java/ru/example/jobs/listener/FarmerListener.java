package ru.example.jobs.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import ru.example.jobs.JobsPlugin;
import ru.example.jobs.field.FieldCrop;
import ru.example.jobs.job.FarmerJob;
import ru.example.jobs.job.JobType;

public final class FarmerListener implements Listener {

    private final JobsPlugin plugin;

    public FarmerListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent event) {
        if (event.isCancelled()) {
            return;
        }
        FieldCrop crop = plugin.fieldManager().cropAt(event.getBlock().getLocation());
        if (crop == null) {
            return;
        }
        FarmerJob farmer = (FarmerJob) plugin.jobManager().job(JobType.FARMER);
        if (farmer != null && farmer.harvest(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
        }
    }
}
