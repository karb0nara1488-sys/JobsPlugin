package ru.example.jobs.listener;

import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import ru.example.jobs.JobsPlugin;

public final class FieldSelectionListener implements Listener {

    private final JobsPlugin plugin;

    public FieldSelectionListener(JobsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent event) {
        if (!plugin.fieldManager().isSelecting(event.getPlayer())) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        Action action = event.getAction();
        if (action == Action.LEFT_CLICK_BLOCK) {
            plugin.fieldManager().setPosition(event.getPlayer(), block.getLocation(), true);
            event.setCancelled(true);
        } else if (action == Action.RIGHT_CLICK_BLOCK) {
            plugin.fieldManager().setPosition(event.getPlayer(), block.getLocation(), false);
            event.setCancelled(true);
        }
    }
}
