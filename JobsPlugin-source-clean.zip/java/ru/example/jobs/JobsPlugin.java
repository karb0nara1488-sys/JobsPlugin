package ru.example.jobs;

import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.event.server.ServiceRegisterEvent;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import ru.example.jobs.command.BarrelsCommand;
import ru.example.jobs.command.FieldCommand;
import ru.example.jobs.command.JobsCommand;
import ru.example.jobs.command.NpcCommand;
import ru.example.jobs.command.PosCommand;
import ru.example.jobs.config.Messages;
import ru.example.jobs.config.PluginConfig;
import ru.example.jobs.content.ContentManager;
import ru.example.jobs.field.FieldDisplayManager;
import ru.example.jobs.field.FieldManager;
import ru.example.jobs.gui.GuiManager;
import ru.example.jobs.job.FarmerJob;
import ru.example.jobs.job.LoaderJob;
import ru.example.jobs.listener.FarmerListener;
import ru.example.jobs.listener.FieldProtectionListener;
import ru.example.jobs.listener.FieldSelectionListener;
import ru.example.jobs.listener.InventoryLockListener;
import ru.example.jobs.listener.LoaderListener;
import ru.example.jobs.listener.LoaderProtectionListener;
import ru.example.jobs.listener.NpcListener;
import ru.example.jobs.listener.PlayerSessionListener;
import ru.example.jobs.manager.CargoTracker;
import ru.example.jobs.manager.EconomyService;
import ru.example.jobs.manager.JobManager;
import ru.example.jobs.manager.NpcManager;
import ru.example.jobs.manager.PlayerDataManager;
import ru.example.jobs.manager.TickService;
import ru.example.jobs.placeholder.JobsExpansion;
import ru.example.jobs.util.Keys;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;

public final class JobsPlugin extends JavaPlugin {

    private PluginConfig config;
    private Messages messages;
    private Keys keys;
    private EconomyService economyService;
    private BukkitTask economyRetryTask;
    private PlayerDataManager playerDataManager;
    private ContentManager contentManager;
    private CargoTracker cargoTracker;
    private JobManager jobManager;
    private NpcManager npcManager;
    private FieldManager fieldManager;
    private FieldDisplayManager fieldDisplayManager;
    private GuiManager guiManager;
    private TickService tickService;
    private JobsExpansion placeholderExpansion;

    @Override
    public void onEnable() {
        try {
            loadConfiguration();
            keys = new Keys(this);
            config = new PluginConfig(this);
            messages = new Messages(this);

            setupEconomy();

            playerDataManager = new PlayerDataManager(this, config);
            cargoTracker = new CargoTracker(this);
            cargoTracker.load();
            contentManager = new ContentManager(this, config);
            contentManager.load();
            fieldDisplayManager = new FieldDisplayManager(this);
            fieldManager = new FieldManager(this, fieldDisplayManager);
            jobManager = new JobManager(this);
            jobManager.register(new LoaderJob(this));
            jobManager.register(new FarmerJob(this));
            npcManager = new NpcManager(this);
            guiManager = new GuiManager(this);

            registerCommands();
            registerListeners();
            logInventoryListeners();

            fieldManager.load();
            fieldDisplayManager.refreshAll();
            npcManager.reload();

            tickService = new TickService(this);
            tickService.start();
            registerPlaceholder();
            registerWorldReady();

            getLogger().info("JobsPlugin включён. Контент: " + contentManager.providerName()
                    + ", полей: " + fieldManager.fields().size()
                    + ", груз: " + config.cargoMap().size()
                    + ", культур: " + config.crops().size()
                    + ", NPC: " + npcManager.totalCount()
                    + ", экономика: " + (economyService.available()
                            ? economyService.backendName() : "выключена"));
        } catch (Throwable throwable) {
            getLogger().log(Level.SEVERE, "Критическая ошибка запуска JobsPlugin", throwable);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        try {
            cancelEconomyRetry();
            if (tickService != null) {
                tickService.stop();
            }
            if (jobManager != null) {
                jobManager.handleDisable();
            }
            if (fieldManager != null) {
                fieldManager.save();
            }
            if (fieldDisplayManager != null) {
                fieldDisplayManager.removeAll();
            }
            if (cargoTracker != null) {
                cargoTracker.save();
            }
            if (npcManager != null) {
                npcManager.despawnAll();
            }
            if (playerDataManager != null) {
                playerDataManager.saveAll(true);
            }
            unregisterPlaceholder();
        } catch (Throwable throwable) {
            getLogger().log(Level.SEVERE, "Ошибка при выключении JobsPlugin", throwable);
        }
    }

    public void reloadPlugin() {
        reloadConfig();
        config.reload();
        messages.reload();
        reloadEconomy();
        contentManager.reload();
        fieldManager.reload();
        npcManager.reload();
        tickService.restart();
    }

    private void loadConfiguration() {
        saveDefaultConfig();
        YamlConfiguration defaults = bundledConfig();
        if (defaults == null) {
            return;
        }
        FileConfiguration current = getConfig();

        migrateDefaults(current, defaults);

        List<String> missing = new ArrayList<>();
        for (String key : defaults.getKeys(true)) {
            if (!defaults.isConfigurationSection(key) && !current.contains(key, true)) {
                missing.add(key);
            }
        }

        current.setDefaults(defaults);
        current.options().copyDefaults(true);

        if (missing.isEmpty()) {
            return;
        }
        getLogger().warning("В config.yml не хватало " + missing.size()
                + " ключей (например, " + missing.get(0) + "). Файл дополнен значениями"
                + " по умолчанию, прежняя версия сохранена как config.yml.bak.");
        backupConfigFile();
        for (String key : missing) {
            current.set(key, defaults.get(key));
        }
        saveConfig();
    }

    private void migrateDefaults(FileConfiguration current, YamlConfiguration defaults) {
        int target = defaults.getInt("config-version", 1);
        int stored = current.getInt("config-version", 1);
        if (stored >= target) {
            return;
        }
        if (stored < 2) {
            copySection(defaults, current, "gui");
            copySection(defaults, current, "jobs.loader.barrels");
        }
        current.set("config-version", target);
        saveConfig();
        getLogger().info("config.yml обновлён с версии " + stored + " до " + target
                + ": секции gui и jobs.loader.barrels перечитаны.");
    }

    private void copySection(YamlConfiguration source, FileConfiguration target, String path) {
        ConfigurationSection section = source.getConfigurationSection(path);
        if (section == null) {
            return;
        }
        target.set(path, null);
        for (String key : section.getKeys(true)) {
            if (section.isConfigurationSection(key)) {
                continue;
            }
            target.set(path + "." + key, section.get(key));
        }
    }

    private YamlConfiguration bundledConfig() {
        try (InputStream stream = getResource("config.yml")) {
            if (stream == null) {
                return null;
            }
            YamlConfiguration defaults = new YamlConfiguration();
            defaults.loadFromString(new String(stream.readAllBytes(), StandardCharsets.UTF_8));
            return defaults;
        } catch (Exception exception) {
            getLogger().log(Level.WARNING, "Не удалось прочитать config.yml из jar", exception);
            return null;
        }
    }

    private void backupConfigFile() {
        File file = new File(getDataFolder(), "config.yml");
        if (!file.isFile()) {
            return;
        }
        try {
            Files.copy(file.toPath(),
                    new File(getDataFolder(), "config.yml.bak").toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException exception) {
            getLogger().log(Level.WARNING, "Не удалось создать config.yml.bak", exception);
        }
    }

    private void setupEconomy() {
        economyService = new EconomyService(config);
        boolean hooked = economyService.tryHook();
        logEconomyState(hooked);
        registerEconomyListeners();
        if (!hooked && config.economyEnabled()) {
            logEconomyDiagnostics();
            scheduleEconomyRetry(config.economyRetryAttempts());
        }
    }

    private void reloadEconomy() {
        if (economyService == null) {
            return;
        }
        boolean hooked = economyService.reconfigure();
        logEconomyState(hooked);
        if (hooked || !config.economyEnabled()) {
            cancelEconomyRetry();
        } else {
            logEconomyDiagnostics();
            scheduleEconomyRetry(config.economyRetryAttempts());
        }
    }

    private void logEconomyState(boolean hooked) {
        if (hooked) {
            getLogger().info("Экономика подключена: " + economyService.backendName()
                    + " (через Vault).");
        } else if (!config.economyEnabled()) {
            getLogger().info("Экономика отключена в config.yml (economy.provider: none).");
        } else {
            getLogger().warning("Экономика недоступна: нужен Vault и economy-плагин "
                    + "(например, EssentialsX). Награды временно не выдаются, "
                    + "остальной функционал работает.");
        }
    }

    private void registerEconomyListeners() {
        getServer().getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void onServiceRegister(ServiceRegisterEvent event) {
                if (event.getProvider() == null) {
                    return;
                }
                Class<?> service = event.getProvider().getService();
                if (service == null
                        || !"net.milkbowl.vault.economy.Economy".equals(service.getName())) {
                    return;
                }
                hookEconomyNow("зарегистрирован economy-провайдер");
            }

            @EventHandler
            public void onPluginEnable(PluginEnableEvent event) {
                String name = event.getPlugin().getName();
                String lower = name.toLowerCase(Locale.ROOT);

                if (!lower.contains("vault") && !lower.contains("essent")) {
                    return;
                }
                hookEconomyNow("включён плагин " + name);
            }
        }, this);
    }

    private void hookEconomyNow(String reason) {
        if (economyService.available()) {
            return;
        }
        if (economyService.tryHook()) {
            getLogger().info("Экономика подключена: " + economyService.backendName()
                    + " (" + reason + ").");
            cancelEconomyRetry();
        }
    }

    private void scheduleEconomyRetry(int attempts) {
        cancelEconomyRetry();
        if (attempts <= 0) {
            return;
        }
        int ticks = Math.max(1, config.economyRetryTicks());
        int[] remaining = {attempts};
        economyRetryTask = getServer().getScheduler().runTaskTimer(this, () -> {
            if (economyService.available()) {
                cancelEconomyRetry();
                return;
            }
            if (economyService.tryHook()) {
                getLogger().info("Экономика подключена: " + economyService.backendName()
                        + " (повторная попытка).");
                cancelEconomyRetry();
                return;
            }
            if (--remaining[0] <= 0) {
                cancelEconomyRetry();
                getLogger().warning("Экономика так и не подключилась. "
                        + "Награды отключены до /jobs reload.");
                logEconomyDiagnostics();
            }
        }, ticks, ticks);
    }

    private void logEconomyDiagnostics() {
        for (String line : economyService.diagnostics()) {
            getLogger().info("  Экономика: " + line);
        }
    }

    private void cancelEconomyRetry() {
        if (economyRetryTask != null) {
            economyRetryTask.cancel();
            economyRetryTask = null;
        }
    }

    private void registerCommands() {
        NpcCommand npcCommand = new NpcCommand(this);
        FieldCommand fieldCommand = new FieldCommand(this);
        JobsCommand jobsCommand = new JobsCommand(this);
        BarrelsCommand barrelsCommand = new BarrelsCommand(this);
        bind("npc", npcCommand, npcCommand);
        bind("field", fieldCommand, fieldCommand);
        bind("jobs", jobsCommand, jobsCommand);
        bind("barrels", barrelsCommand, barrelsCommand);
        PosCommand pos1Command = new PosCommand(this, true);
        PosCommand pos2Command = new PosCommand(this, false);
        bind("pos1", pos1Command, pos1Command);
        bind("pos2", pos2Command, pos2Command);
    }

    private void bind(String name,
                      org.bukkit.command.CommandExecutor executor,
                      org.bukkit.command.TabCompleter completer) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().warning("Команда " + name + " не описана в plugin.yml");
            return;
        }
        command.setExecutor(executor);
        command.setTabCompleter(completer);
    }

    private void registerListeners() {
        PluginManager manager = getServer().getPluginManager();
        manager.registerEvents(new FieldSelectionListener(this), this);
        manager.registerEvents(new FieldProtectionListener(this), this);
        manager.registerEvents(new LoaderListener(this), this);
        manager.registerEvents(new LoaderProtectionListener(this), this);
        manager.registerEvents(new FarmerListener(this), this);
        manager.registerEvents(new NpcListener(this), this);
        manager.registerEvents(new InventoryLockListener(this), this);
        manager.registerEvents(new PlayerSessionListener(this), this);
    }

    private void registerWorldReady() {
        getServer().getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void onServerLoad(ServerLoadEvent event) {
                restoreWorldState("сервер загружен");
            }

            @EventHandler
            public void onWorldLoad(WorldLoadEvent event) {
                restoreWorldState("загружен мир " + event.getWorld().getName());
            }
        }, this);
    }

    private void restoreWorldState(String reason) {
        try {
            fieldManager.load();
            fieldDisplayManager.refreshAll();
            npcManager.reload();
            getLogger().info("Состояние после загрузки миров обновлено (" + reason + "): полей "
                    + fieldManager.fields().size() + ", культур " + fieldManager.cropCount()
                    + ", подписей " + fieldDisplayManager.displayCount() + ".");
        } catch (Throwable throwable) {
            getLogger().log(Level.WARNING,
                    "Не удалось восстановить поля/NPC после загрузки миров", throwable);
        }
    }

    private void logInventoryListeners() {
        StringBuilder names = new StringBuilder();
        for (org.bukkit.plugin.RegisteredListener listener
                : org.bukkit.event.inventory.InventoryOpenEvent.getHandlerList().getRegisteredListeners()) {
            if (names.length() > 0) {
                names.append(", ");
            }
            names.append(listener.getPlugin().getName());
        }
        getLogger().info("Слушатели InventoryOpenEvent: " + (names.length() == 0 ? "нет" : names));
    }
    private void registerPlaceholder() {
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") == null) {
            return;
        }
        try {
            placeholderExpansion = new JobsExpansion(this);
            if (placeholderExpansion.register()) {
                getLogger().info("PlaceholderAPI: расширение job зарегистрировано.");
            } else {
                getLogger().warning("PlaceholderAPI: не удалось зарегистрировать расширение job.");
            }
        } catch (Throwable throwable) {
            getLogger().log(Level.WARNING, "PlaceholderAPI недоступен", throwable);
            placeholderExpansion = null;
        }
    }

    private void unregisterPlaceholder() {
        if (placeholderExpansion == null) {
            return;
        }
        try {
            placeholderExpansion.unregister();
        } catch (Throwable throwable) {
            getLogger().log(Level.WARNING, "Не удалось отменить регистрацию PlaceholderAPI", throwable);
        } finally {
            placeholderExpansion = null;
        }
    }

    public PluginConfig config() {
        return config;
    }

    public Messages messages() {
        return messages;
    }

    public Keys keys() {
        return keys;
    }

    public EconomyService economyService() {
        return economyService;
    }

    public PlayerDataManager playerDataManager() {
        return playerDataManager;
    }

    public ContentManager contentManager() {
        return contentManager;
    }

    public CargoTracker cargoTracker() {
        return cargoTracker;
    }

    public JobManager jobManager() {
        return jobManager;
    }

    public NpcManager npcManager() {
        return npcManager;
    }

    public FieldManager fieldManager() {
        return fieldManager;
    }

    public FieldDisplayManager fieldDisplayManager() {
        return fieldDisplayManager;
    }

    public GuiManager guiManager() {
        return guiManager;
    }

    public TickService tickService() {
        return tickService;
    }
}
