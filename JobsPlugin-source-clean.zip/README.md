# JobsPlugin — Java source code

This package contains the Java source files supplied for JobsPlugin, preserving their package paths.

## Contents
- `java/ru/example/jobs/` — plugin source tree

## Important
This archive contains source `.java` files only. Build metadata (such as `pom.xml` or `build.gradle`), plugin resources (`plugin.yml`, configs), and dependency/version information were not present in the supplied archive. This package is therefore for source review and is not guaranteed to build standalone. Add the original project files before publishing as a complete buildable repository.
